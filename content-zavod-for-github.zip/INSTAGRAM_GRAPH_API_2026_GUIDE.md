# Instagram Graph API - Актуальное руководство 2026

## ⚠️ ВАЖНО: Типы токенов

### Facebook User Access Token (EAA...) - РАБОТАЕТ для hashtag search ✅
- **Формат**: Начинается с `EAA`
- **Где получить**: Через Facebook Login в вашем приложении
- **Поддерживает**: Hashtag search, получение постов по хэштегам
- **Требования**: 
  - App Review для `Instagram Public Content Access`
  - Разрешение `instagram_basic`
  - Пользователь должен быть одобрен для работы с Facebook Page

### Instagram Access Token (IGAAT...) - НЕ РАБОТАЕТ для hashtag search ❌
- **Формат**: Начинается с `IGAAT` или `IG`
- **Где получить**: Через Instagram Login
- **Поддерживает**: Получение информации о пользователе, публикация контента
- **НЕ поддерживает**: Hashtag search, получение постов по хэштегам

## 🔍 Поиск хэштегов (Hashtag Search)

### Endpoint
```
GET https://graph.facebook.com/v24.0/ig_hashtag_search?user_id=<<USER_ID>>&q=<<QUERY_STRING>>&access_token=<<TOKEN>>
```

### Пример запроса
```bash
curl -X GET \
"https://graph.facebook.com/v24.0/ig_hashtag_search?user_id=17841405309211844&q=funnyvideos&access_token=YOUR_TOKEN"
```

### Ответ
```json
{
  "data": [
    {
      "id": "17843857450040591"
    }
  ]
}
```

## 📸 Получение постов по хэштегу

### Top Media (Топ посты)
```
GET https://graph.facebook.com/v24.0/{hashtag_id}/top_media?user_id=<<USER_ID>>&fields=id,media_type,permalink&limit=50
```

### Recent Media (Недавние посты - только последние 24 часа!)
```
GET https://graph.facebook.com/v24.0/{hashtag_id}/recent_media?user_id=<<USER_ID>>&fields=id,media_type,permalink&limit=50
```

### Доступные поля
- `id` - ID поста
- `media_type` - Тип медиа (IMAGE, VIDEO, CAROUSEL_ALBUM)
- `media_url` - URL медиа файла
- `permalink` - **ОБЯЗАТЕЛЬНО** для получения ссылки на пост
- `timestamp` - Время публикации
- `caption` - Описание поста
- `comments_count` - Количество комментариев
- `like_count` - Количество лайков

## ⚙️ Требования для работы

1. **App Review** - Запросите доступ к `Instagram Public Content Access`
2. **Разрешения**:
   - `instagram_basic` (обязательно)
   - `pages_read_engagement` (если роль через Business Manager)
3. **Токен**: Facebook User access token (EAA...)
4. **Instagram Business Account**: Должен быть связан с Facebook Page

## 🚫 Ограничения

- **Максимум 30 уникальных хэштегов** за 7 дней (rolling period)
- **Recent media**: Только посты за последние 24 часа
- **Максимум 50 постов** на страницу
- **Не поддерживаются**: Stories, эмодзи в хэштегах, чувствительный контент
- **Не возвращаются**: Продвигаемые/рекламные посты

## 🔄 Версия API

**Актуальная версия на 2026 год: v24.0**

Meta обычно объявляет об изменениях за 90+ дней до депрекации.

## 📝 Пример использования в коде

```python
from modules.content_collector.instagram_graph_api import InstagramGraphAPI

# Инициализация (использует настройки из .env)
api = InstagramGraphAPI()

# Поиск хэштега
hashtag_id = api.search_hashtag("funnyvideos")

# Получение постов
post_urls = api.get_hashtag_posts("funnyvideos", limit=10)
```

## ❌ Частые ошибки

### "Unsupported get request. Object with ID 'ig_hashtag_search' does not exist"
**Причина**: 
- Используется Instagram токен (IGAAT) вместо Facebook токена (EAA)
- Не пройден App Review
- Нет разрешения `instagram_basic`

**Решение**: 
- Получите Facebook User access token через Facebook Login
- Пройдите App Review для `Instagram Public Content Access`

### "Error validating access token"
**Причина**: Токен истек или невалиден

**Решение**: Обновите токен или получите новый

### "User not approved for tasks on the connected Facebook Page"
**Причина**: Пользователь не имеет доступа к Facebook Page

**Решение**: Добавьте пользователя как администратора/редактора Facebook Page

## 🔗 Полезные ссылки

- [Официальная документация Instagram Graph API](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api)
- [Hashtag Search Endpoint](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api/reference/ig-hashtag-search/)
- [Hashtag Top Media](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api/reference/ig-hashtag/top-media/)
- [Hashtag Recent Media](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api/reference/ig-hashtag/recent-media/)
- [App Review Guide](https://developers.facebook.com/docs/app-review)
