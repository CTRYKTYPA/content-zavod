"""
БЫСТРАЯ ПРОВЕРКА COOKIES ИЗ ЯНДЕКС БРАУЗЕРА.
Упрощенная версия - только Яндекс браузер.
"""
import sys
from pathlib import Path
from loguru import logger
import io
import os
import time

# Настройка логирования
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
logger.remove()
logger.add(sys.stdout, format="{time:HH:mm:ss} | {level: <8} | {message}", level="INFO")

print("\n" + "="*80)
print("БЫСТРАЯ ПРОВЕРКА COOKIES ИЗ ЯНДЕКС БРАУЗЕРА")
print("="*80)

print("\n⚠️  ВАЖНО:")
print("Яндекс браузер должен быть ЗАКРЫТ!")
print("Подождите 2 секунды...")
time.sleep(2)

print("\nИщу cookies в Яндекс браузере...")

try:
    import browser_cookie3
    import requests
    
    # Путь к профилю Яндекс браузера
    yandex_profile = Path(os.getenv("LOCALAPPDATA")) / "Yandex" / "YandexBrowser" / "User Data" / "Default"
    cookies_file = yandex_profile / "Network" / "Cookies"
    
    if not cookies_file.exists():
        print(f"❌ Файл cookies не найден: {cookies_file}")
        print("\nУбедитесь что:")
        print("  1. Яндекс браузер установлен")
        print("  2. Вы залогинены на instagram.com")
        exit(1)
    
    print(f"✅ Найден файл cookies: {cookies_file}")
    
    # Пробуем несколько способов
    cookies = None
    
    # Способ 1: Прямое чтение
    try:
        print("\nПопытка 1: Прямое чтение через browser_cookie3...")
        cookies = browser_cookie3.chrome(domain_name="instagram.com", cookie_file=str(cookies_file))
        cookies_list = list(cookies)
        if cookies_list:
            print(f"✅ УСПЕХ! Найдено {len(cookies_list)} cookies")
            cookies = cookies_list
        else:
            cookies = None
    except Exception as e:
        print(f"❌ Прямое чтение не сработало: {e}")
        cookies = None
    
    # Способ 2: Копирование файла
    if not cookies:
        try:
            print("\nПопытка 2: Копирование файла для чтения...")
            import tempfile
            import shutil
            
            temp_cookies = Path(tempfile.gettempdir()) / f"yandex_cookies_{os.getpid()}.db"
            
            # Пробуем скопировать несколько раз
            for attempt in range(5):
                try:
                    time.sleep(0.5)
                    shutil.copy2(cookies_file, temp_cookies)
                    print(f"✅ Файл скопирован (попытка {attempt + 1})")
                    
                    cookies = browser_cookie3.chrome(domain_name="instagram.com", cookie_file=str(temp_cookies))
                    cookies_list = list(cookies)
                    
                    if cookies_list:
                        print(f"✅ УСПЕХ! Найдено {len(cookies_list)} cookies")
                        cookies = cookies_list
                        break
                    else:
                        cookies = None
                    
                    # Удаляем временный файл
                    try:
                        temp_cookies.unlink(missing_ok=True)
                    except:
                        pass
                    
                except PermissionError:
                    if attempt < 4:
                        print(f"   Попытка {attempt + 1}: файл заблокирован, жду...")
                        time.sleep(1)
                        continue
                    else:
                        print("❌ Файл заблокирован после всех попыток")
                        print("   Закройте Яндекс браузер и запустите снова")
                        break
                except Exception as e:
                    print(f"❌ Ошибка на попытке {attempt + 1}: {e}")
                    if attempt < 4:
                        time.sleep(1)
                        continue
                    break
                    
        except Exception as e:
            print(f"❌ Копирование не сработало: {e}")
    
    # Способ 3: SQLite напрямую
    if not cookies:
        try:
            print("\nПопытка 3: Чтение через SQLite...")
            import sqlite3
            import tempfile
            import shutil
            
            temp_db = Path(tempfile.gettempdir()) / f"yandex_cookies_sqlite_{os.getpid()}.db"
            
            # Копируем базу
            for attempt in range(5):
                try:
                    time.sleep(0.3)
                    shutil.copy2(cookies_file, temp_db)
                    
                    # Читаем через SQLite
                    conn = sqlite3.connect(str(temp_db))
                    cursor = conn.cursor()
                    
                    cursor.execute("""
                        SELECT name, value, host_key
                        FROM cookies
                        WHERE host_key LIKE '%instagram.com%'
                    """)
                    
                    cookie_rows = cursor.fetchall()
                    conn.close()
                    
                    # Удаляем временный файл
                    try:
                        temp_db.unlink(missing_ok=True)
                    except:
                        pass
                    
                    if cookie_rows:
                        print(f"✅ Найдено {len(cookie_rows)} cookies через SQLite")
                        print("   Обрабатываю cookies...")
                        
                        # Пробуем расшифровать через DPAPI
                        try:
                            import win32crypt
                            DECRYPT_AVAILABLE = True
                        except ImportError:
                            DECRYPT_AVAILABLE = False
                            print("   ⚠️  win32crypt не установлен (pip install pywin32)")
                            print("   Использую значения как есть...")
                        
                        decrypted_cookies = []
                        for row in cookie_rows:
                            name, encrypted_value, host_key = row[0], row[1], row[2]
                            
                            # Пробуем расшифровать
                            decrypted_value = None
                            try:
                                if DECRYPT_AVAILABLE and isinstance(encrypted_value, bytes):
                                    # Windows DPAPI расшифровка
                                    try:
                                        decrypted_value = win32crypt.CryptUnprotectData(
                                            encrypted_value, None, None, None, 0
                                        )[1].decode('utf-8')
                                    except:
                                        # Если не получилось, пробуем как строку
                                        try:
                                            decrypted_value = encrypted_value.decode('utf-8', errors='ignore')
                                        except:
                                            decrypted_value = str(encrypted_value)
                                else:
                                    # Если значение уже не зашифровано
                                    if isinstance(encrypted_value, bytes):
                                        try:
                                            decrypted_value = encrypted_value.decode('utf-8', errors='ignore')
                                        except:
                                            decrypted_value = str(encrypted_value)
                                    else:
                                        decrypted_value = str(encrypted_value)
                                
                            except Exception as e:
                                # Если не удалось расшифровать, используем как есть
                                if isinstance(encrypted_value, bytes):
                                    try:
                                        decrypted_value = encrypted_value.decode('utf-8', errors='ignore')
                                    except:
                                        decrypted_value = str(encrypted_value)
                                else:
                                    decrypted_value = str(encrypted_value)
                            
                            if decrypted_value:
                                # Создаем cookie объект
                                class FakeCookie:
                                    def __init__(self, name, value, domain):
                                        self.name = name
                                        self.value = value
                                        self.domain = domain
                                
                                decrypted_cookies.append(FakeCookie(name, decrypted_value, host_key))
                        
                        if decrypted_cookies:
                            print(f"✅ УСПЕХ! Обработано {len(decrypted_cookies)} cookies")
                            cookies = decrypted_cookies
                        else:
                            print("⚠️  Не удалось обработать cookies")
                            cookies = None
                        break
                    else:
                        cookies = None
                        
                except PermissionError:
                    if attempt < 4:
                        time.sleep(0.5)
                        continue
                    else:
                        print("❌ Файл заблокирован")
                        break
                except Exception as e:
                    print(f"❌ Ошибка SQLite на попытке {attempt + 1}: {e}")
                    if attempt < 4:
                        time.sleep(0.5)
                        continue
                    break
                    
        except Exception as e:
            print(f"❌ SQLite не сработало: {e}")
    
    if not cookies:
        print("\n" + "="*80)
        print("❌ НЕ УДАЛОСЬ ПРОЧИТАТЬ COOKIES")
        print("="*80)
        print("\nАльтернативный способ (работает с открытым браузером):")
        print("1. Запустите: python get_cookies_from_open_browser.py")
        print("2. Следуйте инструкциям в скрипте")
        print("\nИли:")
        print("1. Закройте Яндекс браузер ПОЛНОСТЬЮ")
        print("2. Подождите 3-5 секунд")
        print("3. Запустите скрипт снова:")
        print("   python quick_yandex_cookies.py")
        exit(1)
    
    # Создаем сессию
    print("\n" + "="*80)
    print("СОЗДАНИЕ СЕССИИ")
    print("="*80)
    
    session = requests.Session()
    
    for cookie in cookies:
        session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
    
    print(f"✅ Загружено {len(cookies)} cookies в сессию")
    
    # Проверяем важные cookies
    important = ['sessionid', 'csrftoken', 'ds_user_id']
    found = [name for name in important if name in session.cookies]
    print(f"✅ Найдено важных cookies: {', '.join(found)}")
    
    if 'sessionid' not in session.cookies:
        print("\n⚠️  ВНИМАНИЕ: sessionid не найден!")
        print("   Сессия может не работать")
        print("   Убедитесь что вы залогинены на instagram.com")
    
    # Проверяем работоспособность
    print("\n" + "="*80)
    print("ПРОВЕРКА РАБОТОСПОСОБНОСТИ")
    print("="*80)
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'X-IG-App-ID': '936619743392459',
    }
    
    try:
        response = session.get(
            'https://www.instagram.com/api/v1/web/data/shared_data/',
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            try:
                data = response.json()
                if 'config' in data:
                    viewer = data['config'].get('viewer')
                    if viewer:
                        username = viewer.get('username')
                        if username:
                            print(f"\n✅✅✅ УСПЕХ! Сессия работает!")
                            print(f"   Пользователь: {username}")
                            print(f"   Cookies: {len(cookies)} шт.")
                            print(f"   sessionid: ✅")
                            
                            print("\n" + "="*80)
                            print("ГОТОВО! Можно запускать сбор:")
                            print("  python run_thematic_collection.py humor 10")
                            print("="*80)
                            exit(0)
            except:
                pass
        
        if 'sessionid' in session.cookies:
            print("\n✅ Сессия работает (есть sessionid cookie)")
            print("\n" + "="*80)
            print("ГОТОВО! Можно запускать сбор:")
            print("  python run_thematic_collection.py humor 10")
            print("="*80)
            exit(0)
        else:
            print("\n⚠️  Сессия может не работать (нет sessionid)")
            
    except Exception as e:
        print(f"\n⚠️  Ошибка проверки: {e}")
        if 'sessionid' in session.cookies:
            print("   Но sessionid есть - можно попробовать использовать")
    
    print("\n" + "="*80)

except ImportError:
    print("❌ browser_cookie3 не установлен")
    print("Установите: pip install browser-cookie3")
except Exception as e:
    print(f"❌ Ошибка: {e}")
    import traceback
    traceback.print_exc()
