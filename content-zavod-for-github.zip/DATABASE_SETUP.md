# Настройка базы данных

## Вариант 1: SQLite (проще всего, по умолчанию)

SQLite уже настроен по умолчанию! Ничего устанавливать не нужно.

База данных будет создана автоматически в файле `content_zavod.db` в корне проекта.

**Преимущества:**
- ✅ Не требует установки дополнительного ПО
- ✅ Работает сразу "из коробки"
- ✅ Подходит для разработки и тестирования

**Недостатки:**
- ⚠️ Менее производительна для больших объёмов данных
- ⚠️ Не поддерживает некоторые продвинутые функции PostgreSQL

## Вариант 2: PostgreSQL (для продакшена)

Если хотите использовать PostgreSQL:

### 1. Установите PostgreSQL

**Windows:**
- Скачайте с https://www.postgresql.org/download/windows/
- Или через Chocolatey: `choco install postgresql`

**Linux:**
```bash
sudo apt-get install postgresql
```

**Mac:**
```bash
brew install postgresql
```

### 2. Создайте базу данных

```sql
CREATE DATABASE content_zavod;
CREATE USER content_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE content_zavod TO content_user;
```

### 3. Обновите `.env`

```bash
DATABASE_URL=postgresql://content_user:your_password@localhost:5432/content_zavod
```

### 4. Перезапустите систему

База данных будет автоматически создана при первом запуске.

## Текущая настройка

По умолчанию используется SQLite. Чтобы проверить:

```bash
# В .env файле должно быть:
DATABASE_URL=sqlite:///content_zavod.db
```

Или просто не указывайте DATABASE_URL - будет использован SQLite по умолчанию.
