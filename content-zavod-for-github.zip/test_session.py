"""Проверка сессии Instagram."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from config import settings
import instaloader

print("=" * 60)
print("ПРОВЕРКА СЕССИИ INSTAGRAM")
print("=" * 60)

username = settings.INSTAGRAM_USERNAME

if not username:
    print("Ошибка: INSTAGRAM_USERNAME не указан")
    exit(1)

print(f"\nЛогин: {username}")

try:
    L = instaloader.Instaloader()
    
    # Загружаем сессию
    try:
        from instaloader.instaloader import get_default_session_filename
        session_file = get_default_session_filename(username)
        if Path(session_file).exists():
            print(f"\nНайдена сессия: {session_file}")
            L.load_session_from_file(username)
            print("Сессия загружена")
        else:
            print(f"\nСессия не найдена: {session_file}")
            exit(1)
    except Exception as e:
        print(f"Ошибка загрузки сессии: {e}")
        exit(1)
    
    # Пробуем получить информацию о профиле
    print("\nПроверяю доступ к Instagram...")
    try:
        profile = instaloader.Profile.from_username(L.context, username)
        print(f"OK: Профиль найден: @{profile.username}")
        print(f"   Подписчиков: {profile.followers}")
        print(f"   Постов: {profile.mediacount}")
        
        # Пробуем получить несколько постов
        print("\nПробуем получить последние посты...")
        posts = list(profile.get_posts())
        if posts:
            print(f"OK: Найдено {len(posts)} постов")
            for i, post in enumerate(posts[:3], 1):
                print(f"   {i}. {post.shortcode} - {post.typename}")
                if post.is_video:
                    print(f"      Видео: {post.video_duration} сек, просмотров: {post.video_view_count or 'N/A'}")
        else:
            print("Нет постов")
            
    except Exception as e:
        print(f"Ошибка доступа к профилю: {e}")
        import traceback
        traceback.print_exc()
        
        print("\nПопробуем обновить сессию...")
        print("Запустите: python interactive_login.py")
        
except Exception as e:
    print(f"Ошибка: {e}")
    import traceback
    traceback.print_exc()
