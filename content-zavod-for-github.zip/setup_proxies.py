"""Настройка прокси для эмуляции разных IP."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from config import settings

print("=" * 60)
print("НАСТРОЙКА ПРОКСИ ДЛЯ ЭМУЛЯЦИИ РАЗНЫХ IP")
print("=" * 60)

print("\nДля эмуляции разных IP адресов нужны прокси.")
print("Вы можете использовать:")
print("1. Бесплатные прокси (менее надёжные)")
print("2. Платные прокси сервисы (рекомендуется)")
print("3. VPN с прокси")
print()

choice = input("Добавить прокси вручную? (y/n): ").strip().lower()

if choice == 'y':
    print("\nВведите прокси (можно несколько через запятую):")
    print("Формат: http://user:pass@host:port или http://host:port")
    print("Пример: http://proxy1.com:8080,http://proxy2.com:8080")
    
    proxies_input = input("Прокси: ").strip()
    
    if proxies_input:
        # Обновляем .env файл
        env_file = Path(".env")
        env_content = ""
        
        if env_file.exists():
            env_content = env_file.read_text(encoding="utf-8")
        
        lines = env_content.split("\n") if env_content else []
        updated_lines = []
        proxy_found = False
        
        for line in lines:
            if line.startswith("INSTAGRAM_PROXY="):
                updated_lines.append(f"INSTAGRAM_PROXY={proxies_input}")
                proxy_found = True
            else:
                updated_lines.append(line)
        
        if not proxy_found:
            updated_lines.append(f"INSTAGRAM_PROXY={proxies_input}")
        
        env_file.write_text("\n".join(updated_lines), encoding="utf-8")
        
        print(f"\nOK: Прокси добавлены в .env")
        print(f"Количество: {len(proxies_input.split(','))}")
        print("\nТеперь система будет автоматически использовать разные IP!")
    else:
        print("Прокси не добавлены.")
else:
    print("\nРекомендуемые сервисы прокси:")
    print("1. Bright Data (бывший Luminati) - https://brightdata.com/")
    print("2. Smartproxy - https://smartproxy.com/")
    print("3. Oxylabs - https://oxylabs.io/")
    print("4. ProxyMesh - https://proxymesh.com/")
    print("\nИли используйте VPN с поддержкой прокси.")
    print("\nПосле получения прокси запустите этот скрипт снова.")

print("\n" + "=" * 60)
