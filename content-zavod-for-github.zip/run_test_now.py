"""
Быстрый запуск теста скачивания видео с Instagram.
Использует комбинированный метод для максимальной надежности.
"""
import sys
from pathlib import Path
from loguru import logger

# Настройка логирования
logger.remove()
logger.add(sys.stdout, format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>", level="INFO")

from modules.content_collector.instagram_downloader import (
    download_video_combined,
    download_video_ytdlp,
    extract_shortcode,
    load_user_agents,
)

def main():
    print("\n" + "="*80)
    print("БЫСТРЫЙ ТЕСТ СКАЧИВАНИЯ ВИДЕО С INSTAGRAM")
    print("="*80)
    
    # Проверяем user agents
    user_agents = load_user_agents()
    logger.info(f"Загружено {len(user_agents)} user agents из useragents.txt\n")
    
    # Получаем URL из аргументов
    if len(sys.argv) < 2:
        print("\nИспользование: python run_test_now.py <URL_поста_Instagram>")
        print("Пример: python run_test_now.py https://www.instagram.com/p/ABC123/")
        print("\nВведите URL публичного поста Instagram с видео:")
        test_url = input("URL: ").strip()
        
        if not test_url:
            logger.error("URL не указан! Завершение.")
            return
    else:
        test_url = sys.argv[1].strip()
    
    if 'instagram.com' not in test_url:
        logger.error("Неверный URL! Должен содержать instagram.com")
        return
    
    shortcode = extract_shortcode(test_url)
    if not shortcode:
        logger.error("Не удалось извлечь shortcode из URL!")
        return
    
    logger.info(f"Тестируемый URL: {test_url}")
    logger.info(f"Shortcode: {shortcode}\n")
    
    # Создаем директорию для результатов
    output_dir = Path("test_downloads")
    output_dir.mkdir(exist_ok=True)
    logger.info(f"Результаты будут сохранены в: {output_dir.absolute()}\n")
    
    # ТЕСТ 1: Комбинированный метод (рекомендуется - пробует все по очереди)
    logger.info("="*80)
    logger.info("ТЕСТ 1: Комбинированный метод (пробует все методы по очереди)")
    logger.info("="*80)
    
    output_path = output_dir / f"{shortcode}_combined.mp4"
    try:
        logger.info("Запускаю комбинированный метод...")
        success = download_video_combined(test_url, str(output_path))
        
        if success and output_path.exists():
            file_size = output_path.stat().st_size
            logger.info(f"[SUCCESS] Видео скачано через комбинированный метод!")
            logger.info(f"Размер: {file_size / 1024 / 1024:.2f} MB")
            logger.info(f"Путь: {output_path.absolute()}")
        else:
            logger.warning("[FAIL] Комбинированный метод не смог скачать видео")
    except Exception as e:
        logger.error(f"[ERROR] Ошибка комбинированного метода: {str(e)}")
        import traceback
        logger.debug(traceback.format_exc())
    
    # ТЕСТ 2: yt-dlp (самый надежный метод)
    logger.info(f"\n{'='*80}")
    logger.info("ТЕСТ 2: yt-dlp метод (самый надежный)")
    logger.info("="*80)
    
    output_path = output_dir / f"{shortcode}_ytdlp.mp4"
    try:
        logger.info("Запускаю yt-dlp метод...")
        success = download_video_ytdlp(test_url, str(output_path))
        
        if success and output_path.exists():
            file_size = output_path.stat().st_size
            logger.info(f"[SUCCESS] Видео скачано через yt-dlp!")
            logger.info(f"Размер: {file_size / 1024 / 1024:.2f} MB")
            logger.info(f"Путь: {output_path.absolute()}")
        else:
            logger.warning("[FAIL] yt-dlp метод не смог скачать видео")
    except Exception as e:
        logger.error(f"[ERROR] Ошибка yt-dlp метода: {str(e)}")
        import traceback
        logger.debug(traceback.format_exc())
    
    # Итоги
    logger.info(f"\n{'='*80}")
    logger.info("ТЕСТИРОВАНИЕ ЗАВЕРШЕНО")
    logger.info("="*80)
    
    # Проверяем результаты
    combined_file = output_dir / f"{shortcode}_combined.mp4"
    ytdlp_file = output_dir / f"{shortcode}_ytdlp.mp4"
    
    if combined_file.exists():
        logger.info(f"\n[SUCCESS] Комбинированный метод: файл найден ({combined_file.stat().st_size / 1024 / 1024:.2f} MB)")
    if ytdlp_file.exists():
        logger.info(f"[SUCCESS] yt-dlp метод: файл найден ({ytdlp_file.stat().st_size / 1024 / 1024:.2f} MB)")
    
    if combined_file.exists() or ytdlp_file.exists():
        logger.info(f"\n✅ ТЕСТ ПРОЙДЕН! Видео успешно скачаны!")
        logger.info(f"Все файлы в: {output_dir.absolute()}")
    else:
        logger.warning(f"\n⚠️ Тест не прошел. Проверьте:")
        logger.warning("  1. URL поста правильный и публичный")
        logger.warning("  2. Пост содержит видео (не фото)")
        logger.warning("  3. VPN работает корректно")
        logger.warning("  4. Интернет соединение стабильно")

if __name__ == '__main__':
    main()
