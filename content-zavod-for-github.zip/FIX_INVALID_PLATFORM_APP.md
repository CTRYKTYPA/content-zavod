# Исправление ошибки "Invalid platform app"

## ❌ Ошибка:
**"Недействительный запрос: Параметры запроса недействительны: Invalid platform app"**

Эта ошибка означает, что приложение не настроено для работы с Instagram Graph API.

## ✅ Решение (пошагово):

### Шаг 1: Проверьте, что Instagram Graph API добавлен

1. Перейдите в ваше приложение в Facebook Developers
2. В левом меню найдите **"Продукты"** (Products) или **"Add Product"**
3. Убедитесь, что **"Instagram Graph API"** добавлен и настроен
4. Если его нет - нажмите **"Add Product"** → найдите **"Instagram Graph API"** → **"Set Up"**

### Шаг 2: Настройте платформы (Platforms)

1. В настройках приложения найдите раздел **"Настройки"** (Settings) → **"Основные"** (Basic)
2. Прокрутите вниз до раздела **"Платформы"** (Platforms)
3. Убедитесь, что добавлена платформа **"Website"** или **"Веб-сайт"**
   - Если нет - нажмите **"Добавить платформу"** (Add Platform)
   - Выберите **"Website"**
   - В поле "URL сайта" можно указать: `https://localhost` или `https://example.com`

### Шаг 3: Проверьте настройки Instagram Graph API

1. В левом меню найдите **"Instagram Graph API"** (или "Products" → "Instagram Graph API")
2. Убедитесь, что все базовые настройки заполнены
3. Проверьте раздел **"Basic Display"** или **"Graph API"**

### Шаг 4: Свяжите Instagram Business Account (если нужно)

**ВАЖНО:** Для работы с Instagram Graph API нужен **Instagram Business Account** или **Creator Account**:

1. Убедитесь, что ваш Instagram аккаунт переведен в **Business** или **Creator** режим
2. Instagram аккаунт должен быть связан с **Facebook Page**
3. В настройках приложения найдите раздел про связывание аккаунтов

### Шаг 5: Попробуйте снова

1. Вернитесь в **Graph API Explorer**
2. Убедитесь, что выбрано ваше приложение
3. Попробуйте снова нажать **"Generate Instagram Access Token"**

## 🔍 Альтернативный способ (если не работает):

Если ошибка сохраняется, попробуйте получить токен через **Facebook Login**:

1. В Graph API Explorer выберите **"Пользователь или Страница"** → **"Получить маркер"** (Get Token)
2. Добавьте разрешения:
   - `instagram_basic`
   - `pages_read_engagement`
3. Нажмите **"Generate Access Token"**
4. После авторизации получите токен для вашей Facebook Page
5. Затем используйте этот токен для запросов к Instagram API

## ⚠️ Важно:

- **Instagram Graph API работает только с Business/Creator аккаунтами**
- Личный аккаунт (Personal) не поддерживается
- Аккаунт должен быть связан с Facebook Page

## 📝 Проверочный список:

- [ ] Instagram Graph API добавлен как продукт
- [ ] Платформа "Website" добавлена в настройках
- [ ] Instagram аккаунт переведен в Business/Creator режим
- [ ] Instagram аккаунт связан с Facebook Page
- [ ] Все базовые настройки приложения заполнены
