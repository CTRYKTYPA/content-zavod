import re
import json

with open('debug_html/instagram_funny.html', 'rb') as f:
    content = f.read()

content_str = content.decode('utf-8', errors='ignore')

print(f"Размер HTML: {len(content_str)} символов")
print(f"Есть 'script': {'script' in content_str.lower()}")
print(f"Есть 'json': {'json' in content_str.lower()[:10000]}")

# Ищем shortcode
matches = re.findall(r'["\']shortcode["\']\s*:\s*["\']([^"\']+)', content_str, re.IGNORECASE)
print(f"\nНайдено 'shortcode' в тексте: {len(matches)}")
if matches:
    print(f"Примеры: {matches[:5]}")

# Ищем /p/ или /reel/
matches2 = re.findall(r'/(p|reel)/([A-Za-z0-9_-]+)', content_str)
print(f"\nНайдено /p/ или /reel/: {len(matches2)}")
if matches2:
    print(f"Примеры: {matches2[:5]}")

# Ищем window._sharedData
if 'window._sharedData' in content_str:
    print("\n✓ window._sharedData найден!")
    match = re.search(r'window\._sharedData\s*=\s*({.+?});', content_str, re.DOTALL)
    if match:
        print("✓ JSON найден в window._sharedData")
else:
        print("\nwindow._sharedData НЕ найден")

# Ищем другие JSON структуры
if '__additionalDataLoaded' in content_str:
    print("✓ __additionalDataLoaded найден")
if 'edge_hashtag_to_media' in content_str:
    print("✓ edge_hashtag_to_media найден")

# Ищем любые упоминания instagram.com/p/ или instagram.com/reel/
url_matches = re.findall(r'instagram\.com/(p|reel)/[A-Za-z0-9_-]+', content_str)
print(f"\nНайдено упоминаний instagram.com/p/ или /reel/: {len(url_matches)}")
if url_matches:
    print(f"Примеры: {url_matches[:5]}")
