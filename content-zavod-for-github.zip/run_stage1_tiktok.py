#!/usr/bin/env python3
"""
Этап 1 — запуск сбора и обработки по TikTok.

1. Собирает контент из активных источников tiktok (users / hashtags).
2. Скачивает найденные видео через yt-dlp (как YouTube).
3. Обрабатывает (уникализация + плашка).
4. Видео «готовы к публикации» (PROCESSED). В ТГ уходит отчёт.

Нет API — только yt-dlp. Источники: setup_tiktok_stage1.py. Куки, app_info, темы: см. TIKTOK_SETUP.md.

Запуск:
  python run_stage1_tiktok.py
  python run_stage1_tiktok.py --themes "humor,business" --collect 10 --download 10 --process 10
  python run_stage1_tiktok.py --themes "humor" --dry-run   # проверить источники
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from loguru import logger

from config import settings
from database.models import Base, ContentSource, Publication, Topic, Video, VideoStatus
from modules.content_manager import ContentManager
from modules.telegram_bot.notify import send_report_to_admins


def _clear_videos_db(db) -> None:
    db.query(Publication).delete()
    db.query(Video).delete()
    db.commit()


def run_stage1(
    collect_limit: int = 30,
    download_limit: int = 20,
    process_limit: int = 20,
    themes: list[str] | None = None,
    clear_db: bool = False,
):
    engine = create_engine(settings.DATABASE_URL)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    if clear_db:
        _clear_videos_db(db)
    cm = ContentManager(db)

    q = (
        db.query(ContentSource)
        .join(Topic, ContentSource.topic_id == Topic.id)
        .filter(
            ContentSource.source_type == "tiktok",
            ContentSource.is_active == True,
        )
    )
    if themes:
        from tiktok_themes_config import TIKTOK_THEMES
        slug2name = {th["slug"].lower(): th["name"] for th in TIKTOK_THEMES}
        name2name = {th["name"].lower(): th["name"] for th in TIKTOK_THEMES}
        requested = [t.strip() for t in themes if t]
        matches = []
        for r in requested:
            k = r.lower()
            if k in slug2name:
                matches.append(slug2name[k])
            elif k in name2name:
                matches.append(name2name[k])
        if matches:
            q = q.filter(Topic.name.in_(matches))
    sources = q.all()

    if not sources:
        from tiktok_themes_config import TIKTOK_THEMES
        slugs = [th["slug"] for th in TIKTOK_THEMES]
        logger.warning(
            "Нет активных TikTok-источников по выбранным темам. "
            "Запустите: python scripts/setup_tiktok_stage1.py. "
            f"Доступные slug: {slugs}. Вы указали: {themes!r}. Пример: --themes \"humor,business\""
        )
        db.close()
        return

    total_collected = 0
    per_src = max(1, collect_limit // len(sources)) if collect_limit else 50
    for src in sources:
        created = cm.collect_content_from_source(src.id, limit=per_src)
        total_collected += len(created)
    logger.info(f"Собрано: {total_collected}")

    to_download = db.query(Video).filter(Video.status == VideoStatus.FOUND).limit(download_limit).all()
    downloaded_ok = 0
    for v in to_download:
        if cm.download_video(v.id):
            downloaded_ok += 1
    logger.info(f"Скачано: {downloaded_ok} из {len(to_download)}")

    to_process = db.query(Video).filter(Video.status == VideoStatus.DOWNLOADED).limit(process_limit).all()
    processed_ok = 0
    for v in to_process:
        if cm.process_video(v.id):
            processed_ok += 1
    logger.info(f"Обработано: {processed_ok} из {len(to_process)}")

    db.close()
    logger.info("Этап 1 (TikTok) завершён. Отчёт в Telegram.")

    report = (
        "📊 Этап 1 (TikTok) — отчёт\n\n"
        f"🔍 Собрано новых: {total_collected}\n"
        f"⬇️ Скачано: {downloaded_ok}/{len(to_download)}\n"
        f"⚙️ Обработано: {processed_ok}/{len(to_process)}\n\n"
        f"✅ Готово к публикации: {processed_ok} видео\n\n"
        "Команды в боте: /status /stats /alerts /videos"
    )
    send_report_to_admins(report)


def _parse_args():
    p = argparse.ArgumentParser(description="Этап 1: TikTok — сбор → скачивание → обработка, отчёт в ТГ.")
    p.add_argument("--themes", type=str, default=None, help='Темы по slug: humor, business, lifestyle, tech, motivation. Через запятую.')
    p.add_argument("--collect", type=int, default=30, help="Лимит на сбор (всего)")
    p.add_argument("--download", type=int, default=20, help="Лимит на скачивание")
    p.add_argument("--process", type=int, default=20, help="Лимит на обработку")
    p.add_argument("--clear-db-only", action="store_true", help="Только очистить БД (видео и публикации)")
    p.add_argument("--dry-run", action="store_true", help="Только проверить источники по темам и выйти")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    if args.clear_db_only:
        engine = create_engine(settings.DATABASE_URL)
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine)
        db = Session()
        _clear_videos_db(db)
        db.close()
        logger.info("БД очищена. Запуск: python run_stage1_tiktok.py")
        sys.exit(0)
    themes = [t.strip() for t in args.themes.split(",")] if args.themes else None
    if getattr(args, "dry_run", False):
        engine = create_engine(settings.DATABASE_URL)
        Base.metadata.create_all(engine)
        db = sessionmaker(bind=engine)()
        q = db.query(ContentSource).join(Topic, ContentSource.topic_id == Topic.id).filter(
            ContentSource.source_type == "tiktok", ContentSource.is_active == True
        )
        if themes:
            from tiktok_themes_config import TIKTOK_THEMES
            slug2name = {th["slug"].lower(): th["name"] for th in TIKTOK_THEMES}
            name2name = {th["name"].lower(): th["name"] for th in TIKTOK_THEMES}
            requested = [t.strip() for t in themes if t]
            matches = []
            for r in requested:
                k = r.lower()
                if k in slug2name:
                    matches.append(slug2name[k])
                elif k in name2name:
                    matches.append(name2name[k])
            logger.info(f"dry-run: requested={requested!r}, matches={matches!r}")
            if matches:
                q = q.filter(Topic.name.in_(matches))
        srcs = q.all()
        logger.info(f"dry-run: темы={themes!r}, источников={len(srcs)}")
        for s in srcs:
            logger.info(f"  источник id={s.id}, тема={s.topic.name!r}")
        db.close()
        sys.exit(0)
    run_stage1(
        collect_limit=args.collect,
        download_limit=args.download,
        process_limit=args.process,
        themes=themes,
    )
