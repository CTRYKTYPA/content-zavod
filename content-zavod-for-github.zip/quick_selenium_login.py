"""
Быстрый модуль для проверки cookies и логина через Selenium.
Только Undetected-ChromeDriver и Nodriver - без лишних методов.
"""
import sys
from pathlib import Path
from loguru import logger
import io
import time
import random

# Настройка логирования
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
logger.remove()
logger.add(sys.stdout, format="{time:HH:mm:ss} | {level: <8} | {message}", level="INFO")

from config import settings
import requests

def test_browser_cookies():
    """Быстрая проверка cookies из браузера."""
    print("\n" + "="*80)
    print("ШАГ 1: ПРОВЕРКА COOKIES ИЗ БРАУЗЕРА")
    print("="*80)
    
    session = requests.Session()
    
    try:
        from modules.thematic_collectors.browser_cookies_helper import (
            load_cookies_from_browser,
            test_session
        )
        
        browsers = ['chrome', 'yandex', 'firefox', 'edge']
        for browser in browsers:
            print(f"\nПробую {browser}...")
            if load_cookies_from_browser(session, browser=browser):
                username = test_session(session)
                if username:
                    print(f"\n✅ COOKIES РАБОТАЮТ! Браузер: {browser}, Пользователь: {username}")
                    return session, True
        print("\n❌ Cookies из браузеров не работают")
        return session, False
    except Exception as e:
        logger.error(f"Ошибка проверки cookies: {e}")
        return session, False


def login_undetected_chromedriver(username: str, password: str):
    """Логин через Undetected-ChromeDriver (МЕТОД 1)."""
    print("\n" + "="*80)
    print("ШАГ 2: ЛОГИН ЧЕРЕЗ UNDETECTED-CHROMEDRIVER")
    print("="*80)
    
    try:
        import undetected_chromedriver as uc
        from selenium.webdriver.common.by import By
        from selenium.common.exceptions import NoSuchElementException
        from selenium.webdriver.common.keys import Keys
        
        logger.info("Инициализирую Undetected-ChromeDriver...")
        
        options = uc.ChromeOptions()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        
        # НЕ headless - Instagram лучше работает с видимым браузером
        # options.add_argument('--headless=new')
        
        driver = uc.Chrome(options=options, version_main=None)
        
        try:
            logger.info("Загружаю страницу логина...")
            driver.get('https://www.instagram.com/accounts/login/')
            time.sleep(random.uniform(2, 4))
            
            # Ищем поля
            logger.info("Ищу поля ввода...")
            username_field = None
            password_field = None
            
            # Пробуем разные селекторы
            username_selectors = [
                (By.CSS_SELECTOR, 'input[name="username"]'),
                (By.CSS_SELECTOR, 'input[aria-label*="username" i]'),
                (By.CSS_SELECTOR, 'input[type="text"]'),
            ]
            
            password_selectors = [
                (By.CSS_SELECTOR, 'input[name="password"]'),
                (By.CSS_SELECTOR, 'input[type="password"]'),
            ]
            
            for selector_type, selector_value in username_selectors:
                try:
                    elements = driver.find_elements(selector_type, selector_value)
                    for elem in elements:
                        if elem.is_displayed():
                            username_field = elem
                            logger.info(f"[OK] Найдено поле username: {selector_value}")
                            break
                    if username_field:
                        break
                except:
                    continue
            
            for selector_type, selector_value in password_selectors:
                try:
                    elements = driver.find_elements(selector_type, selector_value)
                    for elem in elements:
                        if elem.is_displayed():
                            password_field = elem
                            logger.info(f"[OK] Найдено поле password: {selector_value}")
                            break
                    if password_field:
                        break
                except:
                    continue
            
            if not username_field or not password_field:
                logger.error("[ERROR] Поля ввода не найдены")
                driver.quit()
                return None
            
            # Вводим данные
            logger.info("Ввожу логин...")
            username_field.clear()
            time.sleep(0.5)
            username_field.send_keys(username)
            time.sleep(1)
            
            logger.info("Ввожу пароль...")
            password_field.clear()
            time.sleep(0.5)
            password_field.send_keys(password)
            time.sleep(1)
            
            # Нажимаем кнопку
            try:
                login_button = driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
                login_button.click()
            except:
                password_field.send_keys(Keys.RETURN)
            
            # Ждем
            logger.info("Ожидаю авторизацию...")
            time.sleep(8)
            
            # Проверяем cookies
            cookies = driver.get_cookies()
            has_sessionid = any(c.get('name') == 'sessionid' for c in cookies)
            
            if has_sessionid:
                logger.info("[OK] Авторизация успешна через Undetected-ChromeDriver!")
                
                # Конвертируем cookies в requests session
                session = requests.Session()
                for cookie in cookies:
                    session.cookies.set(cookie['name'], cookie['value'], domain=cookie.get('domain', '.instagram.com'))
                
                driver.quit()
                return session
            else:
                logger.warning("[WARN] sessionid не найден")
                current_url = driver.current_url
                logger.warning(f"Текущий URL: {current_url}")
                
                # Скриншот
                try:
                    screenshot_path = Path("selenium_cookies") / f"debug_login_{username}.png"
                    screenshot_path.parent.mkdir(exist_ok=True)
                    driver.save_screenshot(str(screenshot_path))
                    logger.warning(f"Скриншот сохранен: {screenshot_path}")
                except:
                    pass
                
                driver.quit()
                return None
                
        except Exception as e:
            logger.error(f"[ERROR] Ошибка Undetected-ChromeDriver: {e}")
            try:
                driver.quit()
            except:
                pass
            return None
            
    except ImportError:
        logger.warning("[WARN] undetected-chromedriver не установлен")
        logger.info("Установите: pip install undetected-chromedriver")
        return None
    except Exception as e:
        logger.error(f"[ERROR] Критическая ошибка: {e}")
        return None


def login_nodriver(username: str, password: str):
    """Логин через Nodriver (МЕТОД 2)."""
    print("\n" + "="*80)
    print("ШАГ 3: ЛОГИН ЧЕРЕЗ NODRIVER")
    print("="*80)
    
    try:
        import nodriver as uc
        import asyncio
        
        logger.info("Инициализирую Nodriver...")
        
        async def login_async():
            try:
                browser = await uc.start(
                    headless=True,
                    browser_args=["--no-sandbox", "--disable-dev-shm-usage"]
                )
                page = await browser.get('https://www.instagram.com/accounts/login/')
                await page.sleep(3)
                
                # Ищем поля
                logger.info("Ищу поля ввода...")
                username_input = None
                password_input = None
                
                username_selectors = [
                    'input[name="username"]',
                    'input[aria-label*="username" i]',
                    'input[type="text"]',
                ]
                
                password_selectors = [
                    'input[name="password"]',
                    'input[type="password"]',
                ]
                
                for selector in username_selectors:
                    try:
                        elements = await page.select_all(selector)
                        for elem in elements:
                            if await elem.is_visible():
                                username_input = elem
                                logger.info(f"[OK] Найдено поле username: {selector}")
                                break
                        if username_input:
                            break
                    except:
                        continue
                
                for selector in password_selectors:
                    try:
                        elements = await page.select_all(selector)
                        for elem in elements:
                            if await elem.is_visible():
                                password_input = elem
                                logger.info(f"[OK] Найдено поле password: {selector}")
                                break
                        if password_input:
                            break
                    except:
                        continue
                
                if not username_input or not password_input:
                    logger.error("[ERROR] Поля ввода не найдены")
                    await browser.stop()
                    return None
                
                # Вводим данные
                logger.info("Ввожу логин...")
                await username_input.clear()
                await page.sleep(0.5)
                await username_input.send_keys(username)
                await page.sleep(1)
                
                logger.info("Ввожу пароль...")
                await password_input.clear()
                await page.sleep(0.5)
                await password_input.send_keys(password)
                await page.sleep(1)
                
                # Нажимаем кнопку
                try:
                    login_button = await page.select('button[type="submit"]')
                    await login_button.click()
                except:
                    await password_input.send_keys(uc.Keys.ENTER)
                
                # Ждем
                logger.info("Ожидаю авторизацию...")
                await page.sleep(6)
                
                # Проверяем cookies
                cookies = []
                try:
                    if hasattr(browser, 'cookies'):
                        cookies = await browser.cookies.get_all() if hasattr(browser.cookies, 'get_all') else []
                    if not cookies and hasattr(page, 'cookies'):
                        cookies = await page.cookies() if callable(getattr(page, 'cookies', None)) else []
                except:
                    pass
                
                if not isinstance(cookies, list):
                    cookies = list(cookies) if cookies else []
                
                has_sessionid = any((c.get('name') if isinstance(c, dict) else getattr(c, 'name', '')) == 'sessionid' for c in cookies)
                
                if has_sessionid:
                    logger.info("[OK] Авторизация успешна через Nodriver!")
                    
                    # Конвертируем cookies в requests session
                    session = requests.Session()
                    for c in cookies:
                        name = c.get('name', getattr(c, 'name', ''))
                        value = c.get('value', getattr(c, 'value', ''))
                        domain = c.get('domain', getattr(c, 'domain', '.instagram.com'))
                        session.cookies.set(name, value, domain=domain)
                    
                    await browser.stop()
                    return session
                else:
                    logger.warning("[WARN] sessionid не найден")
                    current_url = page.url
                    logger.warning(f"Текущий URL: {current_url}")
                    await browser.stop()
                    return None
                    
            except Exception as e:
                logger.error(f"[ERROR] Ошибка Nodriver: {e}")
                try:
                    await browser.stop()
                except:
                    pass
                return None
        
        # Запускаем
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        session = loop.run_until_complete(login_async())
        loop.close()
        
        return session
        
    except ImportError:
        logger.warning("[WARN] nodriver не установлен")
        logger.info("Установите: pip install nodriver")
        return None
    except Exception as e:
        logger.error(f"[ERROR] Критическая ошибка Nodriver: {e}")
        return None


def test_session_works(session: requests.Session) -> bool:
    """Проверить что сессия работает."""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'X-IG-App-ID': '936619743392459',
        }
        
        response = session.get(
            'https://www.instagram.com/api/v1/web/data/shared_data/',
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200 and 'sessionid' in session.cookies:
            logger.info("[OK] Сессия работает!")
            return True
        return False
    except:
        return False


def main():
    print("\n" + "="*80)
    print("БЫСТРАЯ ПРОВЕРКА COOKIES И ЛОГИН ЧЕРЕЗ SELENIUM")
    print("="*80)
    
    # Шаг 1: Проверяем cookies из браузера
    session, cookies_work = test_browser_cookies()
    
    if cookies_work:
        if test_session_works(session):
            print("\n" + "="*80)
            print("✅ ГОТОВО! Cookies работают, можно использовать сессию")
            print("="*80)
            return
    
    # Шаг 2: Если cookies не работают, пробуем логин через Selenium
    username = settings.INSTAGRAM_USERNAME
    password = settings.INSTAGRAM_PASSWORD
    
    if not username or not password:
        print("\n❌ Логин/пароль не указаны в .env")
        print("Добавьте в .env:")
        print("  INSTAGRAM_USERNAME=ваш_логин")
        print("  INSTAGRAM_PASSWORD=ваш_пароль")
        return
    
    print(f"\nПробую логин для: {username}")
    
    # Метод 1: Undetected-ChromeDriver
    session = login_undetected_chromedriver(username, password)
    if session and test_session_works(session):
        print("\n" + "="*80)
        print("✅ ГОТОВО! Авторизация через Undetected-ChromeDriver успешна!")
        print("="*80)
        return
    
    # Метод 2: Nodriver
    session = login_nodriver(username, password)
    if session and test_session_works(session):
        print("\n" + "="*80)
        print("✅ ГОТОВО! Авторизация через Nodriver успешна!")
        print("="*80)
        return
    
    print("\n" + "="*80)
    print("❌ НЕ УДАЛОСЬ АВТОРИЗОВАТЬСЯ")
    print("="*80)
    print("\nВозможные причины:")
    print("1. Instagram блокирует логин с нового браузера")
    print("2. Требуется проверка (checkpoint/challenge)")
    print("3. Неверный логин/пароль")
    print("\nРекомендация:")
    print("Используйте cookies из браузера (закройте браузер и запустите снова)")


if __name__ == '__main__':
    main()
