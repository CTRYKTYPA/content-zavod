"""
Полный автоматический тест всех методов скачивания видео с Instagram.
Запускает все методы последовательно и показывает детальные результаты.
"""
import sys
import time
from pathlib import Path
from loguru import logger

# Настройка логирования
logger.remove()
logger.add(sys.stdout, format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>", level="INFO")

from modules.content_collector.instagram_downloader import (
    download_video_combined,
    download_video_ytdlp,
    download_video_graphql,
    download_video_direct,
    download_video_html_parsing,
    download_video_api_v1,
    download_video_selenium,
    extract_shortcode,
    load_user_agents,
)

def test_method(method_name: str, method_func, url: str, output_path: Path):
    """Тестировать один метод скачивания."""
    logger.info(f"\n{'='*80}")
    logger.info(f"МЕТОД: {method_name}")
    logger.info(f"{'='*80}")
    
    start_time = time.time()
    
    try:
        # Проверяем сигнатуру функции
        import inspect
        sig = inspect.signature(method_func)
        params = list(sig.parameters.keys())
        
        # Вызываем функцию с правильными параметрами
        if len(params) >= 2:
            success = method_func(url, str(output_path))
        else:
            logger.warning(f"Неверная сигнатура функции {method_name}")
            return False, 0, 0
        
        elapsed = time.time() - start_time
        
        if success and output_path.exists():
            file_size = output_path.stat().st_size
            logger.info(f"[SUCCESS] Видео скачано за {elapsed:.2f} сек")
            logger.info(f"Размер файла: {file_size / 1024 / 1024:.2f} MB")
            logger.info(f"Путь: {output_path.absolute()}")
            return True, file_size, elapsed
        else:
            logger.warning(f"[FAIL] Не удалось скачать (время: {elapsed:.2f} сек)")
            if output_path.exists():
                output_path.unlink()
            return False, 0, elapsed
            
    except Exception as e:
        elapsed = time.time() - start_time
        logger.error(f"[ERROR] Ошибка: {str(e)} (время: {elapsed:.2f} сек)")
        if output_path.exists():
            output_path.unlink()
        return False, 0, elapsed

def main():
    print("\n" + "="*80)
    print("ПОЛНЫЙ АВТОМАТИЧЕСКИЙ ТЕСТ СКАЧИВАНИЯ ВИДЕО С INSTAGRAM")
    print("="*80)
    
    # Получаем URL из аргументов
    if len(sys.argv) < 2:
        print("\nИспользование: python run_full_test.py <URL_поста_Instagram>")
        print("Пример: python run_full_test.py https://www.instagram.com/p/ABC123/")
        print("\nДля тестирования нужен URL публичного поста Instagram с видео.")
        sys.exit(1)
    
    test_url = sys.argv[1].strip()
    
    if 'instagram.com' not in test_url:
        logger.error("Неверный URL! Должен содержать instagram.com")
        sys.exit(1)
    
    shortcode = extract_shortcode(test_url)
    if not shortcode:
        logger.error("Не удалось извлечь shortcode из URL!")
        sys.exit(1)
    
    # Проверяем user agents
    user_agents = load_user_agents()
    logger.info(f"Загружено {len(user_agents)} user agents из useragents.txt")
    
    logger.info(f"\nТестируемый URL: {test_url}")
    logger.info(f"Shortcode: {shortcode}")
    
    # Создаем директорию для результатов
    output_dir = Path("test_downloads")
    output_dir.mkdir(exist_ok=True)
    logger.info(f"Результаты будут сохранены в: {output_dir.absolute()}\n")
    
    # Список всех методов
    methods = [
        ("1. yt-dlp (самый надежный)", download_video_ytdlp),
        ("2. GraphQL API", download_video_graphql),
        ("3. Прямые HTTP запросы", download_video_direct),
        ("4. HTML парсинг", download_video_html_parsing),
        ("5. Instagram API v1", download_video_api_v1),
        ("6. Selenium", download_video_selenium),
    ]
    
    results = {}
    total_start = time.time()
    
    # Тестируем каждый метод
    for method_name, method_func in methods:
        output_path = output_dir / f"{shortcode}_{method_name.split('.')[0].strip().replace(' ', '_').lower()}.mp4"
        success, file_size, elapsed = test_method(method_name, method_func, test_url, output_path)
        
        results[method_name] = {
            'success': success,
            'file_size': file_size,
            'elapsed': elapsed,
            'output_path': output_path if success else None
        }
        
        # Небольшая задержка между методами
        if method_name != methods[-1][0]:
            time.sleep(2)
    
    # Тест комбинированного метода
    logger.info(f"\n{'='*80}")
    logger.info("КОМБИНИРОВАННЫЙ МЕТОД (пробует все по очереди до успеха)")
    logger.info(f"{'='*80}")
    
    output_path = output_dir / f"{shortcode}_combined.mp4"
    start_time = time.time()
    try:
        success = download_video_combined(test_url, str(output_path))
        elapsed = time.time() - start_time
        
        if success and output_path.exists():
            file_size = output_path.stat().st_size
            logger.info(f"[SUCCESS] Видео скачано за {elapsed:.2f} сек")
            logger.info(f"Размер файла: {file_size / 1024 / 1024:.2f} MB")
            logger.info(f"Путь: {output_path.absolute()}")
            results['Комбинированный'] = {
                'success': True,
                'file_size': file_size,
                'elapsed': elapsed,
                'output_path': output_path
            }
        else:
            logger.warning(f"[FAIL] Не удалось скачать (время: {elapsed:.2f} сек)")
            results['Комбинированный'] = {
                'success': False,
                'file_size': 0,
                'elapsed': elapsed,
                'output_path': None
            }
    except Exception as e:
        elapsed = time.time() - start_time
        logger.error(f"[ERROR] Ошибка: {str(e)} (время: {elapsed:.2f} сек)")
        results['Комбинированный'] = {
            'success': False,
            'file_size': 0,
            'elapsed': elapsed,
            'output_path': None
        }
    
    # Итоговый отчет
    total_elapsed = time.time() - total_start
    logger.info(f"\n{'='*80}")
    logger.info("ИТОГОВЫЙ ОТЧЕТ")
    logger.info(f"{'='*80}")
    
    successful = [(name, res) for name, res in results.items() if res['success']]
    failed = [(name, res) for name, res in results.items() if not res['success']]
    
    if successful:
        logger.info(f"\n[SUCCESS] Успешные методы ({len(successful)}/{len(results)}):")
        for name, res in successful:
            logger.info(f"  ✓ {name:40s} | {res['file_size'] / 1024 / 1024:6.2f} MB | {res['elapsed']:6.2f} сек")
            if res['output_path']:
                logger.info(f"    Путь: {res['output_path']}")
    
    if failed:
        logger.warning(f"\n[FAIL] Неудачные методы ({len(failed)}/{len(results)}):")
        for name, res in failed:
            logger.warning(f"  ✗ {name:40s} | {res['elapsed']:6.2f} сек")
    
    logger.info(f"\nОбщее время тестирования: {total_elapsed:.2f} сек")
    logger.info(f"Все файлы сохранены в: {output_dir.absolute()}")
    
    if successful:
        logger.info(f"\n✅ ТЕСТИРОВАНИЕ ЗАВЕРШЕНО УСПЕШНО!")
        logger.info(f"Найдено {len(successful)} рабочих метода(ов) для скачивания видео!")
    else:
        logger.error(f"\n❌ ТЕСТИРОВАНИЕ ЗАВЕРШЕНО С ОШИБКАМИ")
        logger.error("Ни один метод не смог скачать видео. Проверьте:")
        logger.error("  1. URL поста правильный и публичный")
        logger.error("  2. Пост содержит видео (не фото)")
        logger.error("  3. VPN/прокси работает корректно")
        logger.error("  4. Интернет соединение стабильно")

if __name__ == '__main__':
    main()
