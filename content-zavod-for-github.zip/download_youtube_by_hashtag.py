#!/usr/bin/env python3
"""
Скачивание видео с YouTube по хэштегам через yt-dlp.

Использует ytsearch — поиск YouTube. Авторизация не нужна.

Примеры:
  python download_youtube_by_hashtag.py "#funny"          # Shorts 10–120 сек
  python download_youtube_by_hashtag.py "#memes" --max 5 -o downloads/memes
  python download_youtube_by_hashtag.py "#viral" --list-only
  python download_youtube_by_hashtag.py "#funny" --no-shorts   # любые видео
  python download_youtube_by_hashtag.py "#funny" --min-duration 15 --max-duration 90
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Корень проекта
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Скачать видео с YouTube по хэштегу (yt-dlp + ytsearch)."
    )
    ap.add_argument(
        "hashtag",
        type=str,
        help='Хэштег для поиска, например "#funny" или "funny"',
    )
    ap.add_argument(
        "-n", "--max",
        type=int,
        default=10,
        help="Максимум видео для скачивания (по умолчанию 10)",
    )
    ap.add_argument(
        "-o", "--output",
        type=Path,
        default=None,
        help="Папка для сохранения (по умолчанию downloads/youtube_hashtag)",
    )
    ap.add_argument(
        "-l", "--list-only",
        action="store_true",
        help="Только вывести список видео (ID, название), не скачивать",
    )
    ap.add_argument(
        "-s", "--search-limit",
        type=int,
        default=20,
        help="Сколько результатов поиска запрашивать у YouTube (по умолчанию 20)",
    )
    ap.add_argument(
        "--proxy",
        type=str,
        default=None,
        help="Прокси (например http://127.0.0.1:7890 или socks5://...)",
    )
    ap.add_argument(
        "--no-shorts",
        action="store_true",
        help="Скачивать любые видео. По умолчанию — только Shorts (10–120 сек).",
    )
    ap.add_argument(
        "--min-duration",
        type=int,
        default=10,
        metavar="SEC",
        help="Мин. длительность Shorts в секундах (по умолчанию 10)",
    )
    ap.add_argument(
        "--max-duration",
        type=int,
        default=120,
        metavar="SEC",
        help="Макс. длительность Shorts в секундах (по умолчанию 120)",
    )
    args = ap.parse_args()
    args.shorts = not args.no_shorts

    query = args.hashtag.strip()
    if not query:
        ap.error("Укажите хэштег.")
    if not query.startswith("#"):
        query = f"#{query}"

    try:
        import yt_dlp
    except ImportError:
        print("Ошибка: yt-dlp не установлен. Выполните: pip install yt-dlp")
        sys.exit(1)

    # ytsearchN: запрос — первые N результатов поиска
    search_limit = args.search_limit
    search_query = query
    if args.shorts:
        search_query = f"{query} shorts"
        if not args.list_only:
            search_limit = max(search_limit, 50)  # больше результатов — много отфильтруется по duration
    ytsearch = f"ytsearch{search_limit}:{search_query}"

    if args.output is None:
        try:
            from config import settings
            out_dir = settings.DOWNLOADS_DIR / "youtube_hashtag"
        except Exception:
            out_dir = ROOT / "downloads" / "youtube_hashtag"
    else:
        out_dir = args.output.resolve()

    out_dir.mkdir(parents=True, exist_ok=True)
    out_tmpl = str(out_dir / "%(title)s [%(id)s].%(ext)s")

    ydl_opts: dict = {
        "quiet": False,
        "no_warnings": False,
        "extract_flat": True if args.list_only else False,
        "noplaylist": True,
        "socket_timeout": 30,
        "retries": 3,
        "format": "best[ext=mp4]/best",
        "outtmpl": out_tmpl,
        # android_sdkless часто даёт простые HTTP-форматы (без n-sig/HLS)
        "extractor_args": {"youtube": {"player_client": ["android_sdkless"]}},
        "ignoreerrors": True,  # при ошибке одного видео — продолжаем со следующим
    }
    if args.proxy:
        ydl_opts["proxy"] = args.proxy
    if args.shorts and not args.list_only:
        # Shorts — 10–120 сек; при list-only длительность неизвестна (flat), фильтр не применяем
        min_d, max_d = args.min_duration, args.max_duration

        def _shorts_only(info, *, incomplete):
            if incomplete:
                return None
            d = info.get("duration")
            if d is None:
                return None
            if min_d <= d <= max_d:
                return None
            if d < min_d:
                return f"Shorter than {min_d}s, skip"
            return f"Longer than {max_d}s, skip"

        ydl_opts["match_filter"] = _shorts_only

    if args.list_only:
        ydl_opts["simulate"] = True
        ydl_opts["print"] = ["%(id)s | %(title)s"]
    else:
        ydl_opts["max_downloads"] = args.max

    print(f"Поиск: {ytsearch}")
    if not args.list_only:
        short_info = f" (Shorts {args.min_duration}-{args.max_duration} сек)" if args.shorts else ""
        print(f"Скачивание в: {out_dir} (макс. {args.max} видео){short_info}")
    print()

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([ytsearch])
    except yt_dlp.utils.MaxDownloadsReached:
        # Достигли --max-downloads — это успех, не ошибка
        sys.exit(0)


if __name__ == "__main__":
    main()
