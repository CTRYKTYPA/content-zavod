"""Простой тест - проверить что всё работает."""
print("🔍 Простая проверка...")

# Проверяем базовые модули без импорта video_processor (который требует moviepy)
try:
    from database import init_db, get_db
except ImportError as e:
    print(f"❌ Ошибка импорта database: {e}")
    print("   Установите зависимости: pip install -r requirements.txt")
    exit(1)

# 1. БД
print("1. База данных...")
try:
    init_db()
    print("   ✅ ОК")
    # Показываем какой тип БД используется
    from config import settings
    if "sqlite" in settings.DATABASE_URL.lower():
        print("   📁 Используется SQLite (файл: content_zavod.db)")
    else:
        print(f"   🐘 Используется PostgreSQL")
except Exception as e:
    print(f"   ❌ {e}")
    if "Connection refused" in str(e) or "5432" in str(e):
        print("   💡 Подсказка: PostgreSQL не запущен или не установлен")
        print("   Используйте SQLite: DATABASE_URL=sqlite:///content_zavod.db")
    exit(1)

# 2. Тематики (без video_processor)
print("2. Тематики...")
try:
    db = next(get_db())
    from database.models import Topic
    topics = db.query(Topic).all()
    print(f"   ✅ Найдено: {len(topics)}")
    db.close()
except Exception as e:
    print(f"   ❌ {e}")
    exit(1)

# 3. Instaloader
print("3. Instaloader...")
try:
    import instaloader
    L = instaloader.Instaloader(quiet=True)
    print("   ✅ ОК")
except Exception as e:
    print(f"   ❌ {e}")
    exit(1)

print("\n✅ Всё работает! Можно запускать: python run.py")
