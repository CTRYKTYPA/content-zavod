# Простой запуск

## Быстрый старт

1. **Установите зависимости:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Создайте `.env` файл:**
   ```bash
   TELEGRAM_BOT_TOKEN=8541245358:AAEkODhnLBVvU5m-Je_LK4r_AUn20Q05Op8
   TELEGRAM_ADMIN_IDS=[465138834]
   DATABASE_URL=postgresql://user:password@localhost:5432/content_zavod
   REDIS_URL=redis://localhost:6379/0
   ```

3. **Проверьте что всё работает:**
   ```bash
   python simple_test.py
   ```

4. **Запустите систему:**
   ```bash
   python run.py
   ```

Всё! Система запущена. Telegram-бот будет работать.

## Что дальше?

- Откройте Telegram и найдите вашего бота
- Используйте команды: `/start`, `/topics`, `/status`
- Добавьте тематики: `python scripts/setup_topics.py`
- Добавьте источники: `python scripts/add_hashtag_sources.py`
