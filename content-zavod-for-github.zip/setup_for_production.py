"""Настройка системы для продакшена - один раз для заказчика."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("=" * 60)
print("НАСТРОЙКА СИСТЕМЫ ДЛЯ ПРОДАКШЕНА")
print("=" * 60)
print("\nЭтот скрипт настроит систему один раз.")
print("После настройки всё будет работать автоматически.\n")

# 1. Проверка зависимостей
print("1. Проверка зависимостей...")
try:
    import browser_cookie3
    print("   OK: browser-cookie3 установлен")
except ImportError:
    print("   Устанавливаю browser-cookie3...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "browser-cookie3"])
    print("   OK: Установлено")

# 2. Настройка Instagram авторизации
print("\n2. Настройка Instagram авторизации...")
print("   Войдите в Instagram через браузер (Chrome/Firefox/Edge)")
print("   Убедитесь что вы залогинены на instagram.com")
print()

input("Нажмите Enter когда будете готовы...")

try:
    import browser_cookie3
    import instaloader
    import requests
    
    print("\n   Ищу сессию в браузерах...")
    
    # Пробуем браузеры
    browsers = [
        ("Chrome", lambda: browser_cookie3.chrome(domain_name="instagram.com")),
        ("Firefox", lambda: browser_cookie3.firefox(domain_name="instagram.com")),
        ("Edge", lambda: browser_cookie3.edge(domain_name="instagram.com")),
    ]
    
    session_imported = False
    
    for browser_name, get_cookies in browsers:
        try:
            cookies = get_cookies()
            if not cookies:
                continue
            
            print(f"   Найдены cookies в {browser_name}, проверяю...")
            
            # Создаём instaloader
            L = instaloader.Instaloader()
            
            # Импортируем cookies
            session = requests.Session()
            for cookie in cookies:
                session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
            
            L.context._session = session
            
            # Проверяем
            username = L.test_login()
            if username:
                print(f"   OK: Сессия работает! Пользователь: {username}")
                
                # Сохраняем
                L.save_session_to_file()
                print(f"   OK: Сессия сохранена для {username}")
                session_imported = True
                break
        
        except Exception as e:
            print(f"   Пропуск {browser_name}: {e}")
            continue
    
    if not session_imported:
        print("\n   Не удалось импортировать сессию автоматически")
        print("   Убедитесь что:")
        print("   - Вы залогинены в браузере на instagram.com")
        print("   - Браузер не закрыт")
        print("\n   Попробуйте запустить: python simple_auth.py")
        exit(1)

except Exception as e:
    print(f"\n   Ошибка: {e}")
    import traceback
    traceback.print_exc()
    exit(1)

# 3. Проверка что всё работает
print("\n3. Проверка работы...")
try:
    from database import init_db
    init_db()
    print("   OK: База данных")
    
    from database import get_db
    from database.models import Topic
    db = next(get_db())
    topics = db.query(Topic).all()
    print(f"   OK: Тематики ({len(topics)} шт)")
    db.close()
    
    print("\n" + "=" * 60)
    print("OK: СИСТЕМА НАСТРОЕНА!")
    print("=" * 60)
    print("\nТеперь можно запускать систему:")
    print("  python run.py")
    print("\nСессия Instagram сохранена и будет использоваться автоматически.")
    print("Больше ничего настраивать не нужно!")
    
except Exception as e:
    print(f"   Ошибка проверки: {e}")
    exit(1)
