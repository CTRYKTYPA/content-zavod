# Быстрая настройка Instagram Graph API (БЕСПЛАТНО)

## 🚀 За 5 минут:

### 1. Создайте приложение (2 минуты)
1. Идите на https://developers.facebook.com/
2. "My Apps" → "Create App"
3. Выберите "Business" или "None"
4. Название любое, Email ваш
5. Добавьте продукт "Instagram Graph API"

### 2. Получите токен (1 минута)
1. Откройте https://developers.facebook.com/tools/explorer/
2. Выберите ваше приложение
3. Разрешения: `instagram_basic`
4. "Generate Access Token" → скопируйте

### 3. Получите User ID (1 минута)
В Graph API Explorer выполните:
```
GET /me?fields=id,name
```
Скопируйте `id` - это ваш User ID

### 4. Добавьте в .env (30 секунд)
```bash
INSTAGRAM_GRAPH_API_TOKEN=ваш_токен_здесь
INSTAGRAM_GRAPH_API_USER_ID=ваш_id_здесь
```

### 5. Готово! 🎉

Запустите:
```bash
python run_thematic_collection.py humor 3
```

## 💡 Совет:

Базовый токен действует 1-2 часа. Для долгосрочного использования получите Long-Lived Token (60 дней):

```
GET /oauth/access_token?grant_type=fb_exchange_token&client_id={app_id}&client_secret={app_secret}&fb_exchange_token={short_token}
```

**ВСЕ БЕСПЛАТНО!** 💰
