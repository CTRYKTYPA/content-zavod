"""
Быстрый тест сбора ссылок через Instagram Graph API.
"""
import sys
from pathlib import Path
from loguru import logger
import io

# Настройка логирования
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
logger.remove()
logger.add(sys.stdout, format="{time:HH:mm:ss} | {level: <8} | {message}", level="INFO")

from modules.content_collector.instagram_graph_api import InstagramGraphAPI
from config import settings
from datetime import datetime

def main():
    print("\n" + "="*80)
    print("ТЕСТ СБОРА ССЫЛОК ЧЕРЕЗ INSTAGRAM GRAPH API")
    print("="*80)
    
    # Проверяем настройки
    if not settings.INSTAGRAM_GRAPH_API_TOKEN:
        print("❌ INSTAGRAM_GRAPH_API_TOKEN не указан в .env")
        return
    
    if not settings.INSTAGRAM_GRAPH_API_USER_ID:
        print("❌ INSTAGRAM_GRAPH_API_USER_ID не указан в .env")
        return
    
    print(f"\n✅ Токен: {settings.INSTAGRAM_GRAPH_API_TOKEN[:30]}...")
    print(f"✅ User ID: {settings.INSTAGRAM_GRAPH_API_USER_ID}")
    
    # Создаем API клиент
    api = InstagramGraphAPI()
    
    # Проверяем информацию о пользователе
    print("\n" + "-"*80)
    print("Проверка токена...")
    print("-"*80)
    user_info = api.get_user_info()
    if user_info:
        print(f"✅ Токен работает!")
        print(f"   Username: {user_info.get('username', 'N/A')}")
        print(f"   Account Type: {user_info.get('account_type', 'N/A')}")
    else:
        print("❌ Токен не работает")
        return
    
    # Проверяем тип токена
    is_facebook_token = api.access_token.startswith('EAA')
    is_instagram_token = api.access_token.startswith('IGAAT') or api.access_token.startswith('IG')
    
    if is_instagram_token:
        print("\n" + "-"*80)
        print("⚠️  Обнаружен Instagram токен (IGAAT...)")
        print("-"*80)
        print("Instagram токены НЕ поддерживают поиск по хэштегам.")
        print("\nАльтернатива: Получение постов вашего пользователя...")
        print("-"*80)
        
        # Пробуем получить посты пользователя (работает с Instagram токенами)
        user_posts = api.get_user_media_urls(limit=10)
        
        if user_posts:
            print(f"\n✅ УСПЕХ! Найдено {len(user_posts)} ссылок на посты пользователя:")
            for i, url in enumerate(user_posts[:5], 1):
                print(f"  {i}. {url}")
            if len(user_posts) > 5:
                print(f"  ... и еще {len(user_posts) - 5} ссылок")
            
            # Сохраняем в файл
            links_file = Path("instagram_links") / f"test_user_media_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            links_file.parent.mkdir(exist_ok=True)
            with open(links_file, 'w', encoding='utf-8') as f:
                for url in user_posts:
                    f.write(f"{url}\n")
            print(f"\n✅ Ссылки сохранены в файл: {links_file}")
        else:
            print("\n❌ Не удалось получить посты пользователя")
        
        print("\n" + "="*80)
        print("ДЛЯ ПОИСКА ПО ХЭШТЕГАМ НУЖЕН FACEBOOK ТОКЕН!")
        print("="*80)
        print("См. инструкцию: HOW_TO_GET_FACEBOOK_TOKEN.md")
        print("="*80)
    else:
        # Пробуем собрать ссылки по хэштегу (только для Facebook токенов)
        print("\n" + "-"*80)
        print("Попытка собрать ссылки по хэштегу #funnyvideos...")
        print("-"*80)
        
        hashtag = "funnyvideos"
        post_urls = api.get_hashtag_posts(hashtag, limit=10)
        
        if post_urls:
            print(f"\n✅ УСПЕХ! Найдено {len(post_urls)} ссылок:")
            for i, url in enumerate(post_urls[:5], 1):
                print(f"  {i}. {url}")
            if len(post_urls) > 5:
                print(f"  ... и еще {len(post_urls) - 5} ссылок")
            
            # Сохраняем в файл
            links_file = Path("instagram_links") / f"test_graph_api_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            links_file.parent.mkdir(exist_ok=True)
            with open(links_file, 'w', encoding='utf-8') as f:
                for url in post_urls:
                    f.write(f"{url}\n")
            print(f"\n✅ Ссылки сохранены в файл: {links_file}")
        else:
            print("\n❌ Не удалось собрать ссылки")
            print("\nВозможные причины:")
            print("  1. Требуется App Review для 'Instagram Public Content Access'")
            print("  2. Токен не имеет разрешения 'instagram_basic' или 'pages_read_engagement'")
            print("  3. Instagram Business Account не связан с Facebook Page")
            print("  4. Превышен лимит: максимум 30 уникальных хэштегов за 7 дней")
    
    print("\n" + "="*80)

if __name__ == '__main__':
    main()
