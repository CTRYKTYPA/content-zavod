"""Конфигурация системы."""
import os
from pathlib import Path
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Настройки приложения."""
    
    # База данных
    # По умолчанию SQLite (не требует установки PostgreSQL)
    # Для PostgreSQL используйте: postgresql://user:password@localhost:5432/content_zavod
    DATABASE_URL: str = "sqlite:///content_zavod.db"
    
    # Redis для очередей
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # Telegram Bot
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    # JSON-массив ID, например [123456789] или [123,456]. Через .env: TELEGRAM_ADMIN_IDS=[123456789]
    TELEGRAM_ADMIN_IDS: list[int] = []
    
    # Instagram
    INSTAGRAM_USERNAME: Optional[str] = None
    INSTAGRAM_PASSWORD: Optional[str] = None
    # Второй аккаунт Instagram (для ротации и fallback)
    INSTAGRAM_USERNAME_2: Optional[str] = None
    INSTAGRAM_PASSWORD_2: Optional[str] = None
    # Instagram Graph API (из Graph API Explorer)
    INSTAGRAM_GRAPH_API_TOKEN: Optional[str] = None
    INSTAGRAM_GRAPH_API_USER_ID: Optional[str] = None  # ID вашего Instagram аккаунта
    # Instagram Graph API App Credentials (для генерации/обмена токенов)
    INSTAGRAM_GRAPH_API_APP_ID: Optional[str] = None  # App ID из Facebook Developer
    INSTAGRAM_GRAPH_API_APP_SECRET: Optional[str] = None  # App Secret из Facebook Developer
    # Headless режим для авторизации (по умолчанию False - Instagram лучше работает с окном)
    # Для сервера без дисплея установите INSTAGRAM_HEADLESS=1
    INSTAGRAM_HEADLESS: str = "0"  # "0" = False (окно), "1" = True (headless)
    
    # Proxy/VPN для Instagram (опционально)
    # Формат: http://user:pass@host:port или http://host:port
    # Или socks5://user:pass@host:port для SOCKS5
    # Можно указать несколько через запятую для ротации
    INSTAGRAM_PROXY: Optional[str] = None
    YOUTUBE_PROXY: Optional[str] = None  # иначе используется INSTAGRAM_PROXY
    TIKTOK_PROXY: Optional[str] = None   # иначе YOUTUBE_PROXY / INSTAGRAM_PROXY
    # TikTok: без API, только yt-dlp. Куки сильно повышают шанс успеха.
    # Файл куков (Netscape): Chrome DevTools → Application → Cookies → tiktok.com → экспорт.
    TIKTOK_COOKIES_FILE: Optional[str] = None
    # Или куки из браузера: "chrome", "firefox", "edge". Залогиньтесь на tiktok.com перед запуском.
    TIKTOK_COOKIES_FROM_BROWSER: Optional[str] = None
    # Опционально: app_info для mobile API (хэштеги). Формат: iid/app_name/app_version/manifest/aid через запятую.
    # Оставьте пустым, если собираете только по users (web API).
    TIKTOK_EXTRACTOR_APP_INFO: Optional[str] = None
    TIKTOK_EXTRACTOR_DEVICE_ID: Optional[str] = None
    # YouTube Data API v3: поиск и метаданные (API key). Загрузка видео — OAuth.
    YOUTUBE_API_KEY: Optional[str] = None
    YOUTUBE_CLIENT_ID: Optional[str] = None
    YOUTUBE_CLIENT_SECRET: Optional[str] = None
    YOUTUBE_REFRESH_TOKEN: Optional[str] = None
    # Подсказка языка для поиска Shorts (меньше арабского/другого): "russian", "english" или ""
    YOUTUBE_SEARCH_LANG_HINT: str = "russian"

    # Ротация прокси (если указано несколько)
    ROTATE_PROXIES: bool = True
    
    # Список прокси для ротации (если не указан INSTAGRAM_PROXY)
    PROXY_LIST: list[str] = []
    
    # Пути
    BASE_DIR: Path = Path(__file__).parent
    DOWNLOADS_DIR: Path = BASE_DIR / "downloads"
    PROCESSED_DIR: Path = BASE_DIR / "processed"
    LOGS_DIR: Path = BASE_DIR / "logs"
    
    # Обработка видео
    VIDEO_MAX_DURATION: int = 300  # секунд (увеличено, т.к. длительность не важна)
    VIDEO_MIN_DURATION: int = 0   # секунд (убрано ограничение)
    VIDEO_TARGET_RESOLUTION: tuple[int, int] = (1080, 1920)  # 9:16 формат
    
    # Фильтры по умолчанию для сбора контента
    DEFAULT_MIN_VIEWS: int = 1000000  # 1 млн просмотров
    DEFAULT_MIN_LIKES: int = 10000    # 10к лайков
    
    # Публикация
    MAX_POSTS_PER_DAY: int = 5
    DEFAULT_TIMEZONE: str = "Europe/Moscow"

    # Текст на бейдже (ник аккаунта, напр. Rise_motivation.7). Через .env: BRANDING_DEFAULT_TEXT=Rise_motivation.7
    BRANDING_DEFAULT_TEXT: str = "Rise_motivation.7"

    # Автопоиск и затирка водяных знаков (при брендировании)
    # Доля кадра на угол: 0.06–0.12, например 0.08 = 8%
    WATERMARK_ROI_PERCENT: float = 0.08
    # Какие углы сканировать: "all" (все 4) | "bottom_right" (только правый нижний)
    WATERMARK_CORNERS: str = "all"
    # Fallback-затирка в правом нижнем углу, если ничего не найдено (чтобы плашка легла на чистое)
    WATERMARK_FALLBACK_BOTTOM_RIGHT: bool = True

    # Логирование
    LOG_LEVEL: str = "INFO"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


# Создаем директории при импорте
settings = Settings()
settings.DOWNLOADS_DIR.mkdir(exist_ok=True)
settings.PROCESSED_DIR.mkdir(exist_ok=True)
settings.LOGS_DIR.mkdir(exist_ok=True)
