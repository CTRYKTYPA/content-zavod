# Как получить Facebook User Access Token для Instagram Graph API

## ⚠️ ПРОБЛЕМА

У вас есть **Instagram токен (IGAAT...)**, который:
- ✅ Работает для получения информации о пользователе
- ✅ Работает для публикации контента
- ❌ **НЕ работает** для поиска по хэштегам (hashtag search)

Для поиска по хэштегам нужен **Facebook User Access Token (EAA...)**.

## 🔑 Решение: Получить Facebook Token

### Способ 1: Через Facebook Graph API Explorer (Быстрый способ для тестирования)

1. Перейдите на [Graph API Explorer](https://developers.facebook.com/tools/explorer/)
2. Выберите ваше приложение в выпадающем списке
3. Нажмите "Get Token" → "Get User Access Token"
4. Выберите разрешения:
   - `instagram_basic`
   - `pages_read_engagement` (если нужно)
   - `pages_show_list` (если нужно)
5. Нажмите "Generate Access Token"
6. Авторизуйтесь через Facebook
7. Скопируйте токен (начинается с `EAA...`)

### Способ 2: Через Facebook Login в вашем приложении (Рекомендуется)

#### Шаг 1: Настройте Facebook Login

1. В [Facebook Developer Console](https://developers.facebook.com/apps/) выберите ваше приложение
2. Перейдите в **Settings** → **Basic**
3. Добавьте **Valid OAuth Redirect URIs**:
   ```
   http://localhost:8000/auth/facebook/callback
   https://yourdomain.com/auth/facebook/callback
   ```

#### Шаг 2: Создайте скрипт для получения токена

Создайте файл `get_facebook_token.py`:

```python
"""
Скрипт для получения Facebook User Access Token через OAuth.
"""
import requests
from urllib.parse import urlencode

# Настройки из Facebook Developer Console
APP_ID = "YOUR_APP_ID"  # Замените на ваш App ID
APP_SECRET = "YOUR_APP_SECRET"  # Замените на ваш App Secret
REDIRECT_URI = "http://localhost:8000/auth/facebook/callback"  # Или ваш URL

# Разрешения для Instagram Graph API
SCOPES = [
    "instagram_basic",
    "pages_read_engagement",
    "pages_show_list"
]

def get_authorization_url():
    """Получить URL для авторизации."""
    params = {
        "client_id": APP_ID,
        "redirect_uri": REDIRECT_URI,
        "scope": ",".join(SCOPES),
        "response_type": "code"
    }
    
    url = f"https://www.facebook.com/v24.0/dialog/oauth?{urlencode(params)}"
    return url

def exchange_code_for_token(code):
    """Обменять код авторизации на токен."""
    url = "https://graph.facebook.com/v24.0/oauth/access_token"
    params = {
        "client_id": APP_ID,
        "client_secret": APP_SECRET,
        "redirect_uri": REDIRECT_URI,
        "code": code
    }
    
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        return data.get("access_token")
    else:
        print(f"Ошибка: {response.text}")
        return None

def exchange_for_long_lived_token(short_token):
    """Обменять короткоживущий токен на долгоживущий (60 дней)."""
    url = "https://graph.facebook.com/v24.0/oauth/access_token"
    params = {
        "grant_type": "fb_exchange_token",
        "client_id": APP_ID,
        "client_secret": APP_SECRET,
        "fb_exchange_token": short_token
    }
    
    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        return data.get("access_token")
    else:
        print(f"Ошибка: {response.text}")
        return None

if __name__ == "__main__":
    print("=" * 80)
    print("ПОЛУЧЕНИЕ FACEBOOK USER ACCESS TOKEN")
    print("=" * 80)
    print("\n1. Откройте этот URL в браузере:")
    print(get_authorization_url())
    print("\n2. Авторизуйтесь и скопируйте код из redirect URL")
    print("   (параметр 'code' в URL)")
    print("\n3. Введите код:")
    
    code = input("Код: ").strip()
    
    print("\n4. Обмениваю код на токен...")
    token = exchange_code_for_token(code)
    
    if token:
        print(f"\n✅ Короткоживущий токен получен: {token[:30]}...")
        print("\n5. Обмениваю на долгоживущий токен (60 дней)...")
        long_token = exchange_for_long_lived_token(token)
        
        if long_token:
            print(f"\n✅ Долгоживущий токен получен: {long_token[:30]}...")
            print("\n" + "=" * 80)
            print("ДОБАВЬТЕ В .env:")
            print("=" * 80)
            print(f"INSTAGRAM_GRAPH_API_TOKEN={long_token}")
            print("=" * 80)
        else:
            print("\n❌ Не удалось получить долгоживущий токен")
    else:
        print("\n❌ Не удалось получить токен")
```

### Способ 3: Через веб-приложение (Flask/FastAPI)

Пример для Flask:

```python
from flask import Flask, redirect, request
import requests

app = Flask(__name__)

APP_ID = "YOUR_APP_ID"
APP_SECRET = "YOUR_APP_SECRET"
REDIRECT_URI = "http://localhost:5000/callback"

@app.route('/auth/facebook')
def facebook_login():
    """Начать авторизацию через Facebook."""
    url = f"https://www.facebook.com/v24.0/dialog/oauth"
    params = {
        "client_id": APP_ID,
        "redirect_uri": REDIRECT_URI,
        "scope": "instagram_basic,pages_read_engagement",
        "response_type": "code"
    }
    auth_url = f"{url}?{urlencode(params)}"
    return redirect(auth_url)

@app.route('/callback')
def callback():
    """Обработка callback от Facebook."""
    code = request.args.get('code')
    
    # Обменять код на токен
    token_url = "https://graph.facebook.com/v24.0/oauth/access_token"
    params = {
        "client_id": APP_ID,
        "client_secret": APP_SECRET,
        "redirect_uri": REDIRECT_URI,
        "code": code
    }
    
    response = requests.get(token_url, params=params)
    if response.status_code == 200:
        data = response.json()
        token = data.get("access_token")
        return f"Токен: {token}"
    else:
        return f"Ошибка: {response.text}"

if __name__ == '__main__':
    app.run(port=5000)
```

## 📝 После получения токена

1. Добавьте токен в `.env`:
   ```
   INSTAGRAM_GRAPH_API_TOKEN=EAA...ваш_токен...
   ```

2. Убедитесь, что у вас есть:
   - ✅ App Review для `Instagram Public Content Access`
   - ✅ Разрешение `instagram_basic`
   - ✅ Instagram Business Account связан с Facebook Page

3. Проверьте работу:
   ```bash
   python test_graph_api_links.py
   ```

## 🔗 Полезные ссылки

- [Facebook Login Documentation](https://developers.facebook.com/docs/facebook-login/)
- [Access Tokens Guide](https://developers.facebook.com/docs/facebook-login/guides/access-tokens/)
- [Graph API Explorer](https://developers.facebook.com/tools/explorer/)
- [App Review Guide](https://developers.facebook.com/docs/app-review)

## ⚠️ Важно

- **Короткоживущие токены** истекают через 1-2 часа
- **Долгоживущие токены** истекают через 60 дней
- Для production используйте автоматическое обновление токенов
- Храните токены в безопасном месте (не коммитьте в Git!)
