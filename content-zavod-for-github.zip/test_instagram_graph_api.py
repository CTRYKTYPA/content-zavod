"""
Тестовый скрипт для проверки Instagram Graph API модуля.
"""
import sys
from pathlib import Path
from loguru import logger

# Настройка логирования и кодировки для Windows
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
logger.remove()
logger.add(sys.stdout, format="{time:HH:mm:ss} | {level: <8} | {message}", level="INFO")

from modules.content_collector.instagram_graph_api import InstagramGraphAPI
from config import settings


def test_basic_info():
    """Тест 1: Проверка базовой информации."""
    print("\n" + "="*80)
    print("ТЕСТ 1: Проверка базовой информации")
    print("="*80)
    
    api = InstagramGraphAPI()
    
    print(f"Access Token: {'Указан' if api.access_token else 'НЕ указан'}")
    print(f"User ID: {api.user_id or 'НЕ указан'}")
    print(f"App ID: {api.app_id or 'НЕ указан'}")
    print(f"App Secret: {'Указан' if api.app_secret else 'НЕ указан'}")
    
    if not api.access_token:
        print("\n⚠️  Access Token не указан! Добавьте INSTAGRAM_GRAPH_API_TOKEN в .env")
        return False
    
    if not api.user_id:
        print("\n⚠️  User ID не указан! Добавьте INSTAGRAM_GRAPH_API_USER_ID в .env")
        return False
    
    print("\n✅ Базовая информация проверена")
    return True


def test_token_validation():
    """Тест 2: Проверка валидности токена."""
    print("\n" + "="*80)
    print("ТЕСТ 2: Проверка валидности токена")
    print("="*80)
    
    api = InstagramGraphAPI()
    
    if not api.access_token:
        print("⚠️  Пропускаю тест: Access Token не указан")
        return False
    
    # Сначала проверяем, работает ли токен через получение информации о пользователе
    user_info = api.get_user_info()
    if user_info:
        print("✅ Токен работает (успешно получена информация о пользователе)")
        print(f"   Username: {user_info.get('username', 'N/A')}")
        print(f"   Account Type: {user_info.get('account_type', 'N/A')}")
    
    # Пробуем debug_token (требует app access token)
    token_info = api.debug_token()
    
    if token_info:
        print("\nИнформация о токене (через debug_token):")
        data = token_info.get('data', {})
        print(f"  App ID: {data.get('app_id', 'N/A')}")
        print(f"  User ID: {data.get('user_id', 'N/A')}")
        print(f"  Тип: {data.get('type', 'N/A')}")
        print(f"  Валиден: {data.get('is_valid', False)}")
        print(f"  Истекает: {data.get('expires_at', 'N/A')}")
        print("\n✅ Токен валиден (полная проверка)")
        return True
    elif user_info:
        print("\n⚠️  debug_token недоступен (требует app access token)")
        print("✅ Но токен работает (информация о пользователе получена)")
        return True  # Считаем успешным, если токен работает
    else:
        print("\n❌ Токен невалиден или ошибка проверки")
        return False


def test_user_info():
    """Тест 3: Получение информации о пользователе."""
    print("\n" + "="*80)
    print("ТЕСТ 3: Получение информации о пользователе")
    print("="*80)
    
    api = InstagramGraphAPI()
    
    if not api.user_id:
        print("⚠️  Пропускаю тест: User ID не указан")
        return False
    
    user_info = api.get_user_info()
    
    if user_info:
        print("\nИнформация о пользователе:")
        print(f"  ID: {user_info.get('id', 'N/A')}")
        print(f"  Username: {user_info.get('username', 'N/A')}")
        print(f"  Тип аккаунта: {user_info.get('account_type', 'N/A')}")
        print("\n✅ Информация о пользователе получена")
        return True
    else:
        print("\n❌ Не удалось получить информацию о пользователе")
        return False


def test_hashtag_search():
    """Тест 4: Поиск хэштега."""
    print("\n" + "="*80)
    print("ТЕСТ 4: Поиск хэштега")
    print("="*80)
    
    api = InstagramGraphAPI()
    
    if not api.user_id:
        print("⚠️  Пропускаю тест: User ID не указан")
        return False
    
    # Тестируем на популярном хэштеге
    test_hashtag = "funnyvideos"
    print(f"Ищу хэштег: #{test_hashtag}")
    
    hashtag_id = api.search_hashtag(test_hashtag)
    
    if hashtag_id:
        print(f"\n✅ Найден ID хэштега: {hashtag_id}")
        return True
    else:
        print("\n❌ Не удалось найти хэштег")
        print("   Возможные причины:")
        print("   - Требуется App Review для 'Instagram Public Content Access'")
        print("   - Недостаточно разрешений")
        print("   - Хэштег не существует")
        return False


def test_get_posts():
    """Тест 5: Получение постов по хэштегу."""
    print("\n" + "="*80)
    print("ТЕСТ 5: Получение постов по хэштегу")
    print("="*80)
    
    api = InstagramGraphAPI()
    
    if not api.user_id:
        print("⚠️  Пропускаю тест: User ID не указан")
        return False
    
    test_hashtag = "funnyvideos"
    print(f"Получаю посты для хэштега: #{test_hashtag}")
    
    post_urls = api.get_hashtag_posts(test_hashtag, limit=10)
    
    if post_urls:
        print(f"\n✅ Найдено {len(post_urls)} ссылок:")
        for i, url in enumerate(post_urls[:5], 1):
            print(f"  {i}. {url}")
        if len(post_urls) > 5:
            print(f"  ... и еще {len(post_urls) - 5} ссылок")
        return True
    else:
        print("\n❌ Не удалось получить посты")
        return False


def test_token_exchange():
    """Тест 6: Обмен токена (опционально)."""
    print("\n" + "="*80)
    print("ТЕСТ 6: Обмен токена на долгоживущий")
    print("="*80)
    
    api = InstagramGraphAPI()
    
    if not api.app_secret:
        print("⚠️  Пропускаю тест: App Secret не указан")
        return False
    
    if not api.access_token:
        print("⚠️  Пропускаю тест: Access Token не указан")
        return False
    
    print("Попытка обмена токена...")
    print("(Если токен уже долгоживущий, обмен не требуется)")
    
    long_lived_token = api.exchange_token()
    
    if long_lived_token:
        print(f"\n✅ Токен обменян успешно!")
        print(f"   Новый токен: {long_lived_token[:30]}...")
        print("\n⚠️  ВАЖНО: Сохраните новый токен в .env как INSTAGRAM_GRAPH_API_TOKEN")
        return True
    else:
        # Проверяем, работает ли текущий токен
        user_info = api.get_user_info()
        if user_info:
            print("\n⚠️  Обмен токена не удался, но текущий токен работает")
            print("   Возможные причины:")
            print("   - Токен уже долгоживущий (60 дней) - это нормально")
            print("   - Неверный App Secret")
            print("   - Токен не является короткоживущим")
            print("\n✅ Токен работает, обмен не требуется")
            return True  # Считаем успешным, если токен работает
        else:
            print("\n❌ Не удалось обменять токен и токен не работает")
            return False


def main():
    """Запуск всех тестов."""
    print("\n" + "="*80)
    print("ТЕСТИРОВАНИЕ INSTAGRAM GRAPH API МОДУЛЯ")
    print("="*80)
    
    results = []
    
    # Тест 1: Базовая информация
    results.append(("Базовая информация", test_basic_info()))
    
    # Тест 2: Проверка токена
    results.append(("Проверка токена", test_token_validation()))
    
    # Тест 3: Информация о пользователе
    results.append(("Информация о пользователе", test_user_info()))
    
    # Тест 4: Поиск хэштега
    results.append(("Поиск хэштега", test_hashtag_search()))
    
    # Тест 5: Получение постов
    results.append(("Получение постов", test_get_posts()))
    
    # Тест 6: Обмен токена (опционально)
    results.append(("Обмен токена", test_token_exchange()))
    
    # Итоговый отчет
    print("\n" + "="*80)
    print("ИТОГОВЫЙ ОТЧЕТ")
    print("="*80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    print(f"\nПройдено тестов: {passed}/{total}")
    print("\nДетали:")
    for name, result in results:
        status = "✅ ПРОЙДЕН" if result else "❌ ПРОВАЛЕН"
        print(f"  {status}: {name}")
    
    if passed == total:
        print("\n🎉 Все тесты пройдены!")
    else:
        print("\n⚠️  Некоторые тесты провалены. Проверьте настройки в .env")
    
    print("="*80 + "\n")


if __name__ == '__main__':
    main()
