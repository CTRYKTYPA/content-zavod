"""Тест системы без прокси - используя только VPN на компьютере."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("=" * 60)
print("ТЕСТ БЕЗ ПРОКСИ (С VPN НА КОМПЬЮТЕРЕ)")
print("=" * 60)

print("\nЭтот способ БЕСПЛАТНЫЙ если у вас уже есть VPN!")
print("\nИнструкция:")
print("1. Включите VPN на компьютере")
print("2. Выберите сервер в другой стране (Польша, Германия, США)")
print("3. Запустите этот скрипт")
print()

print("(Жду 2 секунды для проверки VPN...)")
import time
time.sleep(2)

from config import settings
import instaloader

username = settings.INSTAGRAM_USERNAME
password = settings.INSTAGRAM_PASSWORD

if not username:
    print("Ошибка: INSTAGRAM_USERNAME не указан в .env")
    exit(1)

print("\nПробую войти в Instagram через VPN...")

try:
    # Используем мобильный User-Agent
    mobile_user_agent = "Instagram 219.0.0.12.117 Android (29/10; 480dpi; 1080x2134; samsung; SM-G973F; beyond1; exynos9820; en_US; 314665256)"
    L = instaloader.Instaloader(user_agent=mobile_user_agent)
    
    device_id = str(abs(hash(username)))[:16]
    L.context._session.headers.update({
        'X-IG-App-ID': '567067343352427',
        'X-IG-Device-ID': f'android-{device_id}',
        'X-IG-Android-ID': f'android-{device_id}',
    })
    
    print("Вхожу автоматически...")
    L.login(username, password)
    
    print("OK: Успешный вход!")
    L.save_session_to_file()
    print("OK: Сессия сохранена!")
    
    test_user = L.test_login()
    if test_user:
        print(f"OK: Подтверждено! Пользователь: {test_user}")
        print("\nСистема работает БЕЗ прокси!")
        print("Просто используйте VPN при каждом запуске.")
    
except Exception as e:
    error_msg = str(e)
    print(f"Ошибка: {error_msg}")
    
    if "Wrong password" in error_msg:
        print("\nInstagram временно блокирует вход.")
        print("\nРешения:")
        print("1. Подождите 2-4 часа и попробуйте снова")
        print("2. Попробуйте другой сервер VPN")
        print("3. Или используйте резидентные прокси (но это платно)")
    elif "Checkpoint" in error_msg:
        print("\nТребуется checkpoint.")
        print("Подтвердите через телефон или браузер.")
    else:
        print("\nПопробуйте:")
        print("1. Другой сервер VPN")
        print("2. Подождать несколько часов")
        print("3. Или использовать резидентные прокси")
