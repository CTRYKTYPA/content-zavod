"""Показать все скачанные видео из папки test_downloads."""
from pathlib import Path
import sys

try:
    downloads_dir = Path("test_downloads")
    
    if not downloads_dir.exists():
        print(f"Папка {downloads_dir.absolute()} не существует!")
        print("Сначала запустите тест скачивания.")
        sys.exit(1)
    
    print("="*70)
    print("СКАЧАННЫЕ ВИДЕО С INSTAGRAM")
    print("="*70)
    print(f"\nПапка: {downloads_dir.absolute()}\n")
    
    # Ищем все видео файлы
    video_files = list(downloads_dir.glob("*.mp4"))
    
    if not video_files:
        print("Видео файлы не найдены.")
        sys.exit(0)
    
    print(f"Найдено видео файлов: {len(video_files)}\n")
    print("-"*70)
    
    total_size = 0
    for i, video_file in enumerate(video_files, 1):
        try:
            file_size = video_file.stat().st_size
            total_size += file_size
            size_mb = file_size / 1024 / 1024
            
            print(f"{i}. {video_file.name}")
            print(f"   Размер: {size_mb:.2f} MB")
            print(f"   Путь: {video_file.absolute()}")
            print("-"*70)
        except Exception as e:
            print(f"Ошибка при чтении {video_file.name}: {e}")
    
    print(f"\nОбщий размер: {total_size / 1024 / 1024:.2f} MB")
    print(f"\nЧтобы открыть папку в Проводнике:")
    print(f'explorer "{downloads_dir.absolute()}"')
    
except Exception as e:
    print(f"Ошибка: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
