"""
Тест автоматической расшифровки cookies из Яндекс браузера.
"""
import sys
import io
import requests

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

print("="*80)
print("ТЕСТ АВТОМАТИЧЕСКОЙ РАСШИФРОВКИ COOKIES")
print("="*80)

from modules.thematic_collectors.yandex_cookies_decrypt import get_yandex_cookies_from_db

session = requests.Session()
result = get_yandex_cookies_from_db(session)

print("\n" + "="*80)
print(f"РЕЗУЛЬТАТ: {result}")
print(f"sessionid в cookies: {'sessionid' in session.cookies}")
if 'sessionid' in session.cookies:
    print("✅✅✅ УСПЕХ! Cookies готовы к использованию!")
else:
    print("❌ sessionid не найден")
print("="*80)
