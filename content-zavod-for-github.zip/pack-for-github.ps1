# Pack archive for GitHub (no .env, cache, venv, etc.)
$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
$zipName = "content-zavod-for-github.zip"
$tempDir = Join-Path $env:TEMP "content-zavod-pack-$(Get-Random)"

$excludeDirs = @(
    '.git', '.venv', 'venv', 'env', 'ENV', '__pycache__', '.vscode', '.idea',
    'node_modules', 'downloads', 'processed', 'logs', 'mcps', 'assets',
    'selenium_cookies', 'test_downloads'
)
$excludeFiles = @(
    '.env', '.env.local', '*.db', '*.sqlite', '*.pyc', '*.pyo', '*.log',
    'session-*', 'client_secret*.json', 'client_secrets.json',
    '*_TEMP_MPY_*', '*.part', '.DS_Store', 'Thumbs.db', $zipName,
    'cookies.txt', '*cookies*.txt', '*.cookies', 'tiktok_cookies*.txt',
    'credentials*.json', 'token*.json', '*.token'
)

New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

Get-ChildItem -Path $root -Force | Where-Object {
    $name = $_.Name
    if ($_.PSIsContainer) {
        $exclude = $excludeDirs | Where-Object { $name -like $_ }
        -not $exclude
    } else {
        $exclude = $excludeFiles | Where-Object { $name -like $_ }
        -not $exclude
    }
} | ForEach-Object {
    $dest = Join-Path $tempDir $_.Name
    if ($_.PSIsContainer) {
        Copy-Item -Path $_.FullName -Destination $dest -Recurse -Force
    } else {
        Copy-Item -Path $_.FullName -Destination $dest -Force
    }
}

# Clean nested __pycache__, .env from copy
Get-ChildItem -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue | Where-Object {
    ($_.PSIsContainer -and $_.Name -in @('__pycache__','.git','venv','.venv','node_modules')) -or
    ($_.Name -eq '.env')
} | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue

$zipPath = Join-Path $root $zipName
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path "$tempDir\*" -DestinationPath $zipPath
Remove-Item $tempDir -Recurse -Force

Write-Host "Done: $zipPath"
Write-Host "Size MB: $([math]::Round((Get-Item $zipPath).Length / 1MB, 2))"
