Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Установка зависимостей для Content Zavod" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Шаг 1: Создание виртуального окружения..." -ForegroundColor Yellow
python -m venv venv
if ($LASTEXITCODE -ne 0) {
    Write-Host "Ошибка создания виртуального окружения!" -ForegroundColor Red
    pause
    exit 1
}
Write-Host "OK" -ForegroundColor Green

Write-Host ""
Write-Host "Шаг 2: Активация виртуального окружения..." -ForegroundColor Yellow
& .\venv\Scripts\Activate.ps1
if ($LASTEXITCODE -ne 0) {
    Write-Host "Ошибка активации виртуального окружения!" -ForegroundColor Red
    Write-Host "Попробуйте выполнить:" -ForegroundColor Yellow
    Write-Host "Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser" -ForegroundColor Yellow
    pause
    exit 1
}
Write-Host "OK" -ForegroundColor Green

Write-Host ""
Write-Host "Шаг 3: Обновление pip..." -ForegroundColor Yellow
python -m pip install --upgrade pip
Write-Host "OK" -ForegroundColor Green

Write-Host ""
Write-Host "Шаг 4: Установка зависимостей..." -ForegroundColor Yellow
Write-Host "Это может занять несколько минут..." -ForegroundColor Gray
pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) {
    Write-Host "Ошибка установки зависимостей!" -ForegroundColor Red
    pause
    exit 1
}
Write-Host "OK" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Установка завершена!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Теперь активируйте виртуальное окружение:" -ForegroundColor Yellow
Write-Host "  .\venv\Scripts\Activate.ps1" -ForegroundColor White
Write-Host ""
Write-Host "И запустите проверку:" -ForegroundColor Yellow
Write-Host "  python simple_test.py" -ForegroundColor White
Write-Host ""
pause
