"""
Тест browser_cookie3 с Яндекс браузером (когда браузер ЗАКРЫТ).
"""
import sys
import io
import requests
import os
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

print("="*80)
print("ТЕСТ BROWSER_COOKIE3 С ЯНДЕКС БРАУЗЕРОМ")
print("="*80)

try:
    import browser_cookie3
    
    print("\nПроверяю доступность файла cookies...")
    
    # Путь к cookies файлу
    yandex_profile = Path(os.getenv("LOCALAPPDATA")) / "Yandex" / "YandexBrowser" / "User Data" / "Default"
    cookies_file = yandex_profile / "Network" / "Cookies"
    
    print(f"\nФайл cookies: {cookies_file}")
    
    if not cookies_file.exists():
        print("❌ Файл не найден!")
        exit(1)
    
    print("✅ Файл найден")
    print("\nПробую загрузить cookies через browser_cookie3...")
    
    # Пробуем загрузить
    try:
        cookies = browser_cookie3.chrome(domain_name="instagram.com", cookie_file=str(cookies_file))
        cookies_list = list(cookies)
        
        if cookies_list:
            print(f"✅✅✅ УСПЕХ! Найдено {len(cookies_list)} cookies!")
            
            # Создаем сессию
            session = requests.Session()
            for cookie in cookies_list:
                session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
            
            # Проверяем sessionid
            if 'sessionid' in session.cookies:
                print("✅✅✅ sessionid найден!")
                print("\n" + "="*80)
                print("ГОТОВО! Cookies работают!")
                print("="*80)
            else:
                print("⚠️  sessionid не найден")
        else:
            print("❌ Cookies не найдены")
            print("Убедитесь что вы залогинены на instagram.com")
            
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        import traceback
        traceback.print_exc()
        
except ImportError:
    print("❌ browser_cookie3 не установлен")
    print("Установите: pip install browser-cookie3")
