# Content Zavod - Система автоматизации контента

Система для автоматического сбора, обработки и публикации коротких вертикальных видео на нескольких платформах.

## Возможности

- ✅ Автоматический сбор видео из Instagram (Reels, профили, хэштеги)
- ✅ Обработка и уникализация видео (изменение скорости, яркости, контраста, кроп)
- ✅ Брендирование видео (добавление логотипа)
- ✅ Публикация на платформы (TikTok, YouTube Shorts, Instagram Reels)
- ✅ Управление тематиками и аккаунтами
- ✅ Планирование публикаций по расписанию
- ✅ Telegram-бот для управления
- ✅ Ежедневная отчётность и статистика

## Структура проекта

```
content-zavod/
├── config.py                 # Конфигурация
├── main.py                   # Точка входа
├── requirements.txt          # Зависимости
├── database/                # Модели БД
│   ├── __init__.py
│   └── models.py
├── modules/                  # Модули системы
│   ├── content_collector/   # Сбор контента
│   ├── video_processor/      # Обработка видео
│   ├── content_manager/     # Управление контентом
│   ├── publisher/           # Публикация на платформы
│   ├── scheduler/           # Планировщик
│   ├── telegram_bot/        # Telegram-бот
│   └── analytics/           # Аналитика
├── downloads/               # Скачанные видео
├── processed/              # Обработанные видео
└── logs/                   # Логи
```

## Установка

1. Клонируйте репозиторий:
```bash
git clone <repository_url>
cd content-zavod
```

2. Установите зависимости:
```bash
pip install -r requirements.txt
```

3. Настройте базу данных PostgreSQL и Redis

4. Создайте файл `.env` на основе `.env.example`:
```bash
cp .env.example .env
# Отредактируйте .env и укажите свои настройки
```

5. Инициализируйте базу данных:
```bash
python -c "from database import init_db; init_db()"
```

6. Запустите Celery worker (в отдельном терминале):
```bash
celery -A modules.scheduler.scheduler.celery_app worker --loglevel=info
```

7. Запустите Celery beat (в отдельном терминале):
```bash
celery -A modules.scheduler.scheduler.celery_app beat --loglevel=info
```

8. Запустите основное приложение:
```bash
python main.py
```

## Использование

### Telegram-бот

После запуска системы используйте Telegram-бота для управления:

- `/start` - Начать работу
- `/topics` - Управление тематиками
- `/accounts` - Управление аккаунтами
- `/videos` - Просмотр видео
- `/status` - Статус системы

### Программное использование

```python
from database import get_db
from modules.content_manager import ContentManager

db = next(get_db())
manager = ContentManager(db)

# Создать тематику
topic = manager.create_topic(
    name="Развлечения",
    description="Развлекательный контент"
)

# Добавить источник контента
source = manager.add_source(
    topic_id=topic.id,
    source_type="profile",
    source_value="instagram_username"
)

# Собрать контент
videos = manager.collect_content_from_source(source.id, limit=10)

# Скачать и обработать видео
for video in videos:
    manager.download_video(video.id)
    manager.process_video(video.id)
```

## Модули

### Content Collector
Модуль сбора контента из различных источников (Instagram, TikTok и т.д.)

### Video Processor
Модуль обработки видео: уникализация, брендирование, удаление водяных знаков

### Content Manager
Модуль управления тематиками, аккаунтами и источниками контента

### Publisher
Модуль публикации на платформы (TikTok, YouTube, Instagram)

### Scheduler
Планировщик публикаций с использованием Celery

### Telegram Bot
Telegram-бот для управления системой

### Analytics
Модуль аналитики и ежедневной отчётности

## Важные замечания

1. **Instagram API**: Для работы с Instagram требуется авторизация. Используется библиотека `instaloader`.

2. **Публикация на платформы**: 
   - TikTok: Требуется интеграция с TikTok API (не реализовано полностью)
   - YouTube: Требуется настроенный Google API Client с OAuth2
   - Instagram: Требуется автоматизация через selenium/appium (не реализовано полностью)

3. **Удаление водяных знаков**: Базовая реализация размывает углы. Для реального удаления нужны более сложные алгоритмы или ML-модели.

4. **База данных**: Используется PostgreSQL. Убедитесь, что база данных создана и доступна.

## Лицензия

MIT
