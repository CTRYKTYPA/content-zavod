"""
Тестовый скрипт для проверки всех методов скачивания видео с Instagram.
"""
import sys
from pathlib import Path
from typing import Optional

# Добавляем путь к модулям
sys.path.insert(0, str(Path(__file__).parent))

from modules.content_collector.instagram_downloader import (
    download_video_combined,
    download_video_ytdlp,
    download_video_graphql,
    download_video_direct,
    download_video_html_parsing,
    download_video_api_v1,
    download_video_selenium,
    load_user_agents,
)
from loguru import logger
import argparse


def test_all_methods(url: str, output_dir: str = "test_downloads", proxy: Optional[str] = None):
    """Протестировать все методы скачивания."""
    output_dir = Path(output_dir)
    output_dir.mkdir(exist_ok=True)
    
    # Проверяем загрузку user agents
    user_agents = load_user_agents()
    logger.info(f"Загружено {len(user_agents)} user agents")
    
    # Извлекаем shortcode для имени файла
    from modules.content_collector.instagram_downloader import extract_shortcode
    shortcode = extract_shortcode(url) or "test"
    
    methods = [
        ("yt-dlp", download_video_ytdlp),
        ("GraphQL API", download_video_graphql),
        ("Прямые HTTP", download_video_direct),
        ("HTML парсинг", download_video_html_parsing),
        ("API v1", download_video_api_v1),
        ("Selenium", download_video_selenium),
    ]
    
    results = {}
    
    for method_name, method_func in methods:
        logger.info(f"\n{'='*60}")
        logger.info(f"Тестирование метода: {method_name}")
        logger.info(f"{'='*60}")
        
        output_path = output_dir / f"{shortcode}_{method_name.replace(' ', '_')}.mp4"
        
        try:
            success = method_func(url, str(output_path), proxy=proxy)
            results[method_name] = {
                'success': success,
                'output_path': output_path if success else None,
                'error': None
            }
            if success:
                logger.info(f"✅ {method_name}: УСПЕХ - файл сохранен в {output_path}")
            else:
                logger.warning(f"❌ {method_name}: НЕУДАЧА")
        except Exception as e:
            results[method_name] = {
                'success': False,
                'output_path': None,
                'error': str(e)
            }
            logger.error(f"❌ {method_name}: ОШИБКА - {e}")
    
    # Итоговый отчет
    logger.info(f"\n{'='*60}")
    logger.info("ИТОГОВЫЙ ОТЧЕТ")
    logger.info(f"{'='*60}")
    
    successful = [name for name, result in results.items() if result['success']]
    failed = [name for name, result in results.items() if not result['success']]
    
    logger.info(f"✅ Успешные методы ({len(successful)}): {', '.join(successful)}")
    logger.info(f"❌ Неудачные методы ({len(failed)}): {', '.join(failed)}")
    
    # Пробуем комбинированный метод
    logger.info(f"\n{'='*60}")
    logger.info("Тестирование комбинированного метода")
    logger.info(f"{'='*60}")
    
    output_path = output_dir / f"{shortcode}_combined.mp4"
    try:
        success = download_video_combined(url, str(output_path), proxy=proxy)
        if success:
            logger.info(f"✅ Комбинированный метод: УСПЕХ - файл сохранен в {output_path}")
        else:
            logger.warning(f"❌ Комбинированный метод: НЕУДАЧА")
    except Exception as e:
        logger.error(f"❌ Комбинированный метод: ОШИБКА - {e}")
    
    return results


def main():
    parser = argparse.ArgumentParser(description='Тест методов скачивания видео с Instagram')
    parser.add_argument('url', help='URL поста Instagram (например: https://www.instagram.com/p/ABC123/)')
    parser.add_argument('--output-dir', default='test_downloads', help='Директория для сохранения (по умолчанию: test_downloads)')
    parser.add_argument('--proxy', help='Прокси (опционально, например: http://proxy:port)')
    parser.add_argument('--method', choices=['all', 'ytdlp', 'graphql', 'direct', 'html', 'api', 'selenium', 'combined'],
                       default='combined', help='Метод для тестирования (по умолчанию: combined)')
    
    args = parser.parse_args()
    
    logger.info(f"Начинаю тестирование для URL: {args.url}")
    
    if args.method == 'all':
        test_all_methods(args.url, args.output_dir, args.proxy)
    elif args.method == 'combined':
        from modules.content_collector.instagram_downloader import download_video_combined
        output_path = Path(args.output_dir) / "test_combined.mp4"
        download_video_combined(args.url, str(output_path), proxy=args.proxy)
    elif args.method == 'ytdlp':
        download_video_ytdlp(args.url, Path(args.output_dir) / "test_ytdlp.mp4", proxy=args.proxy)
    elif args.method == 'graphql':
        download_video_graphql(args.url, Path(args.output_dir) / "test_graphql.mp4")
    elif args.method == 'direct':
        download_video_direct(args.url, Path(args.output_dir) / "test_direct.mp4")
    elif args.method == 'html':
        download_video_html_parsing(args.url, Path(args.output_dir) / "test_html.mp4")
    elif args.method == 'api':
        download_video_api_v1(args.url, Path(args.output_dir) / "test_api.mp4")
    elif args.method == 'selenium':
        download_video_selenium(args.url, Path(args.output_dir) / "test_selenium.mp4", proxy=args.proxy)


if __name__ == '__main__':
    main()
