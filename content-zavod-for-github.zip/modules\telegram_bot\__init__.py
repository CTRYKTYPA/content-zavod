"""Модуль Telegram-бота."""
from .bot import TelegramBot

__all__ = ["TelegramBot"]
