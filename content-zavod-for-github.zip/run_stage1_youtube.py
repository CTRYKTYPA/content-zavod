#!/usr/bin/env python3
"""
Этап 1 — запуск сбора и обработки по YouTube Shorts.

1. Собирает контент из активных источников youtube_shorts.
2. Скачивает найденные видео.
3. Обрабатывает (уникализация + плашка).
4. Видео «готовы к публикации» (PROCESSED). В ТГ уходит отчёт.

Перед запуском:
  python scripts/setup_youtube_stage1.py
  TELEGRAM_BOT_TOKEN, TELEGRAM_ADMIN_IDS в .env.

Быстрое демо (Бизнес + Юмор, по 5 роликов на тему):
  python run_stage1_youtube.py --quick
  или:
  python run_stage1_youtube.py --themes "Бизнес,Юмор" --collect 10 --download 10 --process 10
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from loguru import logger

from config import settings
from database.models import Base, ContentSource, Publication, Topic, Video, VideoStatus
from modules.content_manager import ContentManager
from modules.telegram_bot.notify import send_report_to_admins


def _clear_videos_db(db) -> None:
    """Удалить все публикации и видео (для быстрого демо)."""
    db.query(Publication).delete()
    db.query(Video).delete()
    db.commit()


def run_stage1(
    collect_limit: int = 30,
    download_limit: int = 20,
    process_limit: int = 20,
    themes: list[str] | None = None,
    clear_db: bool = False,
):
    engine = create_engine(settings.DATABASE_URL)
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    if clear_db:
        _clear_videos_db(db)
    cm = ContentManager(db)

    q = (
        db.query(ContentSource)
        .join(Topic, ContentSource.topic_id == Topic.id)
        .filter(
            ContentSource.source_type == "youtube_shorts",
            ContentSource.is_active == True,
        )
    )
    if themes:
        q = q.filter(Topic.name.in_(themes))
    sources = q.all()

    if not sources:
        logger.warning("Нет активных YouTube-источников. Запустите: python scripts/setup_youtube_stage1.py")
        db.close()
        return

    # 1. Сбор
    total_collected = 0
    per_src = max(1, collect_limit // len(sources)) if collect_limit else 50
    for src in sources:
        created = cm.collect_content_from_source(src.id, limit=per_src)
        total_collected += len(created)
    logger.info(f"Собрано: {total_collected}")

    # 2. Скачивание
    to_download = db.query(Video).filter(Video.status == VideoStatus.FOUND).limit(download_limit).all()
    downloaded_ok = 0
    for v in to_download:
        if cm.download_video(v.id):
            downloaded_ok += 1
    logger.info(f"Скачано: {downloaded_ok} из {len(to_download)}")

    # 3. Обработка (плашка)
    to_process = db.query(Video).filter(Video.status == VideoStatus.DOWNLOADED).limit(process_limit).all()
    processed_ok = 0
    for v in to_process:
        if cm.process_video(v.id):
            processed_ok += 1
    logger.info(f"Обработано: {processed_ok} из {len(to_process)}")

    db.close()
    logger.info("Этап 1 (YouTube) завершён. Отчёт в Telegram.")

    # Отчёт в Telegram: готово к публикации N видео
    ready = processed_ok
    report = (
        "📊 Этап 1 (YouTube) — отчёт\n\n"
        f"🔍 Собрано новых: {total_collected}\n"
        f"⬇️ Скачано: {downloaded_ok}/{len(to_download)}\n"
        f"⚙️ Обработано: {processed_ok}/{len(to_process)}\n\n"
        f"✅ Готово к публикации: {ready} видео\n\n"
        "Команды в боте: /status /stats /alerts /videos"
    )
    send_report_to_admins(report)


def _parse_args():
    p = argparse.ArgumentParser(description="Этап 1: сбор → скачивание → обработка YouTube Shorts, отчёт в ТГ.")
    p.add_argument("--themes", type=str, default=None, help='Только эти темы, через запятую, например "Бизнес,Юмор"')
    p.add_argument("--collect", type=int, default=30, help="Лимит на сбор (всего)")
    p.add_argument("--download", type=int, default=20, help="Лимит на скачивание")
    p.add_argument("--process", type=int, default=20, help="Лимит на обработку")
    p.add_argument("--quick", action="store_true", help="Быстрое демо: Бизнес+Юмор, по 5 роликов на тему")
    p.add_argument("--clear-db-only", action="store_true", help="Только очистить БД (видео и публикации), затем выйти")
    return p.parse_args()


if __name__ == "__main__":
    args = _parse_args()
    if args.clear_db_only:
        engine = create_engine(settings.DATABASE_URL)
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine)
        db = Session()
        _clear_videos_db(db)
        db.close()
        logger.info("БД очищена. Запускай парсинг: python run_stage1_youtube.py --quick")
        sys.exit(0)
    if args.quick:
        os.environ["STAGE1_QUICK"] = "1"
        logger.info("Режим --quick: 4 ролика (2 на тему), 720p, быстрый encode.")
        run_stage1(
            themes=["Бизнес", "Юмор"],
            collect_limit=4,
            download_limit=4,
            process_limit=4,
            clear_db=True,
        )
    else:
        themes = [t.strip() for t in args.themes.split(",")] if args.themes else None
        run_stage1(
            collect_limit=args.collect,
            download_limit=args.download,
            process_limit=args.process,
            themes=themes,
        )
