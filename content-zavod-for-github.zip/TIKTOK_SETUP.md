# TikTok: настройка сбора без API

Сбор идёт через **yt-dlp**. Официального API нет. Ниже — все рабочие варианты, чтобы заказчик стабильно получал видео.

---

## 1. Приоритет: сбор по **users** (никнеймы)

- Источники вида `https://www.tiktok.com/@{user}` используют **web API**.
- **Не требуются** куки и app_info.
- В конфиге уже заданы пользователи по темам (`tiktok_themes_config.py`).  
- Запуск: `python scripts/setup_tiktok_stage1.py` → `python run_stage1_tiktok.py`.

**Итого:** для «как хочет заказчик» в первую очередь используйте **users**. Добавляйте нужных авторов в `users` в `tiktok_themes_config.py`.

**Темы по slug:** чтобы не зависеть от кодировки консоли, задавайте темы через slug: `--themes "humor,business"` (см. `tiktok_themes_config.py`: `humor`, `business`, `lifestyle`, `tech`, `motivation`).

---

## 2. Куки — если не хватает users или нужны **hashtags**

Хэштеги используют mobile API. Чтобы уменьшить «No working app info» и блокировки, нужны куки.

### Вариант A: файл куков (Netscape)

1. Залогиньтесь на [tiktok.com](https://www.tiktok.com) в Chrome.
2. F12 → **Application** → **Storage** → **Cookies** → `https://www.tiktok.com`.
3. Экспортируйте куки в формате **Netscape** (расширение «Get Cookies Locally» / «cookies.txt» и т.п.).
4. Сохраните файл, например `tiktok_cookies.txt`.
5. В `.env`:
   ```bash
   TIKTOK_COOKIES_FILE=tiktok_cookies.txt
   ```
   (или полный путь к файлу.)

### Вариант B: куки из браузера

1. Залогиньтесь на tiktok.com в Chrome/Firefox/Edge.
2. В `.env`:
   ```bash
   TIKTOK_COOKIES_FROM_BROWSER=chrome
   ```
   Возможные значения: `chrome`, `firefox`, `edge`.

**Важно:** лучше использовать **отдельный** аккаунт для парсинга, чтобы не рисковать основным.

---

## 3. App info (опционально, для хэштегов)

Нужно только если активно используете **hashtags** и mobile API падает с «No working app info».

В `.env` можно задать:

```bash
# Необязательно. Формат: iid/app_name/app_version/manifest/aid через ";"
# Пример (значения могут устаревать, смотрите актуальные в issues yt-dlp):
# TIKTOK_EXTRACTOR_APP_INFO=/musical_ly/35.1.3/2023501030/0
TIKTOK_EXTRACTOR_APP_INFO=

# Опционально device_id (число)
TIKTOK_EXTRACTOR_DEVICE_ID=
```

Актуальные рабочие значения иногда появляются в обсуждениях:  
[https://github.com/yt-dlp/yt-dlp/issues?q=tiktok+app_info](https://github.com/yt-dlp/yt-dlp/issues?q=tiktok+app_info)

---

## 4. Прокси

Если TikTok режет по IP:

```bash
TIKTOK_PROXY=http://user:pass@host:port
# или
TIKTOK_PROXY=socks5://host:port
```

Иначе используются `YOUTUBE_PROXY` / `INSTAGRAM_PROXY`.

---

## 5. Что включено в проекте

| Что | Где |
|-----|-----|
| **Темы по slug** | `--themes "humor,business"` (slug в `tiktok_themes_config.py`) |
| Сбор по **users** | `tiktok_themes_config.py` → `users` |
| Сбор по **hashtags** | `tiktok_themes_config.py` → `hashtags` |
| Куки из файла | `TIKTOK_COOKIES_FILE` в `.env` |
| Куки из браузера | `TIKTOK_COOKIES_FROM_BROWSER` в `.env` |
| App info / device_id | `TIKTOK_EXTRACTOR_APP_INFO`, `TIKTOK_EXTRACTOR_DEVICE_ID` в `.env` |
| Прокси | `TIKTOK_PROXY` в `.env` |

---

## 6. Рекомендуемый порядок для заказчика

1. **Только users**  
   Настроены в конфиге → `setup_tiktok_stage1` → `run_stage1_tiktok`.  
   Должно работать без куков и app_info.

2. **Добавить своих авторов**  
   Редактировать `users` в `tiktok_themes_config.py` под темы заказчика.

3. **Если нужны хэштеги**  
   Включить куки (файл или из браузера). При необходимости добавить app_info по инструкции выше.

4. **Если блокируют по IP**  
   Настроить `TIKTOK_PROXY`.

5. **Обновлять yt-dlp**  
   `pip install -U yt-dlp` — TikTok часто меняет API, в новых версиях бывают фиксы.

---

## 7. Типичные ошибки

| Ошибка | Что делать |
|--------|------------|
| **No working app info** | Сбор по хэштегам (mobile API). Включите куки и/или `TIKTOK_EXTRACTOR_APP_INFO`. Либо собирайте только по **users** — им app_info не нужен. |
| **No video formats found** | Ролик недоступен (регион, возраст, логин). Включите куки (файл или из браузера), по возможности залогиньтесь на tiktok.com. |
| **Нет активных TikTok-источников по выбранным темам** | Используйте **slug** из конфига: `humor`, `business`, `lifestyle`, `tech`, `motivation`. Например: `--themes "humor,business"`. Запустите без `--themes`, чтобы собрать по всем темам. |

## 8. Полезные ссылки

- [yt-dlp TikTok extractor](https://github.com/yt-dlp/yt-dlp/blob/master/yt_dlp/extractor/tiktok.py)
- [Подробнее про куки TikTok](https://addrom.com/detailed-guide-on-how-to-get-douyin-and-tiktok-cookies/)
- [yt-dlp FAQ — cookies](https://github.com/yt-dlp/yt-dlp/wiki/FAQ)
