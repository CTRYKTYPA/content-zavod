"""Тест ротации прокси."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from modules.content_collector.proxy_rotator import get_proxy_rotator

print("=" * 60)
print("ТЕСТ РОТАЦИИ ПРОКСИ")
print("=" * 60)

rotator = get_proxy_rotator()

if not rotator.has_proxies():
    print("\nПрокси не настроены.")
    print("Запустите: python setup_proxies.py")
    exit(1)

print(f"\nНайдено прокси: {len(rotator.proxies)}")
print("\nТестирую ротацию (10 итераций):\n")

for i in range(10):
    proxy = rotator.get_next_proxy()
    display = proxy.split('@')[-1] if '@' in proxy else proxy
    print(f"{i+1}. {display}")

print("\nOK: Ротация работает!")
print("\nСистема будет автоматически использовать разные IP при каждом запросе.")
