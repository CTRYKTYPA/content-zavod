"""Импорт сессии из Яндекс браузера."""
import sys
import codecs
from pathlib import Path
import os

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from config import settings
import instaloader

print("=" * 60)
print("ИМПОРТ СЕССИИ ИЗ ЯНДЕКС БРАУЗЕРА")
print("=" * 60)

username = settings.INSTAGRAM_USERNAME

if not username:
    print("Ошибка: INSTAGRAM_USERNAME не указан в .env")
    exit(1)

print(f"\nЛогин: {username}")
print("\nИщу cookies в Яндекс браузере...")

# Пути к Яндекс браузеру (правильный путь с Network)
yandex_paths = [
    Path(os.getenv("LOCALAPPDATA")) / "Yandex" / "YandexBrowser" / "User Data" / "Default" / "Network" / "Cookies",
    Path(os.getenv("LOCALAPPDATA")) / "Yandex" / "YandexBrowser" / "User Data" / "Default" / "Cookies",
    Path.home() / "AppData" / "Local" / "Yandex" / "YandexBrowser" / "User Data" / "Default" / "Network" / "Cookies",
]

cookies_file = None
for path in yandex_paths:
    if path.exists():
        cookies_file = str(path)
        print(f"Найден файл cookies: {cookies_file}")
        break

if not cookies_file:
    print("Файл cookies Яндекс браузера не найден")
    print("Убедитесь что:")
    print("  - Яндекс браузер установлен")
    print("  - Вы залогинены на instagram.com")
    exit(1)

try:
    import browser_cookie3
    import shutil
    import tempfile
    
    print("Читаю cookies из Яндекс браузера...")
    
    # Копируем файл cookies во временную папку (чтобы обойти блокировку)
    temp_cookies = Path(tempfile.gettempdir()) / "yandex_cookies_temp"
    try:
        shutil.copy2(cookies_file, temp_cookies)
        print("Файл cookies скопирован для чтения")
    except Exception as e:
        print(f"Не удалось скопировать файл: {e}")
        print("Попробуйте закрыть Яндекс браузер и запустить скрипт снова")
        exit(1)
    
    try:
        # Используем browser-cookie3 для чтения
        # Яндекс браузер использует Chrome формат
        cookies = browser_cookie3.chrome(domain_name="instagram.com", cookie_file=str(temp_cookies))
        cookies_list = list(cookies)
        
        if not cookies_list:
            print("Cookies Instagram не найдены в Яндекс браузере")
            print("Убедитесь что вы залогинены на instagram.com в Яндекс браузере")
            temp_cookies.unlink(missing_ok=True)
            exit(1)
        
        print(f"Найдено cookies: {len(cookies_list)}")
        
        # Создаём instaloader
        L = instaloader.Instaloader()
        
        # Импортируем cookies
        import requests
        session = requests.Session()
        for cookie in cookies:
            session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
        
        L.context._session = session
        
        # Проверяем
        test_user = L.test_login()
        if test_user:
            print(f"OK: Сессия работает! Пользователь: {test_user}")
            
            # Сохраняем
            L.save_session_to_file()
            print("OK: Сессия сохранена!")
            print("\nТеперь можно запускать систему:")
            print("  python test_download.py")
        else:
            print("Ошибка: Сессия не работает")
            print("Убедитесь что вы залогинены в Instagram через Яндекс браузер")
        
    finally:
        # Удаляем временный файл
        temp_cookies.unlink(missing_ok=True)

except Exception as e:
    print(f"Ошибка: {e}")
    import traceback
    traceback.print_exc()
    
    print("\nАльтернативный способ:")
    print("1. Откройте Яндекс браузер")
    print("2. Войдите на instagram.com")
    print("3. Не закрывайте браузер")
    print("4. Запустите: python fix_auth_simple.py")
