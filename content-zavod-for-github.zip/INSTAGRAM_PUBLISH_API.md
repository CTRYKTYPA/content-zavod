# Публикация в Instagram через Graph API

## ✅ Можно ли публиковать?

**ДА!** Instagram Graph API поддерживает публикацию:
- 📸 Фото
- 🎥 Видео
- 🎬 Reels
- 🎠 Карусели (несколько фото/видео)

## 🔑 Что нужно?

### 1. Разрешения (Permissions)

В Graph API Explorer выберите:
- `instagram_content_publish` - **обязательно для публикации**
- `instagram_basic` - для чтения данных
- `pages_read_engagement` - для работы с Page

### 2. Требования к аккаунту

- ✅ **Профессиональный Instagram аккаунт** (Business или Creator)
- ✅ Аккаунт должен быть **связан с Facebook Page**
- ✅ Page должен быть в **Business Manager** (для некоторых случаев)

### 3. App Review (проверка приложения)

⚠️ **Может потребоваться**, если:
- Используете Advanced Access
- Публикуете от имени нескольких бизнесов
- Нужны расширенные разрешения

✅ **НЕ требуется**, если:
- Используете Standard Access
- Публикуете только для своего бизнеса
- Используете базовые разрешения

## 📋 Процесс публикации

### Шаг 1: Загрузите медиа на публичный сервер

Медиа должно быть доступно по публичному URL:
```
https://ваш-сервер.com/video.mp4
```

### Шаг 2: Создайте Media Container

```http
POST /{ig-user-id}/media
```

Параметры:
- `media_type`: `REELS`, `VIDEO`, `IMAGE`, или `CAROUSEL`
- `video_url`: URL вашего видео (для Reels/Video)
- `image_url`: URL вашего фото (для Image)
- `caption`: Подпись к посту

### Шаг 3: Опубликуйте

```http
POST /{ig-user-id}/media_publish
```

Параметры:
- `creation_id`: ID контейнера из шага 2

**ВАЖНО:** Подождите 15+ секунд между созданием контейнера и публикацией!

## ⚠️ Ограничения

- **50 публикаций в 24 часа** на аккаунт
- Медиа должно быть на **публичном сервере**
- Только для **профессиональных аккаунтов**
- Может потребоваться **App Review**

## 💡 Пример использования

```python
# 1. Создать контейнер
container_response = requests.post(
    f"https://graph.instagram.com/{user_id}/media",
    params={
        'media_type': 'REELS',
        'video_url': 'https://your-server.com/video.mp4',
        'caption': 'Мой новый Reel!',
        'access_token': access_token
    }
)
container_id = container_response.json()['id']

# 2. Подождать
time.sleep(15)

# 3. Опубликовать
publish_response = requests.post(
    f"https://graph.instagram.com/{user_id}/media_publish",
    params={
        'creation_id': container_id,
        'access_token': access_token
    }
)
```

## 🎯 Итого

**ДА, можно публиковать**, но:
- Нужен профессиональный аккаунт
- Медиа на публичном сервере
- Может потребоваться App Review
- Лимит 50 постов в день

**Для вашего проекта:** Graph API отлично подходит и для сбора ссылок, и для публикации!
