# Установка ChromeDriver для автоматизации

## Быстрая установка:

1. Откройте https://chromedriver.chromium.org/downloads
2. Скачайте версию для вашей версии Chrome
3. Распакуйте `chromedriver.exe`
4. Поместите в папку проекта `content-zavod`

## Или автоматически:

Скрипт автоматически найдёт ChromeDriver если он в:
- Папке проекта
- `chromedriver/chromedriver.exe`
- Домашней папке пользователя
- `C:/chromedriver/chromedriver.exe`

## Проверка версии Chrome:

1. Откройте Chrome
2. Нажмите меню (три точки) → Настройки → О браузере Chrome
3. Посмотрите версию (например, 120.0.6099.109)
4. Скачайте соответствующую версию ChromeDriver
