"""
Скрипт для запуска Яндекс браузера с remote debugging.
Запускает браузер автоматически с нужными флагами.
АВТОМАТИЧЕСКИ закрывает старый браузер и запускает новый.
"""
import subprocess
import sys
import os
import time
import json
import io
from pathlib import Path

# Настройка кодировки для Windows
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

print("="*80)
print("АВТОМАТИЧЕСКИЙ ЗАПУСК ЯНДЕКС БРАУЗЕРА С REMOTE DEBUGGING")
print("="*80)

# Путь к Яндекс браузеру
yandex_paths = [
    Path(os.getenv("LOCALAPPDATA")) / "Yandex" / "YandexBrowser" / "Application" / "browser.exe",
    Path(os.getenv("PROGRAMFILES")) / "Yandex" / "YandexBrowser" / "Application" / "browser.exe",
    Path(os.getenv("PROGRAMFILES(X86)")) / "Yandex" / "YandexBrowser" / "Application" / "browser.exe",
]

yandex_exe = None
for path in yandex_paths:
    if path.exists():
        yandex_exe = path
        break

if not yandex_exe:
    print("❌ Яндекс браузер не найден!")
    print("\nУстановите Яндекс браузер или укажите путь вручную")
    sys.exit(1)

print(f"✅ Найден Яндекс браузер: {yandex_exe}")

# Закрываем старый браузер если запущен
if PSUTIL_AVAILABLE:
    print("\n🔍 Проверяю запущенные процессы Яндекс браузера...")
    yandex_processes = []
    for proc in psutil.process_iter(['pid', 'name', 'exe']):
        try:
            if proc.info['name'] and 'yandex' in proc.info['name'].lower():
                yandex_processes.append(proc)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    if yandex_processes:
        print(f"⚠️  Найдено {len(yandex_processes)} процессов Яндекс браузера")
    print("   Закрываю старые процессы...")
    for proc in yandex_processes:
        try:
            proc.terminate()
        except:
            pass
    
    # Ждем закрытия
    print("   Жду 3 секунды...")
    time.sleep(3)
    
    # Принудительно убиваем если не закрылись
    for proc in yandex_processes:
        try:
            if proc.is_running():
                proc.kill()
        except:
            pass
    
        print("✅ Старые процессы закрыты")
    else:
        print("✅ Браузер не запущен")
else:
    print("\n⚠️  psutil не установлен, не могу автоматически закрыть браузер")
    print("   Закройте Яндекс браузер вручную перед запуском!")

# Запускаем с remote debugging
print("\n🚀 Запускаю браузер с remote debugging (порт 9222)...")
print("   После запуска откройте Instagram и залогиньтесь")

try:
    # Запускаем в отдельном процессе
    # Яндекс браузер использует те же флаги что и Chrome
    user_data_debug = Path(os.getenv("LOCALAPPDATA")) / "Yandex" / "YandexBrowser" / "User Data Debug"
    user_data_debug.mkdir(parents=True, exist_ok=True)
    
    process = subprocess.Popen([
        str(yandex_exe),
        f"--remote-debugging-port=9222",
        f"--user-data-dir={user_data_debug}",
        "--disable-web-security",  # Дополнительный флаг для отладки
        "https://www.instagram.com"
    ], creationflags=subprocess.CREATE_NEW_CONSOLE if sys.platform == 'win32' else 0)
    
    print("\n✅ Браузер запущен с remote debugging!")
    print("   Подождите 3 секунды пока браузер загрузится...")
    time.sleep(3)
    
    # Проверяем доступность порта
    print("\n🔍 Проверяю доступность порта 9222...")
    import urllib.request
    try:
        with urllib.request.urlopen("http://127.0.0.1:9222/json", timeout=2) as response:
            tabs = json.loads(response.read().decode())
            print(f"✅✅✅ ПОРТ 9222 РАБОТАЕТ! Найдено {len(tabs)} вкладок")
    except Exception as e:
        print(f"⚠️  Порт пока недоступен: {e}")
        print("   Подождите еще 2 секунды...")
        time.sleep(2)
    
    print("\n" + "="*80)
    print("ГОТОВО!")
    print("="*80)
    print("\nТеперь:")
    print("1. Залогиньтесь на Instagram в открывшемся браузере")
    print("2. Запустите: python run_thematic_collection.py humor 10")
    print("\nБраузер будет использован автоматически для получения cookies!")
    
except ImportError:
    # Если psutil не установлен, просто запускаем браузер
    print("⚠️  psutil не установлен, не могу закрыть старые процессы")
    print("   Закройте браузер вручную и запустите скрипт снова")
    subprocess.Popen([
        str(yandex_exe),
        "--remote-debugging-port=9222",
        "https://www.instagram.com"
    ])
    print("\n✅ Браузер запущен!")
except Exception as e:
    print(f"❌ Ошибка запуска: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)
