# Методы скачивания видео с Instagram БЕЗ instaloader

Этот документ содержит все найденные способы скачивания видео с Instagram, используя user agents из файла `useragents.txt` и обходя необходимость в instaloader.

## 📋 Содержание

1. [GraphQL API метод](#1-graphql-api-метод)
2. [Прямые HTTP запросы с правильными заголовками](#2-прямые-http-запросы)
3. [yt-dlp с улучшенными настройками](#3-yt-dlp-метод)
4. [pyigdl библиотека](#4-pyigdl-библиотека)
5. [Instagram API v1 метод](#5-instagram-api-v1-метод)
6. [Selenium метод (улучшенный)](#6-selenium-метод)
7. [HTML парсинг с BeautifulSoup](#7-html-парсинг)
8. [Комбинированный подход](#8-комбинированный-подход)

---

## 1. GraphQL API метод

**Самый эффективный метод** - использование GraphQL эндпоинта Instagram напрямую.

### Преимущества:
- Не требует авторизации для публичного контента
- Получает метаданные и прямые ссылки на видео
- Можно получить несколько качеств видео

### Недостатки:
- `doc_id` меняется каждые 2-4 недели (нужно обновлять)
- Строгие лимиты (~200 запросов/час на IP)
- Требует правильные заголовки и user-agent

### Реализация:

```python
import requests
import json
import re
from pathlib import Path
from typing import Optional, Dict, Any
import random

def load_user_agents(file_path: str = "useragents.txt") -> list:
    """Загрузить user agents из файла."""
    user_agents = []
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if line and len(line) > 30:
                    # Фильтруем только десктопные браузеры
                    if ('Chrome/' in line or 'Firefox/' in line) and 'Mobile' not in line:
                        if 'Windows' in line or 'Macintosh' in line or 'Linux' in line:
                            user_agents.append(line)
    except Exception as e:
        print(f"Ошибка загрузки user agents: {e}")
    
    return user_agents if user_agents else [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
    ]

def extract_shortcode(url: str) -> Optional[str]:
    """Извлечь shortcode из URL Instagram."""
    patterns = [
        r'/p/([^/]+)',
        r'/reel/([^/]+)',
        r'/tv/([^/]+)',
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None

def get_csrf_token(session: requests.Session, user_agent: str) -> Optional[str]:
    """Получить CSRF токен из главной страницы Instagram."""
    headers = {
        'User-Agent': user_agent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': 'https://www.instagram.com/',
    }
    
    try:
        response = session.get('https://www.instagram.com/', headers=headers, timeout=10)
        # Ищем csrf токен в cookies
        csrf_token = response.cookies.get('csrftoken')
        if not csrf_token:
            # Пробуем извлечь из HTML
            match = re.search(r'"csrf_token":"([^"]+)"', response.text)
            if match:
                csrf_token = match.group(1)
        return csrf_token
    except Exception as e:
        print(f"Ошибка получения CSRF токена: {e}")
        return None

def download_video_graphql(url: str, output_path: str, user_agents_file: str = "useragents.txt") -> bool:
    """
    Скачать видео через GraphQL API.
    
    Args:
        url: URL поста Instagram (например https://www.instagram.com/p/ABC123/)
        output_path: Путь для сохранения видео
        user_agents_file: Путь к файлу с user agents
    
    Returns:
        True если успешно
    """
    user_agents = load_user_agents(user_agents_file)
    user_agent = random.choice(user_agents)
    
    session = requests.Session()
    
    # Получаем CSRF токен
    csrf_token = get_csrf_token(session, user_agent)
    if not csrf_token:
        print("Не удалось получить CSRF токен")
        return False
    
    # Извлекаем shortcode
    shortcode = extract_shortcode(url)
    if not shortcode:
        print(f"Не удалось извлечь shortcode из URL: {url}")
        return False
    
    # GraphQL запрос
    graphql_url = "https://www.instagram.com/graphql/query/"
    
    # ВАЖНО: doc_id меняется каждые 2-4 недели!
    # Текущий doc_id можно найти в DevTools браузера при открытии поста
    # Или использовать один из известных:
    doc_ids = [
        "7950326061742207",  # Для получения информации о посте
        "24368985919464652",  # Альтернативный
    ]
    
    headers = {
        'User-Agent': user_agent,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-CSRFToken': csrf_token,
        'X-IG-App-ID': '936619743392459',  # Веб-версия Instagram
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://www.instagram.com',
        'Referer': f'https://www.instagram.com/p/{shortcode}/',
    }
    
    # Пробуем разные doc_id
    for doc_id in doc_ids:
        data = {
            'variables': json.dumps({"shortcode": shortcode}),
            'doc_id': doc_id
        }
        
        try:
            response = session.post(graphql_url, headers=headers, data=data, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                
                # Извлекаем URL видео из ответа
                video_url = None
                try:
                    # Структура ответа может отличаться, нужно адаптировать
                    data = result.get('data', {})
                    shortcode_media = data.get('shortcode_media', {})
                    
                    if shortcode_media.get('is_video'):
                        video_url = shortcode_media.get('video_url')
                        if not video_url:
                            # Пробуем найти в других местах
                            video_url = shortcode_media.get('video_versions', [{}])[0].get('url')
                except Exception as e:
                    print(f"Ошибка парсинга ответа: {e}")
                    print(f"Ответ: {response.text[:500]}")
                    continue
                
                if video_url:
                    # Скачиваем видео
                    video_response = session.get(video_url, stream=True, timeout=30)
                    video_response.raise_for_status()
                    
                    output_file = Path(output_path)
                    output_file.parent.mkdir(parents=True, exist_ok=True)
                    
                    with open(output_file, 'wb') as f:
                        for chunk in video_response.iter_content(chunk_size=8192):
                            f.write(chunk)
                    
                    print(f"✅ Видео скачано через GraphQL: {output_path}")
                    return True
            else:
                print(f"Ошибка GraphQL запроса: {response.status_code}")
                continue
                
        except Exception as e:
            print(f"Ошибка при запросе с doc_id {doc_id}: {e}")
            continue
    
    return False

# Использование:
# download_video_graphql("https://www.instagram.com/p/ABC123/", "video.mp4")
```

---

## 2. Прямые HTTP запросы

Метод получения прямых ссылок на видео через парсинг HTML страницы.

### Реализация:

```python
import requests
import re
import json
from pathlib import Path
import random

def download_video_direct(url: str, output_path: str, user_agents_file: str = "useragents.txt") -> bool:
    """
    Скачать видео через прямые HTTP запросы с парсингом HTML.
    
    Args:
        url: URL поста Instagram
        output_path: Путь для сохранения
        user_agents_file: Путь к файлу с user agents
    
    Returns:
        True если успешно
    """
    user_agents = load_user_agents(user_agents_file)
    user_agent = random.choice(user_agents)
    
    session = requests.Session()
    
    headers = {
        'User-Agent': user_agent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
    }
    
    try:
        # Получаем HTML страницу
        response = session.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        html = response.text
        
        # Ищем JSON данные в HTML (Instagram встраивает данные в <script>)
        # Паттерн 1: window._sharedData
        match = re.search(r'window\._sharedData\s*=\s*({.+?});', html)
        if match:
            try:
                data = json.loads(match.group(1))
                # Извлекаем URL видео из структуры данных
                video_url = extract_video_url_from_data(data)
                if video_url:
                    return download_video_file(session, video_url, output_path)
            except Exception as e:
                print(f"Ошибка парсинга _sharedData: {e}")
        
        # Паттерн 2: JSON-LD
        match = re.search(r'<script type="application/ld\+json">(.+?)</script>', html, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(1))
                video_url = data.get('contentUrl') or data.get('video', {}).get('contentUrl')
                if video_url:
                    return download_video_file(session, video_url, output_path)
            except Exception as e:
                print(f"Ошибка парсинга JSON-LD: {e}")
        
        # Паттерн 3: Прямой поиск video_url в HTML
        patterns = [
            r'"video_url":"([^"]+)"',
            r'"videoUrl":"([^"]+)"',
            r'<meta property="og:video" content="([^"]+)"',
            r'<meta property="og:video:secure_url" content="([^"]+)"',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, html)
            for match_url in matches:
                if 'video' in match_url.lower() or 'mp4' in match_url.lower():
                    # Декодируем URL если нужно
                    video_url = match_url.replace('\\u0026', '&').replace('\\/', '/')
                    if download_video_file(session, video_url, output_path):
                        return True
        
        print("Не удалось найти URL видео в HTML")
        return False
        
    except Exception as e:
        print(f"Ошибка прямого скачивания: {e}")
        return False

def extract_video_url_from_data(data: dict) -> Optional[str]:
    """Извлечь URL видео из структуры данных Instagram."""
    try:
        # Различные пути в структуре данных
        paths = [
            ['entry_data', 'PostPage', 0, 'graphql', 'shortcode_media', 'video_url'],
            ['entry_data', 'PostPage', 0, 'graphql', 'shortcode_media', 'video_versions', 0, 'url'],
            ['graphql', 'shortcode_media', 'video_url'],
            ['graphql', 'shortcode_media', 'video_versions', 0, 'url'],
        ]
        
        for path in paths:
            value = data
            try:
                for key in path:
                    if isinstance(key, int):
                        value = value[key]
                    else:
                        value = value[key]
                if value and isinstance(value, str) and value.startswith('http'):
                    return value
            except (KeyError, IndexError, TypeError):
                continue
        
        return None
    except Exception as e:
        print(f"Ошибка извлечения URL: {e}")
        return None

def download_video_file(session: requests.Session, video_url: str, output_path: str) -> bool:
    """Скачать видео файл по прямой ссылке."""
    try:
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        response = session.get(video_url, stream=True, timeout=60)
        response.raise_for_status()
        
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        with open(output_file, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                if chunk:
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total_size > 0:
                        progress = (downloaded / total_size) * 100
                        print(f"\rСкачивание: {progress:.1f}%", end='', flush=True)
        
        print(f"\n✅ Видео скачано: {output_path}")
        return True
        
    except Exception as e:
        print(f"Ошибка скачивания файла: {e}")
        return False
```

---

## 3. yt-dlp метод

**Самый надежный метод** - использование yt-dlp с правильными настройками и user agents.

### Реализация:

```python
import yt_dlp
from pathlib import Path
import random
import tempfile

def download_video_ytdlp(url: str, output_path: str, user_agents_file: str = "useragents.txt", 
                         proxy: Optional[str] = None) -> bool:
    """
    Скачать видео через yt-dlp с ротацией user agents.
    
    Args:
        url: URL поста Instagram
        output_path: Путь для сохранения
        user_agents_file: Путь к файлу с user agents
        proxy: Прокси (опционально)
    
    Returns:
        True если успешно
    """
    user_agents = load_user_agents(user_agents_file)
    user_agent = random.choice(user_agents)
    
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    
    # Настройки yt-dlp
    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': str(output_file.with_suffix('')) + '.%(ext)s',
        'quiet': False,
        'no_warnings': False,
        'extract_flat': False,
        'noplaylist': True,
        'user_agent': user_agent,
        'referer': 'https://www.instagram.com/',
        'headers': {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'X-IG-App-ID': '936619743392459',
        },
        'socket_timeout': 30,
        'retries': 3,
    }
    
    # Добавляем прокси если есть
    if proxy:
        ydl_opts['proxy'] = proxy
    
    # Пробуем использовать cookies из браузера
    try:
        import browser_cookie3
        cookies = browser_cookie3.chrome(domain_name='instagram.com')
        if cookies:
            cookies_file = tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt')
            for cookie in cookies:
                cookies_file.write(
                    f"{cookie.domain}\tTRUE\t{cookie.path}\tFALSE\t"
                    f"{cookie.expires or 0}\t{cookie.name}\t{cookie.value}\n"
                )
            cookies_file.close()
            ydl_opts['cookiefile'] = cookies_file.name
    except Exception:
        pass
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])
        
        # Проверяем что файл создан
        possible_files = list(output_file.parent.glob(f"{output_file.stem}.*"))
        video_files = [f for f in possible_files if f.suffix in ['.mp4', '.webm', '.mkv', '.m4a']]
        
        if video_files:
            downloaded_file = video_files[0]
            if downloaded_file != output_file:
                downloaded_file.rename(output_file)
            print(f"✅ Видео скачано через yt-dlp: {output_path}")
            return True
        else:
            print(f"Файл не найден после скачивания: {output_path}")
            return False
            
    except Exception as e:
        print(f"Ошибка скачивания через yt-dlp: {e}")
        return False
```

---

## 4. pyigdl библиотека

Специализированная библиотека для Instagram.

### Установка:
```bash
pip install pyigdl
```

### Реализация:

```python
from pyigdl import InstagramDownloader
from pathlib import Path
import random

def download_video_pyigdl(url: str, output_path: str, user_agents_file: str = "useragents.txt") -> bool:
    """
    Скачать видео через pyigdl библиотеку.
    
    Args:
        url: URL поста Instagram
        output_path: Путь для сохранения
        user_agents_file: Путь к файлу с user agents
    
    Returns:
        True если успешно
    """
    user_agents = load_user_agents(user_agents_file)
    user_agent = random.choice(user_agents)
    
    try:
        downloader = InstagramDownloader()
        
        # Устанавливаем user agent
        downloader.session.headers.update({
            'User-Agent': user_agent,
        })
        
        # Получаем информацию о посте
        media_info = downloader.get_media_info(url)
        
        if not media_info:
            print("Не удалось получить информацию о посте")
            return False
        
        # Извлекаем URL видео
        video_url = None
        if hasattr(media_info, 'video_url'):
            video_url = media_info.video_url
        elif isinstance(media_info, dict):
            video_url = media_info.get('video_url') or media_info.get('url')
        
        if not video_url:
            print("Видео URL не найден")
            return False
        
        # Скачиваем видео
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        response = downloader.session.get(video_url, stream=True, timeout=60)
        response.raise_for_status()
        
        with open(output_file, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        print(f"✅ Видео скачано через pyigdl: {output_path}")
        return True
        
    except Exception as e:
        print(f"Ошибка скачивания через pyigdl: {e}")
        return False
```

---

## 5. Instagram API v1 метод

Использование неофициального API Instagram v1.

### Реализация:

```python
import requests
import json
import random

def download_video_api_v1(url: str, output_path: str, user_agents_file: str = "useragents.txt") -> bool:
    """
    Скачать видео через Instagram API v1.
    
    Args:
        url: URL поста Instagram
        output_path: Путь для сохранения
        user_agents_file: Путь к файлу с user agents
    
    Returns:
        True если успешно
    """
    user_agents = load_user_agents(user_agents_file)
    user_agent = random.choice(user_agents)
    
    shortcode = extract_shortcode(url)
    if not shortcode:
        return False
    
    session = requests.Session()
    
    # Получаем информацию о посте через API v1
    api_url = f"https://www.instagram.com/api/v1/media/{shortcode}/info/"
    
    headers = {
        'User-Agent': user_agent,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'X-IG-App-ID': '936619743392459',
        'X-Requested-With': 'XMLHttpRequest',
        'Referer': f'https://www.instagram.com/p/{shortcode}/',
        'Origin': 'https://www.instagram.com',
    }
    
    try:
        response = session.get(api_url, headers=headers, timeout=30)
        
        if response.status_code == 200:
            data = response.json()
            
            # Извлекаем URL видео
            video_url = None
            try:
                items = data.get('items', [])
                if items:
                    item = items[0]
                    if item.get('media_type') == 2:  # 2 = видео
                        video_versions = item.get('video_versions', [])
                        if video_versions:
                            # Берем лучшее качество
                            video_url = video_versions[0].get('url')
            except Exception as e:
                print(f"Ошибка парсинга API ответа: {e}")
                return False
            
            if video_url:
                return download_video_file(session, video_url, output_path)
            else:
                print("URL видео не найден в ответе API")
                return False
        else:
            print(f"Ошибка API запроса: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"Ошибка запроса к API v1: {e}")
        return False
```

---

## 6. Selenium метод

Использование Selenium для получения прямых ссылок на видео.

### Реализация:

```python
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time
import random
import requests

def download_video_selenium(url: str, output_path: str, user_agents_file: str = "useragents.txt",
                           proxy: Optional[str] = None) -> bool:
    """
    Скачать видео через Selenium (получаем прямую ссылку, затем скачиваем через requests).
    
    Args:
        url: URL поста Instagram
        output_path: Путь для сохранения
        user_agents_file: Путь к файлу с user agents
        proxy: Прокси (опционально)
    
    Returns:
        True если успешно
    """
    user_agents = load_user_agents(user_agents_file)
    user_agent = random.choice(user_agents)
    
    chrome_options = Options()
    chrome_options.add_argument("--headless=new")
    chrome_options.add_argument("--no-sandbox")
    chrome_options.add_argument("--disable-dev-shm-usage")
    chrome_options.add_argument("--disable-blink-features=AutomationControlled")
    chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
    chrome_options.add_experimental_option('useAutomationExtension', False)
    chrome_options.add_argument(f"--user-agent={user_agent}")
    
    if proxy:
        chrome_options.add_argument(f"--proxy-server={proxy}")
    
    service = Service(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    
    try:
        driver.get(url)
        time.sleep(5)  # Ждем загрузки
        
        # Ищем видео элемент
        video_elements = driver.find_elements("tag name", "video")
        
        if video_elements:
            video_url = video_elements[0].get_attribute("src")
            if video_url:
                # Скачиваем через requests
                session = requests.Session()
                session.headers.update({'User-Agent': user_agent})
                
                return download_video_file(session, video_url, output_path)
        
        # Альтернативный способ - ищем в JavaScript переменных
        page_source = driver.page_source
        
        # Ищем video_url в HTML
        import re
        patterns = [
            r'"video_url":"([^"]+)"',
            r'"videoUrl":"([^"]+)"',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, page_source)
            for match_url in matches:
                video_url = match_url.replace('\\u0026', '&').replace('\\/', '/')
                if video_url.startswith('http'):
                    session = requests.Session()
                    session.headers.update({'User-Agent': user_agent})
                    return download_video_file(session, video_url, output_path)
        
        print("Не удалось найти URL видео через Selenium")
        return False
        
    except Exception as e:
        print(f"Ошибка Selenium: {e}")
        return False
    finally:
        driver.quit()
```

---

## 7. HTML парсинг

Парсинг HTML страницы с BeautifulSoup для извлечения видео URL.

### Реализация:

```python
from bs4 import BeautifulSoup
import requests
import json
import re
import random

def download_video_html_parsing(url: str, output_path: str, user_agents_file: str = "useragents.txt") -> bool:
    """
    Скачать видео через парсинг HTML страницы.
    
    Args:
        url: URL поста Instagram
        output_path: Путь для сохранения
        user_agents_file: Путь к файлу с user agents
    
    Returns:
        True если успешно
    """
    user_agents = load_user_agents(user_agents_file)
    user_agent = random.choice(user_agents)
    
    session = requests.Session()
    
    headers = {
        'User-Agent': user_agent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    
    try:
        response = session.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Ищем meta теги с видео
        video_url = None
        
        # og:video
        og_video = soup.find('meta', property='og:video')
        if og_video:
            video_url = og_video.get('content')
        
        # og:video:secure_url
        if not video_url:
            og_video_secure = soup.find('meta', property='og:video:secure_url')
            if og_video_secure:
                video_url = og_video_secure.get('content')
        
        # Ищем в script тегах
        if not video_url:
            scripts = soup.find_all('script', type='application/ld+json')
            for script in scripts:
                try:
                    data = json.loads(script.string)
                    if isinstance(data, dict):
                        video_url = data.get('contentUrl') or data.get('video', {}).get('contentUrl')
                        if video_url:
                            break
                except:
                    continue
        
        # Ищем в window._sharedData
        if not video_url:
            scripts = soup.find_all('script')
            for script in scripts:
                if script.string and 'window._sharedData' in script.string:
                    match = re.search(r'window\._sharedData\s*=\s*({.+?});', script.string, re.DOTALL)
                    if match:
                        try:
                            data = json.loads(match.group(1))
                            video_url = extract_video_url_from_data(data)
                            if video_url:
                                break
                        except:
                            continue
        
        if video_url:
            return download_video_file(session, video_url, output_path)
        else:
            print("Не удалось найти URL видео в HTML")
            return False
            
    except Exception as e:
        print(f"Ошибка HTML парсинга: {e}")
        return False
```

---

## 8. Комбинированный подход

**Рекомендуемый метод** - пробовать все методы по очереди до успеха.

### Реализация:

```python
def download_video_combined(url: str, output_path: str, user_agents_file: str = "useragents.txt",
                           proxy: Optional[str] = None) -> bool:
    """
    Комбинированный метод - пробует все способы по очереди.
    
    Порядок попыток:
    1. yt-dlp (самый надежный)
    2. GraphQL API
    3. Прямые HTTP запросы
    4. HTML парсинг
    5. Instagram API v1
    6. Selenium (самый медленный)
    
    Args:
        url: URL поста Instagram
        output_path: Путь для сохранения
        user_agents_file: Путь к файлу с user agents
        proxy: Прокси (опционально)
    
    Returns:
        True если успешно
    """
    methods = [
        ("yt-dlp", lambda: download_video_ytdlp(url, output_path, user_agents_file, proxy)),
        ("GraphQL API", lambda: download_video_graphql(url, output_path, user_agents_file)),
        ("Прямые HTTP", lambda: download_video_direct(url, output_path, user_agents_file)),
        ("HTML парсинг", lambda: download_video_html_parsing(url, output_path, user_agents_file)),
        ("API v1", lambda: download_video_api_v1(url, output_path, user_agents_file)),
        ("Selenium", lambda: download_video_selenium(url, output_path, user_agents_file, proxy)),
    ]
    
    for method_name, method_func in methods:
        print(f"Пробую метод: {method_name}...")
        try:
            if method_func():
                print(f"✅ Успешно через {method_name}")
                return True
        except Exception as e:
            print(f"Ошибка метода {method_name}: {e}")
            continue
    
    print("❌ Все методы не сработали")
    return False
```

---

## 📝 Важные замечания

### 1. Ротация User Agents
- Используйте разные user agents из файла `useragents.txt` для каждого запроса
- Это помогает избежать детекции автоматизации

### 2. Задержки между запросами
- Добавляйте случайные задержки между запросами (15-30 секунд)
- Имитируйте поведение человека

### 3. Прокси
- Используйте прокси для обхода IP блокировок
- Рекомендуются residential прокси

### 4. Cookies
- Используйте cookies из браузера для авторизованных запросов
- Это повышает успешность скачивания

### 5. Обновление doc_id
- Для GraphQL метода нужно регулярно обновлять `doc_id`
- Можно найти в DevTools браузера при открытии поста

### 6. Rate Limiting
- Instagram ограничивает ~200 запросов/час на IP
- Используйте прокси и задержки

---

## 🚀 Быстрый старт

```python
from instagram_downloader import download_video_combined

# Скачать видео одним вызовом (пробует все методы)
success = download_video_combined(
    url="https://www.instagram.com/p/ABC123/",
    output_path="video.mp4",
    user_agents_file="useragents.txt",
    proxy="http://proxy:port"  # опционально
)
```

---

## 📚 Дополнительные ресурсы

- [yt-dlp документация](https://github.com/yt-dlp/yt-dlp)
- [pyigdl GitHub](https://github.com/CrypticGuy/pyigdl)
- [Instagram GraphQL исследование](https://medium.com/@seotanvirbd/how-i-built-a-python-tool-that-extracts-instagram-reel-data-without-authentication-api-keys-or-0fcb35cba7b7)

---

**Примечание**: Эти методы предназначены для образовательных целей. Убедитесь, что вы соблюдаете Terms of Service Instagram и законы вашей страны.
