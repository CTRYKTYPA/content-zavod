# Instagram GraphQL метод парсинга ссылок (2026) - БЕЗ Facebook токена!

## ✅ ХОРОШИЕ НОВОСТИ!

В вашем проекте **УЖЕ РЕАЛИЗОВАН** рабочий метод парсинга через GraphQL API, который **НЕ ТРЕБУЕТ Facebook токена**!

## 🎯 Метод: GraphQL API через авторизованную сессию

### Как это работает:

1. **Авторизация через Instagram** (ваш логин/пароль)
2. **Использование GraphQL endpoints** Instagram
3. **Парсинг JSON ответов** с постами

### Где находится:

- **Файл**: `modules/thematic_collectors/humor_collector.py`
- **Метод**: `_get_hashtag_posts_via_api()`
- **Используется автоматически** при сборе контента

## 📝 Как использовать:

### Вариант 1: Через тематический сборщик (РЕКОМЕНДУЕТСЯ)

```python
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import Topic
from modules.thematic_collectors.humor_collector import HumorCollector

# Подключение к БД
engine = create_engine("sqlite:///content_zavod.db")
Session = sessionmaker(bind=engine)
db = Session()

# Получаем тему
topic = db.query(Topic).filter(Topic.name == "Юмор").first()

# Создаем сборщик
collector = HumorCollector(db, topic)

# Собираем ссылки (автоматически использует GraphQL если доступен)
result = collector.collect_and_download(limit=10, download=False)
print(f"Найдено ссылок: {result['found']}")
```

### Вариант 2: Напрямую через метод

```python
import requests
from modules.thematic_collectors.humor_collector import HumorCollector
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from database.models import Topic

# Создаем сессию requests
session = requests.Session()

# Авторизуемся в Instagram
# (используйте ваш метод авторизации или instaloader)

# Создаем сборщик
engine = create_engine("sqlite:///content_zavod.db")
Session = sessionmaker(bind=engine)
db = Session()
topic = db.query(Topic).filter(Topic.name == "Юмор").first()
collector = HumorCollector(db, topic)

# Получаем ссылки через GraphQL
links = collector._get_hashtag_posts_via_api(session, "funnyvideos", limit=50)
print(f"Найдено {len(links)} ссылок")
```

## 🔧 Технические детали

### Endpoints, которые используются:

1. **Основной endpoint**:
   ```
   https://www.instagram.com/api/v1/tags/web_info/?tag_name={hashtag}
   ```

2. **Альтернативные endpoints**:
   ```
   https://www.instagram.com/explore/tags/{hashtag}/?__a=1&__d=dis
   https://www.instagram.com/explore/tags/{hashtag}/?__a=1
   ```

3. **GraphQL с query_hash**:
   ```
   https://www.instagram.com/graphql/query/?query_hash={hash}&variables={json}
   ```

### Query hashes, которые используются:

- `9b498c08113f1e09617a1703c22b2f32` - Основной
- `f92f56e47e7a818121d18262dce6ec2a` - Альтернативный 1
- `174a25488b2c2dd3beda9c03f5093488` - Альтернативный 2

### Структуры данных, которые парсятся:

1. `data.hashtag.edge_hashtag_to_media.edges`
2. `data.hashtag.edge_hashtag_to_top_posts.edges`
3. `data.recent.sections[].layout_content.medias`
4. `graphql.hashtag.edge_hashtag_to_media.edges`

## ⚙️ Требования

1. **Авторизованная сессия Instagram**:
   - Нужен `sessionid` cookie (или другие cookies авторизации)
   - Нужен `csrftoken` cookie
   - Сессия должна быть активной

2. **Правильные заголовки**:
   - `X-IG-App-ID: 936619743392459` (веб-версия)
   - `X-CSRFToken` (из cookies)
   - `User-Agent` (реалистичный браузерный)

## 🚀 Запуск сбора

### Через скрипт:

```bash
python run_thematic_collection.py humor 10
```

Этот скрипт:
1. Автоматически авторизуется в Instagram
2. Использует GraphQL API для сбора ссылок
3. Сохраняет ссылки в файлы `instagram_links/`
4. Сохраняет в базу данных

### Порядок методов (приоритет):

1. **Instagram Graph API** (если есть Facebook токен) - НЕ РАБОТАЕТ с IGAAT токеном
2. **Selenium** - работает, но медленно
3. **GraphQL API** - ✅ **РАБОТАЕТ БЕЗ FACEBOOK ТОКЕНА!**
4. **Instaloader** - работает, но может быть заблокирован

## 📊 Преимущества GraphQL метода:

✅ **Не требует Facebook токена**
✅ **Быстрее чем Selenium**
✅ **Работает с обычным Instagram аккаунтом**
✅ **Не требует App Review**
✅ **Уже реализован в проекте**

## ⚠️ Ограничения:

- Требуется авторизация в Instagram (логин/пароль)
- Может быть заблокирован при частых запросах
- Query hashes могут меняться (но код уже обрабатывает это)
- Instagram может обновлять endpoints

## 🔍 Отладка

Если метод не работает:

1. **Проверьте авторизацию**:
   ```python
   # В коде есть детальная проверка cookies
   logger.debug(f"Все cookies: {list(session.cookies.keys())}")
   ```

2. **Проверьте JSON ответы**:
   - JSON сохраняются в `debug_html/instagram_{hashtag}_api_response.json`
   - GraphQL JSON сохраняются в `debug_html/instagram_{hashtag}_graphql.json`

3. **Проверьте логи**:
   - Метод выводит детальную информацию о каждом шаге
   - Показывает какие endpoints пробуются
   - Показывает структуру найденных данных

## 🎯 Рекомендации

1. **Используйте этот метод как основной** для сбора ссылок
2. **Selenium и Instaloader** оставьте как резервные методы
3. **Мониторьте логи** на предмет блокировок
4. **Используйте прокси** если нужен больший объем запросов

## 📚 Связанные файлы

- `modules/thematic_collectors/humor_collector.py` - Основная реализация
- `run_thematic_collection.py` - Скрипт для запуска сбора
- `modules/content_collector/instagram_collector.py` - Базовый коллектор

---

**Вывод**: GraphQL метод УЖЕ РАБОТАЕТ в вашем проекте! Просто запустите сбор через `run_thematic_collection.py` и он автоматически будет использоваться!
