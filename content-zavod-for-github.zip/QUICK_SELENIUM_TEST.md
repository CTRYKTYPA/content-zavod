# 🚀 Быстрый тест логина через Selenium

## 📋 Что сделано

Создан упрощенный модуль `quick_selenium_login.py` который:
- ✅ Быстро проверяет cookies из браузера
- ✅ Если cookies не работают, пробует только 2 метода:
  1. **Undetected-ChromeDriver** (МЕТОД 1)
  2. **Nodriver** (МЕТОД 2)
- ❌ **НЕ тратит время** на другие методы

## 🎯 Как использовать

### Вариант 1: Быстрая проверка cookies

```bash
python quick_test_cookies.py
```

Проверяет все браузеры и показывает какой работает.

### Вариант 2: Полный тест (cookies + Selenium)

```bash
python quick_selenium_login.py
```

Этот скрипт:
1. Сначала проверяет cookies из браузера
2. Если cookies не работают, пробует Undetected-ChromeDriver
3. Если не сработал, пробует Nodriver
4. Показывает результат

## ⚡ Порядок методов (только быстрые!)

1. **Cookies из браузера** - самый быстрый (если работает)
2. **Undetected-ChromeDriver** - основной метод Selenium
3. **Nodriver** - резервный метод Selenium

**Убрано:**
- ❌ Логин через requests (медленно и блокируется)
- ❌ Другие методы авторизации

## 🔧 Требования

```bash
pip install undetected-chromedriver nodriver browser-cookie3
```

## 📝 Настройка

В `.env` должны быть:
```
INSTAGRAM_USERNAME=ваш_логин
INSTAGRAM_PASSWORD=ваш_пароль
```

## ⚠️ Важно

1. **Для cookies**: Закройте браузер перед запуском
2. **Для Selenium**: Браузер должен быть закрыт (Undetected-ChromeDriver создаст свой)

## 🎉 Результат

Если успешно:
- ✅ Сессия с cookies готова к использованию
- ✅ Можно запускать сбор: `python run_thematic_collection.py humor 10`

Если не успешно:
- ❌ Instagram блокирует логин
- 💡 Используйте cookies из браузера (закройте браузер и запустите снова)
