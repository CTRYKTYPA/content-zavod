# Установка зависимостей

## Шаг 1: Создать виртуальное окружение

### Windows (PowerShell):
```powershell
python -m venv venv
```

### Windows (CMD):
```cmd
python -m venv venv
```

### Linux/Mac:
```bash
python3 -m venv venv
```

## Шаг 2: Активировать виртуальное окружение

### Windows (PowerShell):
```powershell
.\venv\Scripts\Activate.ps1
```

Если выдаёт ошибку про выполнение скриптов, выполните:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Windows (CMD):
```cmd
venv\Scripts\activate.bat
```

### Linux/Mac:
```bash
source venv/bin/activate
```

После активации в начале строки появится `(venv)`.

## Шаг 3: Установить зависимости

```bash
pip install -r requirements.txt
```

Это установит все необходимые пакеты, включая:
- psycopg2-binary (для PostgreSQL)
- instaloader (для Instagram)
- python-telegram-bot (для Telegram-бота)
- и другие...

## Шаг 4: Проверить установку

```bash
python simple_test.py
```

Если всё установлено правильно, увидите:
```
✅ Всё работает! Можно запускать: python run.py
```

## Если что-то не работает

### Проблема: "pip не найден"
Установите pip или используйте:
```bash
python -m pip install -r requirements.txt
```

### Проблема: Ошибки при установке psycopg2
Убедитесь, что используете `psycopg2-binary` (уже в requirements.txt)

### Проблема: Ошибки при установке на Windows
Некоторые пакеты требуют Visual C++ Build Tools. Установите их или используйте предкомпилированные версии.
