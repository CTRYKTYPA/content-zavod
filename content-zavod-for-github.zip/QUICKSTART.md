# Быстрый старт

## 1. Настройка окружения

Создайте файл `.env`:

```bash
# Telegram Bot
TELEGRAM_BOT_TOKEN=8541245358:AAEkODhnLBVvU5m-Je_LK4r_AUn20Q05Op8
TELEGRAM_ADMIN_IDS=[465138834]

# База данных
DATABASE_URL=postgresql://user:password@localhost:5432/content_zavod

# Redis
REDIS_URL=redis://localhost:6379/0

# Instagram (опционально, для авторизации)
INSTAGRAM_USERNAME=your_username
INSTAGRAM_PASSWORD=your_password
```

## 2. Инициализация базы данных

```bash
python scripts/init_database.py
```

## 3. Создание тематик

```bash
python scripts/setup_topics.py
```

Это создаст 5 тематик:
- Юмор
- Фильмы
- Познавательный
- Бизнес
- Комедийный контент

## 4. Проверка готовности системы

```bash
# Проверка всех зависимостей и настроек
python scripts/check_setup.py
```

## 5. Тест загрузки видео

```bash
# Тест сбора и загрузки видео из Instagram
python scripts/test_video_download.py
```

Этот скрипт:
- Проверит базу данных
- Создаст тестовую тематику и источник (если нужно)
- Соберёт несколько видео из Instagram
- Попробует скачать одно видео
- Покажет результаты

## 6. Добавление источников по хэштегам

```bash
python scripts/add_hashtag_sources.py
```

Это добавит источники по хэштегам для каждой тематики с фильтрами:
- Минимум 1 млн просмотров ИЛИ 10к лайков

## 7. Запуск системы

### Запуск основного приложения (Telegram-бот):

```bash
python main.py
```

### Запуск Celery Worker (в отдельном терминале):

```bash
celery -A modules.scheduler.scheduler.celery_app worker --loglevel=info
```

### Запуск Celery Beat (в отдельном терминале):

```bash
celery -A modules.scheduler.scheduler.celery_app beat --loglevel=info
```

## Использование Telegram-бота

После запуска системы используйте команды в Telegram:

- `/start` - Начать работу
- `/topics` - Просмотр тематик
- `/status` - Статус системы
- `/videos` - Просмотр собранных видео

## Ручной запуск сбора контента

```python
from database import get_db
from modules.content_manager import ContentManager

db = next(get_db())
manager = ContentManager(db)

# Собрать контент из источника (например, ID=1)
videos = manager.collect_content_from_source(source_id=1, limit=10)

# Скачать видео
for video in videos:
    manager.download_video(video.id)

# Обработать видео
for video in videos:
    manager.process_video(video.id)
```

## Фильтры по метрикам

Система автоматически фильтрует видео по метрикам:
- **По умолчанию**: минимум 1 млн просмотров **ИЛИ** 10к лайков
- Можно настроить для каждого источника отдельно через БД или API

## Добавление источников по ключевым словам

```python
from database import get_db
from modules.content_manager import ContentManager

db = next(get_db())
manager = ContentManager(db)

# Добавить источник по ключевым словам
source = manager.add_source(
    topic_id=1,  # ID тематики
    source_type="keywords",
    source_value="юмор,приколы,смех",  # Ключевые слова через запятую
    min_views=1000000,  # Минимум просмотров
    min_likes=10000     # Минимум лайков
)
```

## Важные замечания

1. **Instagram авторизация**: Для сбора контента может потребоваться авторизация в Instagram. Первый раз система попросит ввести пароль интерактивно.

2. **Фильтрация**: Система собирает только видео с высокими метриками (1 млн+ просмотров или 10к+ лайков).

3. **Длительность**: Ограничения по длительности видео отключены - важны только метрики охвата.

4. **Автоматический сбор**: Celery автоматически собирает контент каждые 30 минут из всех активных источников.
