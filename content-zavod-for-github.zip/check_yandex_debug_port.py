"""
Проверка доступности remote debugging порта Яндекс браузера.
"""
import urllib.request
import json
import sys
import io

# Настройка кодировки для Windows
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

print("="*80)
print("ПРОВЕРКА REMOTE DEBUGGING ПОРТА ЯНДЕКС БРАУЗЕРА")
print("="*80)

ports_to_check = [9222, 9223, 9224, 9225]

for port in ports_to_check:
    print(f"\nПроверяю порт {port}...")
    try:
        url = f"http://127.0.0.1:{port}/json"
        with urllib.request.urlopen(url, timeout=2) as response:
            tabs = json.loads(response.read().decode())
            print(f"✅ Порт {port} ДОСТУПЕН!")
            print(f"   Найдено вкладок: {len(tabs)}")
            
            # Показываем вкладки
            for i, tab in enumerate(tabs[:5], 1):  # Показываем первые 5
                url_tab = tab.get('url', 'unknown')
                title = tab.get('title', 'unknown')
                print(f"   {i}. {title[:50]} - {url_tab[:60]}")
            
            if len(tabs) > 5:
                print(f"   ... и еще {len(tabs) - 5} вкладок")
            
            # Проверяем есть ли Instagram
            instagram_found = any('instagram.com' in tab.get('url', '') for tab in tabs)
            if instagram_found:
                print(f"   ✅ Найдена вкладка Instagram!")
            else:
                print(f"   ⚠️  Вкладка Instagram не найдена")
                print(f"   Откройте Instagram в браузере")
            
            print(f"\n✅✅✅ ПОРТ {port} РАБОТАЕТ! Можно использовать для получения cookies!")
            sys.exit(0)
            
    except urllib.error.HTTPError as e:
        if e.code == 502:
            print(f"⚠️  Порт {port} отвечает, но remote debugging не настроен (502 Bad Gateway)")
            print(f"   Запустите браузер с флагом --remote-debugging-port={port}")
        else:
            print(f"❌ Порт {port} вернул ошибку HTTP {e.code}: {e}")
    except urllib.error.URLError as e:
        print(f"❌ Порт {port} недоступен: {e}")
    except Exception as e:
        print(f"❌ Ошибка на порту {port}: {e}")

print("\n" + "="*80)
print("❌ НИ ОДИН ПОРТ НЕ ДОСТУПЕН")
print("="*80)
print("\nРЕШЕНИЕ:")
print("1. Запустите Яндекс браузер с remote debugging:")
print('   python start_yandex_with_debug.py')
print("\nИли вручную:")
print('   "C:\\Users\\Даниил\\AppData\\Local\\Yandex\\YandexBrowser\\Application\\browser.exe" --remote-debugging-port=9222')
print("\n2. Откройте Instagram в браузере")
print("3. Запустите этот скрипт снова")
