"""Тест системы с VPN - проверка работает ли."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("=" * 60)
print("ТЕСТ СИСТЕМЫ С VPN")
print("=" * 60)

print("\nПроверяю работает ли система с VPN...")
print("(VPN должен быть включен на компьютере)\n")

from config import settings
import instaloader

username = settings.INSTAGRAM_USERNAME
password = settings.INSTAGRAM_PASSWORD

if not username:
    print("Ошибка: INSTAGRAM_USERNAME не указан в .env")
    exit(1)

# Проверяем текущий IP
print("Проверяю IP адрес...")
try:
    import requests
    response = requests.get("https://api.ipify.org?format=json", timeout=5)
    current_ip = response.json()["ip"]
    print(f"Текущий IP: {current_ip}")
    
    # Проверяем страну
    try:
        ip_info = requests.get(f"https://ipapi.co/{current_ip}/json/", timeout=5)
        country = ip_info.json().get("country_name", "Unknown")
        print(f"Страна: {country}")
        
        if country == "United States":
            print("OK: VPN работает! IP из США.")
        else:
            print(f"VPN активен, IP из {country}")
    except:
        print("Не удалось определить страну, но VPN может работать")
except Exception as e:
    print(f"Не удалось проверить IP: {e}")
    print("Продолжаю тест...")

print("\nПробую войти в Instagram...")

try:
    # Используем мобильный User-Agent
    mobile_user_agent = "Instagram 219.0.0.12.117 Android (29/10; 480dpi; 1080x2134; samsung; SM-G973F; beyond1; exynos9820; en_US; 314665256)"
    L = instaloader.Instaloader(user_agent=mobile_user_agent)
    
    device_id = str(abs(hash(username)))[:16]
    L.context._session.headers.update({
        'X-IG-App-ID': '567067343352427',
        'X-IG-Device-ID': f'android-{device_id}',
        'X-IG-Android-ID': f'android-{device_id}',
    })
    
    # Проверяем сохранённую сессию
    try:
        from instaloader.instaloader import get_default_session_filename
        session_file = get_default_session_filename(username)
        if Path(session_file).exists():
            print("Найдена сохранённая сессия, пробую загрузить...")
            L.load_session_from_file(username)
            test_user = L.test_login()
            if test_user:
                print(f"OK: Сессия работает! Пользователь: {test_user}")
                print("\nСистема работает с VPN!")
                exit(0)
    except:
        pass
    
    print("Вхожу автоматически...")
    L.login(username, password)
    
    print("OK: Успешный вход!")
    L.save_session_to_file()
    print("OK: Сессия сохранена!")
    
    test_user = L.test_login()
    if test_user:
        print(f"OK: Подтверждено! Пользователь: {test_user}")
        print("\nСистема работает с VPN!")
        print("Можно использовать VPN вместо прокси!")
    
except Exception as e:
    error_msg = str(e)
    print(f"Ошибка: {error_msg}")
    
    if "challenge_required" in error_msg or "Checkpoint" in error_msg:
        print("\nТребуется checkpoint даже с VPN.")
        print("\nРешения:")
        print("1. Подтвердите checkpoint через телефон/браузер")
        print("2. Или используйте резидентные прокси (но это платно)")
        print("3. Или подождите несколько часов и попробуйте снова")
    elif "Wrong password" in error_msg:
        print("\nInstagram временно блокирует вход.")
        print("Попробуйте:")
        print("1. Другой сервер VPN")
        print("2. Подождать 2-4 часа")
        print("3. Или использовать резидентные прокси")
    else:
        print("\nПопробуйте:")
        print("1. Другой сервер VPN")
        print("2. Подождать несколько часов")
        print("3. Или использовать резидентные прокси")
