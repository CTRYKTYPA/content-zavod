"""Модуль обработки видео."""
from .processor import VideoProcessor

__all__ = ["VideoProcessor"]
