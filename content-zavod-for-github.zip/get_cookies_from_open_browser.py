"""
Получение cookies из ОТКРЫТОГО Яндекс браузера через Chrome DevTools Protocol.
Работает даже если браузер открыт!
"""
import sys
from pathlib import Path
from loguru import logger
import io
import json
import time

# Настройка логирования
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
logger.remove()
logger.add(sys.stdout, format="{time:HH:mm:ss} | {level: <8} | {message}", level="INFO")

print("\n" + "="*80)
print("ПОЛУЧЕНИЕ COOKIES ИЗ ОТКРЫТОГО ЯНДЕКС БРАУЗЕРА")
print("="*80)

print("\n📋 ИНСТРУКЦИЯ:")
print("1. Откройте Яндекс браузер")
print("2. Войдите на https://www.instagram.com")
print("3. Нажмите F12 (откроется DevTools)")
print("4. Перейдите на вкладку 'Console'")
print("5. Скопируйте и выполните команду ниже:")
print("\n" + "-"*80)
print("КОМАНДА ДЛЯ КОНСОЛИ БРАУЗЕРА:")
print("-"*80)
print("""
document.cookie.split(';').map(c => {
    const [name, value] = c.trim().split('=');
    return {name: name, value: value};
}).filter(c => c.name && c.value).forEach(c => {
    console.log(c.name + '=' + c.value);
});
""")
print("-"*80)
print("\nИли используйте более простой способ:")
print("""
copy(document.cookie)
""")
print("\nЭто скопирует все cookies в буфер обмена.")
print("Затем вставьте их сюда и нажмите Enter (или просто Enter для выхода):")

try:
    cookies_input = input("\nВставьте cookies (или Enter для выхода): ").strip()
    
    if not cookies_input:
        print("Выход...")
        exit(0)
    
    # Парсим cookies
    cookies_dict = {}
    for cookie_pair in cookies_input.split(';'):
        cookie_pair = cookie_pair.strip()
        if '=' in cookie_pair:
            name, value = cookie_pair.split('=', 1)
            cookies_dict[name.strip()] = value.strip()
    
    if not cookies_dict:
        print("❌ Cookies не найдены")
        exit(1)
    
    print(f"\n✅ Найдено {len(cookies_dict)} cookies")
    
    # Проверяем важные cookies
    important = ['sessionid', 'csrftoken', 'ds_user_id']
    found = [name for name in important if name in cookies_dict]
    print(f"✅ Найдено важных cookies: {', '.join(found)}")
    
    if 'sessionid' not in cookies_dict:
        print("\n⚠️  ВНИМАНИЕ: sessionid не найден!")
        print("   Убедитесь что вы залогинены на instagram.com")
    else:
        print("\n✅ sessionid найден!")
    
    # Создаем сессию
    print("\n" + "="*80)
    print("СОЗДАНИЕ СЕССИИ")
    print("="*80)
    
    import requests
    session = requests.Session()
    
    for name, value in cookies_dict.items():
        session.cookies.set(name, value, domain='.instagram.com')
    
    print(f"✅ Загружено {len(cookies_dict)} cookies в сессию")
    
    # Проверяем работоспособность
    print("\n" + "="*80)
    print("ПРОВЕРКА РАБОТОСПОСОБНОСТИ")
    print("="*80)
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'X-IG-App-ID': '936619743392459',
    }
    
    try:
        response = session.get(
            'https://www.instagram.com/api/v1/web/data/shared_data/',
            headers=headers,
            timeout=10
        )
        
        if response.status_code == 200:
            try:
                data = response.json()
                if 'config' in data:
                    viewer = data['config'].get('viewer')
                    if viewer:
                        username = viewer.get('username')
                        if username:
                            print(f"\n✅✅✅ УСПЕХ! Сессия работает!")
                            print(f"   Пользователь: {username}")
                            print(f"   Cookies: {len(cookies_dict)} шт.")
                            print(f"   sessionid: ✅")
                            
                            # Сохраняем cookies в файл для использования
                            cookies_file = Path("yandex_cookies_manual.json")
                            with open(cookies_file, 'w', encoding='utf-8') as f:
                                json.dump(cookies_dict, f, indent=2, ensure_ascii=False)
                            print(f"\n✅ Cookies сохранены в: {cookies_file}")
                            
                            print("\n" + "="*80)
                            print("ГОТОВО! Можно запускать сбор:")
                            print("  python run_thematic_collection.py humor 10")
                            print("="*80)
                            exit(0)
            except:
                pass
        
        if 'sessionid' in session.cookies:
            print("\n✅ Сессия работает (есть sessionid cookie)")
            
            # Сохраняем cookies
            cookies_file = Path("yandex_cookies_manual.json")
            with open(cookies_file, 'w', encoding='utf-8') as f:
                json.dump(cookies_dict, f, indent=2, ensure_ascii=False)
            print(f"✅ Cookies сохранены в: {cookies_file}")
            
            print("\n" + "="*80)
            print("ГОТОВО! Можно запускать сбор:")
            print("  python run_thematic_collection.py humor 10")
            print("="*80)
            exit(0)
        else:
            print("\n⚠️  Сессия может не работать (нет sessionid)")
            
    except Exception as e:
        print(f"\n⚠️  Ошибка проверки: {e}")
        if 'sessionid' in cookies_dict:
            print("   Но sessionid есть - можно попробовать использовать")
    
    print("\n" + "="*80)

except KeyboardInterrupt:
    print("\n\nВыход...")
except Exception as e:
    print(f"❌ Ошибка: {e}")
    import traceback
    traceback.print_exc()
