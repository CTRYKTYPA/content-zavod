"""Простое исправление авторизации - войдите в браузер и запустите."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from config import settings
import instaloader

print("=" * 60)
print("ПРОСТОЕ ИСПРАВЛЕНИЕ АВТОРИЗАЦИИ")
print("=" * 60)

username = settings.INSTAGRAM_USERNAME

if not username:
    print("Ошибка: INSTAGRAM_USERNAME не указан в .env")
    exit(1)

print(f"\nЛогин: {username}")
print("\nВАЖНО:")
print("1. Откройте Chrome")
print("2. Войдите на https://www.instagram.com")
print("3. Убедитесь что вы залогинены")
print("4. НЕ ЗАКРЫВАЙТЕ браузер")
print()
print("Импортирую сессию из браузера...")
print("(Убедитесь что браузер открыт и вы залогинены на instagram.com)")
print("Жду 3 секунды...")
import time
time.sleep(3)

try:
    import browser_cookie3
    
    # Пробуем разные браузеры (включая Яндекс)
    browsers = []
    
    # Пробуем Яндекс браузер (хранит cookies как Chrome)
    try:
        # Яндекс браузер использует Chrome движок, пробуем через chrome с указанием пути
        import os
        yandex_paths = [
            os.path.expanduser("~/AppData/Local/Yandex/YandexBrowser/User Data"),
            os.path.expanduser("~/.config/yandex-browser"),
        ]
        for yandex_path in yandex_paths:
            if os.path.exists(yandex_path):
                try:
                    cookies_yandex = browser_cookie3.chrome(domain_name="instagram.com", cookie_file=os.path.join(yandex_path, "Default/Cookies"))
                    browsers.append(("Yandex", lambda: cookies_yandex))
                    break
                except:
                    pass
    except:
        pass
    
    # Добавляем стандартные браузеры
    browsers.extend([
        ("Chrome", lambda: browser_cookie3.chrome(domain_name="instagram.com")),
        ("Firefox", lambda: browser_cookie3.firefox(domain_name="instagram.com")),
        ("Edge", lambda: browser_cookie3.edge(domain_name="instagram.com")),
    ])
    
    cookies_found = False
    
    for browser_name, get_cookies in browsers:
        try:
            print(f"Проверяю {browser_name}...")
            cookies = get_cookies()
            cookie_list = list(cookies)
            
            if cookie_list:
                print(f"Найдено cookies в {browser_name}: {len(cookie_list)}")
                cookies_found = True
                
                # Создаём instaloader
                L = instaloader.Instaloader()
                
                # Импортируем cookies
                import requests
                session = requests.Session()
                for cookie in cookies:
                    session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
                
                L.context._session = session
                
                # Проверяем
                test_user = L.test_login()
                if test_user:
                    print(f"OK: Сессия работает! Пользователь: {test_user}")
                    
                    # Сохраняем
                    L.save_session_to_file()
                    print("OK: Сессия сохранена!")
                    print("\nТеперь можно запускать систему:")
                    print("  python test_download.py")
                    exit(0)
                else:
                    print(f"Сессия из {browser_name} не работает, пробую следующий браузер...")
                    continue
        except Exception as e:
            print(f"Ошибка с {browser_name}: {e}")
            continue
    
    if not cookies_found:
        print("\nОшибка: Cookies не найдены ни в одном браузере")
        print("Убедитесь что:")
        print("  - Браузер (Chrome/Yandex/Firefox) открыт")
        print("  - Вы залогинены на instagram.com")
        print("  - Браузер не закрыт")
        print("\nПопробуйте:")
        print("1. Откройте браузер")
        print("2. Войдите на https://www.instagram.com")
        print("3. Убедитесь что вы залогинены")
        print("4. Запустите этот скрипт снова")
    else:
        print("\nНе удалось импортировать сессию из браузеров")
        print("Попробуйте войти в Instagram через браузер снова")

except ImportError:
    print("Ошибка: browser-cookie3 не установлен")
    print("Установите: pip install browser-cookie3")
