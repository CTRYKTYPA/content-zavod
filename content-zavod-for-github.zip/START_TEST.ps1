# PowerShell скрипт для запуска теста
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "ТЕСТИРОВАНИЕ СКАЧИВАНИЯ ВИДЕО С INSTAGRAM" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Все зависимости установлены!" -ForegroundColor Green
Write-Host "User agents загружены: 2913 штук" -ForegroundColor Green
Write-Host ""
Write-Host "Введите URL поста Instagram для тестирования:" -ForegroundColor Yellow
Write-Host "Пример: https://www.instagram.com/p/ABC123/" -ForegroundColor Yellow
Write-Host ""

$url = Read-Host "URL"

if ([string]::IsNullOrWhiteSpace($url)) {
    Write-Host "Ошибка: URL не указан!" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Запускаю тест..." -ForegroundColor Green
Write-Host ""

python run_test_now.py $url

Write-Host ""
Write-Host "Нажмите любую клавишу для выхода..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
