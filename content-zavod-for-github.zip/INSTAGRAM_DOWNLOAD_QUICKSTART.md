# Быстрый старт: Скачивание видео с Instagram БЕЗ instaloader

## 📦 Установка зависимостей

```bash
pip install requests beautifulsoup4 yt-dlp selenium webdriver-manager browser-cookie3
```

## 🚀 Использование

### Вариант 1: Комбинированный метод (рекомендуется)

Пробует все методы по очереди до успеха:

```python
from modules.content_collector.instagram_downloader import download_video_combined

success = download_video_combined(
    url="https://www.instagram.com/p/ABC123/",
    output_path="video.mp4",
    user_agents_file="useragents.txt",  # опционально
    proxy="http://proxy:port"  # опционально
)
```

### Вариант 2: Конкретный метод

```python
from modules.content_collector.instagram_downloader import download_video_ytdlp

success = download_video_ytdlp(
    url="https://www.instagram.com/p/ABC123/",
    output_path="video.mp4",
    user_agents_file="useragents.txt",
    proxy="http://proxy:port"  # опционально
)
```

## 🧪 Тестирование

Запустите тестовый скрипт:

```bash
# Тест комбинированного метода (рекомендуется)
python test_instagram_download.py "https://www.instagram.com/p/ABC123/" --method combined

# Тест всех методов
python test_instagram_download.py "https://www.instagram.com/p/ABC123/" --method all

# Тест конкретного метода
python test_instagram_download.py "https://www.instagram.com/p/ABC123/" --method ytdlp
```

## 📋 Доступные методы

1. **yt-dlp** - Самый надежный, использует yt-dlp библиотеку
2. **GraphQL API** - Прямые запросы к GraphQL эндпоинту Instagram
3. **Прямые HTTP** - Парсинг HTML страницы для извлечения видео URL
4. **HTML парсинг** - Использование BeautifulSoup для парсинга
5. **API v1** - Instagram API v1 (неофициальный)
6. **Selenium** - Автоматизация браузера (самый медленный)

## ⚙️ Настройка

### User Agents

Методы автоматически используют user agents из файла `useragents.txt`. 
Если файл не найден, используются дефолтные.

### Прокси

Можно указать прокси для обхода блокировок:

```python
download_video_combined(
    url="https://www.instagram.com/p/ABC123/",
    output_path="video.mp4",
    proxy="http://username:password@proxy.example.com:8080"
)
```

### Cookies

yt-dlp автоматически пытается использовать cookies из браузера Chrome (если установлен `browser-cookie3`).

## 🔧 Интеграция в существующий код

Замените метод `download_video` в `instagram_collector.py`:

```python
from modules.content_collector.instagram_downloader import download_video_combined

def download_video(self, video_url: str, output_path: str) -> bool:
    """Скачать видео используя альтернативные методы."""
    return download_video_combined(
        url=video_url,
        output_path=output_path,
        user_agents_file="useragents.txt",
        proxy=getattr(self, 'proxy_url', None)
    )
```

## ⚠️ Важные замечания

1. **Rate Limiting**: Instagram ограничивает ~200 запросов/час на IP
2. **User Agents**: Рекомендуется использовать ротацию user agents
3. **Задержки**: Добавляйте задержки между запросами (15-30 секунд)
4. **Прокси**: Используйте residential прокси для лучшей стабильности
5. **doc_id**: Для GraphQL метода нужно обновлять `doc_id` каждые 2-4 недели

## 📚 Подробная документация

См. файл `INSTAGRAM_DOWNLOAD_METHODS.md` для детального описания всех методов.
