# Настройка GitHub Pages для TikTok (Privacy & Terms)

Чтобы TikTok принял ссылки на политику конфиденциальности и условия использования:

1. **Залить в репозиторий** файлы из папки `docs/`:
   - `docs/privacy.html`
   - `docs/terms.html`

2. **Включить GitHub Pages:**
   - Репозиторий на GitHub → **Settings** → слева **Pages**
   - **Source:** Deploy from a branch
   - **Branch:** main (или master) → папка **/docs**
   - **Save**

3. Подождать 1–2 минуты. Сайт будет доступен по адресу:
   - **Privacy Policy URL:** `https://CTRYKTYPA.github.io/content-zavod/privacy.html`
   - **Terms of Service URL:** `https://CTRYKTYPA.github.io/content-zavod/terms.html`

4. Эти две ссылки вставить в форму TikTok (Privacy Policy URL и Terms of Service URL).
