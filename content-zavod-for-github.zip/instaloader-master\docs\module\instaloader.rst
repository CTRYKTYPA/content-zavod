``Instaloader`` (Main Class)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. module:: instaloader
   :no-index:

.. highlight:: python

.. autoclass:: Instaloader
   :no-show-inheritance: