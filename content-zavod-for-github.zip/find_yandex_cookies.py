"""Поиск cookies Яндекс браузера."""
import os
from pathlib import Path

print("Ищу Яндекс браузер...")

# Возможные пути
possible_paths = [
    Path(os.getenv("LOCALAPPDATA")) / "Yandex" / "YandexBrowser",
    Path(os.getenv("LOCALAPPDATA")) / "Yandex",
    Path(os.getenv("APPDATA")) / "Yandex",
    Path.home() / "AppData" / "Local" / "Yandex",
    Path.home() / "AppData" / "Roaming" / "Yandex",
]

found = False

for base_path in possible_paths:
    if base_path.exists():
        print(f"\nНайден: {base_path}")
        
        # Ищем файл Cookies
        for cookies_file in base_path.rglob("Cookies"):
            print(f"  Найден файл cookies: {cookies_file}")
            found = True
        
        # Ищем профили
        user_data = base_path / "User Data"
        if user_data.exists():
            print(f"  Найден User Data: {user_data}")
            for profile in user_data.iterdir():
                if profile.is_dir():
                    cookies = profile / "Cookies"
                    if cookies.exists():
                        print(f"    Профиль: {profile.name}, Cookies: {cookies}")

if not found:
    print("\nЯндекс браузер не найден в стандартных местах")
    print("\nПопробуйте:")
    print("1. Откройте Яндекс браузер")
    print("2. Войдите на instagram.com")
    print("3. Не закрывайте браузер")
    print("4. Запустите: python fix_auth_simple.py")
