"""Простой скрипт для создания тематик."""
import sys
import codecs
from pathlib import Path

# Настройка UTF-8 для Windows
if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

# Добавляем корень проекта в путь
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from database import get_db, init_db
from database.models import Topic

print("Создание тематик...")

# Инициализируем БД
init_db()

db = next(get_db())

# Список тематик
topics_data = [
    {
        "name": "Юмор",
        "description": "Юмористический контент",
        "base_tags": ["юмор", "смех", "приколы", "комедия"],
        "tag_pool": ["смешно", "юмор", "прикол", "комедия", "смех", "веселье", "шутка"],
    },
    {
        "name": "Фильмы",
        "description": "Вырезки из сериалов и фильмов",
        "base_tags": ["фильмы", "сериалы", "кино", "вырезки"],
        "tag_pool": ["фильм", "сериал", "кино", "вырезка", "сцена", "момент", "цитата"],
    },
    {
        "name": "Познавательный",
        "description": "Познавательный контент и факты",
        "base_tags": ["факты", "познавательно", "интересно", "образование"],
        "tag_pool": ["факт", "познавательно", "интересно", "образование", "знание", "наука"],
    },
    {
        "name": "Бизнес",
        "description": "Бизнес, деньги, мотивация",
        "base_tags": ["бизнес", "деньги", "мотивация", "успех"],
        "tag_pool": ["бизнес", "деньги", "мотивация", "успех", "богатство", "финансы", "карьера"],
    },
    {
        "name": "Комедийный контент",
        "description": "Скетчи, короткие сценки, юмористические диалоги, кринж-ситуации",
        "base_tags": ["комедия", "скетч", "сценка", "диалог", "кринж"],
        "tag_pool": ["комедия", "скетч", "сценка", "диалог", "кринж", "юмор", "смешно"],
    }
]

created_count = 0

for topic_data in topics_data:
    # Проверяем, существует ли уже
    existing = db.query(Topic).filter(Topic.name == topic_data["name"]).first()
    if existing:
        print(f"   Пропуск: {topic_data['name']} - уже существует")
        continue
    
    # Создаём
    topic = Topic(
        name=topic_data["name"],
        description=topic_data["description"],
        base_tags=topic_data["base_tags"],
        tag_pool=topic_data["tag_pool"],
        description_template="{emoji} {description}\n\n{cta}"
    )
    db.add(topic)
    created_count += 1
    print(f"   OK: {topic_data['name']}")

db.commit()
db.close()

print(f"\nOK: Создано тематик: {created_count}")
print("\nПроверьте: python simple_test.py")
