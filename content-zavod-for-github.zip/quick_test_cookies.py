"""
Быстрая проверка cookies из браузера для Instagram.
Проверяет все браузеры и показывает какой работает.
"""
import sys
from pathlib import Path
from loguru import logger
import io

# Настройка логирования
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
logger.remove()
logger.add(sys.stdout, format="{time:HH:mm:ss} | {level: <8} | {message}", level="INFO")

import requests
from modules.thematic_collectors.browser_cookies_helper import (
    load_cookies_from_browser,
    test_session
)

def main():
    print("\n" + "="*80)
    print("БЫСТРАЯ ПРОВЕРКА COOKIES ИЗ БРАУЗЕРА")
    print("="*80)
    print("\n⚠️  ВАЖНО: Закройте браузер перед запуском!\n")
    
    # Создаем сессию
    session = requests.Session()
    
    # Пробуем Яндекс браузер ПЕРВЫМ (как просил пользователь)
    browsers = ['yandex', 'chrome', 'firefox', 'edge']
    working_browser = None
    working_username = None
    
    for browser in browsers:
        print(f"\n{'='*80}")
        print(f"Проверяю {browser.upper()}...")
        print(f"{'='*80}")
        
        # Пробуем загрузить cookies
        if load_cookies_from_browser(session, browser=browser):
            # Проверяем работоспособность
            username = test_session(session)
            if username:
                print(f"\n✅ УСПЕХ! {browser.upper()} работает!")
                print(f"   Пользователь: {username}")
                print(f"   Cookies: {len(session.cookies)} шт.")
                print(f"   sessionid: {'✅' if 'sessionid' in session.cookies else '❌'}")
                print(f"   csrftoken: {'✅' if 'csrftoken' in session.cookies else '❌'}")
                
                working_browser = browser
                working_username = username
                break
            else:
                print(f"❌ Cookies из {browser} загружены, но сессия не работает")
        else:
            print(f"❌ Cookies из {browser} не найдены или не загружены")
    
    print("\n" + "="*80)
    if working_browser:
        print(f"✅ РАБОТАЕТ: {working_browser.upper()}")
        print(f"   Пользователь: {working_username}")
        print("\nТеперь можно запускать сбор:")
        print("  python run_thematic_collection.py humor 10")
    else:
        print("❌ НИ ОДИН БРАУЗЕР НЕ РАБОТАЕТ")
        print("\nЧто делать:")
        print("1. Откройте браузер (Chrome/Яндекс/Firefox)")
        print("2. Войдите на https://www.instagram.com")
        print("3. Убедитесь что вы залогинены")
        print("4. ЗАКРОЙТЕ браузер полностью")
        print("5. Запустите этот скрипт снова")
    print("="*80 + "\n")

if __name__ == '__main__':
    main()
