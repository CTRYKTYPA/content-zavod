"""Импорт сессии Instagram из браузера."""
import sys
from pathlib import Path

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("=" * 60)
print("ИМПОРТ СЕССИИ INSTAGRAM ИЗ БРАУЗЕРА")
print("=" * 60)
print("\nЭтот скрипт поможет импортировать сессию из браузера")
print("чтобы обойти checkpoint от Instagram.\n")

print("Инструкция:")
print("1. Откройте браузер (Chrome/Firefox)")
print("2. Войдите в Instagram: https://www.instagram.com")
print("3. Убедитесь что вы залогинены")
print("4. Запустите этот скрипт\n")

try:
    import browser_cookie3
    
    browser = input("Какой браузер используете? (chrome/firefox/edge): ").strip().lower()
    username = input("Логин Instagram: ").strip()
    
    if not username:
        print("Логин обязателен!")
        exit(1)
    
    print("\nИмпортирую cookies из браузера...")
    
    # Импортируем cookies
    if browser == "chrome":
        cookies = browser_cookie3.chrome(domain_name="instagram.com")
    elif browser == "firefox":
        cookies = browser_cookie3.firefox(domain_name="instagram.com")
    elif browser == "edge":
        cookies = browser_cookie3.edge(domain_name="instagram.com")
    else:
        print(f"Неподдерживаемый браузер: {browser}")
        exit(1)
    
    # Создаём сессию
    import instaloader
    L = instaloader.Instaloader()
    
    # Создаём requests session с cookies
    import requests
    session = requests.Session()
    for cookie in cookies:
        session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
    
    # Загружаем сессию в instaloader
    L.context._session = session
    
    # Проверяем что сессия работает
    test_user = L.test_login()
    if test_user:
        print(f"✅ Сессия работает! Пользователь: {test_user}")
        
        # Сохраняем сессию
        L.save_session_to_file()
        print(f"✅ Сессия сохранена для пользователя: {username}")
        print("\nТеперь можно запустить тест:")
        print("  python test_download.py")
    else:
        print("❌ Сессия не работает. Убедитесь что вы залогинены в браузере.")
    
except ImportError:
    print("❌ Модуль browser_cookie3 не установлен")
    print("Установите: pip install browser_cookie3")
except Exception as e:
    print(f"❌ Ошибка: {e}")
    import traceback
    traceback.print_exc()
