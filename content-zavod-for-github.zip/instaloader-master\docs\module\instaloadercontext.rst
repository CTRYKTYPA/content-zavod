``InstaloaderContext`` (Low-level functions)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. module:: instaloader
   :no-index:

.. highlight:: python

.. contents::
   :backlinks: none

``InstaloaderContext``
""""""""""""""""""""""

.. autoclass:: InstaloaderContext
   :no-show-inheritance:

``RateController``
""""""""""""""""""

.. autoclass:: RateController
   :no-show-inheritance:

   .. versionadded:: 4.5
