"""Проверка авторизации Instagram."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from config import settings

print("=" * 60)
print("ПРОВЕРКА АВТОРИЗАЦИИ INSTAGRAM")
print("=" * 60)

username = settings.INSTAGRAM_USERNAME
password = settings.INSTAGRAM_PASSWORD

print(f"\nЛогин из .env: {username}")
print(f"Пароль: {'*' * len(password) if password else 'не указан'}")

if not username:
    print("\nОшибка: INSTAGRAM_USERNAME не указан в .env")
    exit(1)

# Проверяем есть ли сохранённая сессия
import instaloader
from instaloader.instaloader import get_default_session_filename
from pathlib import Path

session_file = get_default_session_filename(username)
print(f"\nФайл сессии: {session_file}")
print(f"Существует: {Path(session_file).exists()}")

if Path(session_file).exists():
    print("\nПробую загрузить сохранённую сессию...")
    try:
        L = instaloader.Instaloader()
        L.load_session_from_file(username)
        test_user = L.test_login()
        if test_user:
            print(f"OK: Сессия работает! Пользователь: {test_user}")
            exit(0)
        else:
            print("Сессия невалидна")
    except Exception as e:
        print(f"Ошибка загрузки сессии: {e}")

# Пробуем импортировать из браузера
print("\nПробую импортировать сессию из браузера...")
try:
    import browser_cookie3
    
    browsers = [
        ("Chrome", lambda: browser_cookie3.chrome(domain_name="instagram.com")),
        ("Firefox", lambda: browser_cookie3.firefox(domain_name="instagram.com")),
        ("Edge", lambda: browser_cookie3.edge(domain_name="instagram.com")),
    ]
    
    for browser_name, get_cookies in browsers:
        try:
            cookies = get_cookies()
            if not cookies:
                continue
            
            print(f"Найдены cookies в {browser_name}")
            
            L = instaloader.Instaloader()
            import requests
            session = requests.Session()
            for cookie in cookies:
                session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
            
            L.context._session = session
            
            test_user = L.test_login()
            if test_user:
                print(f"OK: Сессия работает! Пользователь: {test_user}")
                L.save_session_to_file()
                print("OK: Сессия сохранена!")
                exit(0)
        except Exception as e:
            print(f"Ошибка с {browser_name}: {e}")
            continue
    
    print("\nНе удалось импортировать сессию из браузера")
    print("\nРешение:")
    print("1. Войдите в Instagram через браузер")
    print("2. Убедитесь что вы залогинены")
    print("3. Запустите этот скрипт снова")
    
except ImportError:
    print("\nbrowser-cookie3 не установлен")
    print("Установите: pip install browser-cookie3")
