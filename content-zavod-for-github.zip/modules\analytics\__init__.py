"""Модуль аналитики и отчетности."""
from .analytics import Analytics

__all__ = ["Analytics"]
