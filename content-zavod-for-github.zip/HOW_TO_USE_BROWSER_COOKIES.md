# Как обойти блокировку логина Instagram через cookies из браузера

## 🎯 Проблема

Instagram блокирует автоматический логин через Selenium/requests с нового браузера. Это защита от ботов.

## ✅ Решение: Использовать cookies из реального браузера

Вместо логина через Selenium, мы загружаем cookies из вашего реального браузера, где вы уже залогинены.

## 📝 Инструкция

### Способ 1: Автоматический (РЕКОМЕНДУЕТСЯ)

Просто запустите сбор - код автоматически попробует загрузить cookies из браузера:

```bash
python run_thematic_collection.py humor 10
```

Код автоматически:
1. ✅ Пробует загрузить cookies из Chrome
2. ✅ Пробует загрузить cookies из Яндекс браузера
3. ✅ Пробует загрузить cookies из Firefox
4. ✅ Пробует загрузить cookies из Edge
5. ✅ Если cookies не найдены, пробует логин через requests (может быть заблокирован)

### Способ 2: Ручной импорт cookies

#### Шаг 1: Залогиньтесь в Instagram в браузере

1. Откройте Chrome/Яндекс/Firefox
2. Войдите на https://www.instagram.com
3. Убедитесь что вы залогинены
4. **Закройте браузер** (важно!)

#### Шаг 2: Импортируйте cookies

```bash
# Для Chrome
python import_browser_session.py
# Выберите: chrome
# Введите логин Instagram

# Для Яндекс браузера
python import_yandex_simple.py

# Для Firefox
python import_browser_session.py
# Выберите: firefox
```

#### Шаг 3: Запустите сбор

```bash
python run_thematic_collection.py humor 10
```

## 🔧 Технические детали

### Как это работает:

1. **Загрузка cookies из браузера**:
   - Используется библиотека `browser_cookie3`
   - Читает cookies из базы данных браузера
   - Копирует `sessionid`, `csrftoken` и другие cookies

2. **Проверка работоспособности**:
   - Делается тестовый запрос к Instagram API
   - Проверяется наличие `sessionid` cookie
   - Определяется username

3. **Использование сессии**:
   - Сессия с cookies используется для GraphQL API
   - Обходит блокировку на логин
   - Работает как обычный браузер

### Поддерживаемые браузеры:

- ✅ Chrome
- ✅ Яндекс браузер
- ✅ Firefox
- ✅ Edge
- ✅ Opera (через Chrome движок)

## ⚠️ Важно

1. **Закройте браузер** перед импортом cookies
   - Браузер блокирует доступ к файлу cookies когда открыт

2. **Убедитесь что вы залогинены** в браузере
   - Cookies должны быть свежими (не истекшими)

3. **Cookies истекают** через некоторое время
   - Если сессия перестала работать, импортируйте cookies снова

## 🚀 Преимущества

✅ **Обходит блокировку Instagram** на логин
✅ **Не требует Selenium** (быстрее)
✅ **Работает с GraphQL API** напрямую
✅ **Автоматически** пробует все браузеры

## 📚 Связанные файлы

- `modules/thematic_collectors/browser_cookies_helper.py` - Помощник для загрузки cookies
- `import_browser_session.py` - Скрипт для ручного импорта
- `import_yandex_simple.py` - Импорт из Яндекс браузера
- `modules/thematic_collectors/humor_collector.py` - Использует cookies автоматически

## 🔍 Отладка

Если cookies не загружаются:

1. **Проверьте что браузер закрыт**
2. **Проверьте что вы залогинены** на instagram.com
3. **Попробуйте другой браузер**
4. **Проверьте логи** - там будет указано какой браузер пробовался

## 💡 Альтернатива: Instaloader сессия

Если у вас уже есть сохраненная сессия instaloader:

```bash
# Instaloader автоматически использует сохраненную сессию
python run_thematic_collection.py humor 10
```

Сессия instaloader сохраняется в:
- Windows: `%LOCALAPPDATA%\Instaloader\session-USERNAME`
- Linux/Mac: `~/.config/instaloader/session-USERNAME`

---

**Вывод**: Используйте cookies из браузера вместо логина через Selenium - это обходит блокировку Instagram!
