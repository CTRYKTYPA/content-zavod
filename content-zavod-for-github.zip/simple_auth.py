"""Простая авторизация Instagram через браузер."""
import sys
import codecs
from pathlib import Path

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

print("=" * 60)
print("ПРОСТАЯ АВТОРИЗАЦИЯ INSTAGRAM")
print("=" * 60)
print("\nСамый простой способ:")
print("1. Откройте браузер (Chrome/Firefox)")
print("2. Войдите на https://www.instagram.com")
print("3. Убедитесь что вы залогинены")
print("4. Нажмите Enter здесь\n")

input("Нажмите Enter когда будете готовы...")

try:
    import browser_cookie3
    print("\nИмпортирую сессию из браузера...")
    
    # Пробуем Chrome
    try:
        cookies = browser_cookie3.chrome(domain_name="instagram.com")
        browser_name = "Chrome"
    except:
        try:
            cookies = browser_cookie3.firefox(domain_name="instagram.com")
            browser_name = "Firefox"
        except:
            cookies = browser_cookie3.edge(domain_name="instagram.com")
            browser_name = "Edge"
    
    print(f"Найдены cookies из {browser_name}")
    
    # Создаём instaloader
    import instaloader
    L = instaloader.Instaloader()
    
    # Импортируем cookies
    import requests
    session = requests.Session()
    for cookie in cookies:
        session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
    
    L.context._session = session
    
    # Проверяем
    username = L.test_login()
    if username:
        print(f"OK: Сессия работает! Пользователь: {username}")
        
        # Сохраняем
        L.save_session_to_file()
        print("OK: Сессия сохранена!")
        print("\nТеперь можно запустить тест:")
        print("  python test_download.py")
    else:
        print("Ошибка: Не удалось получить сессию")
        print("Убедитесь что вы залогинены в браузере на instagram.com")

except ImportError:
    print("\nУстанавливаю browser-cookie3...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "browser-cookie3"])
    print("Перезапустите скрипт: python simple_auth.py")
except Exception as e:
    print(f"\nОшибка: {e}")
    print("\nАльтернатива:")
    print("1. Подождите 10-15 минут")
    print("2. Попробуйте снова: python test_download.py")
    print("3. Или подтвердите checkpoint в браузере по ссылке из ошибки")
