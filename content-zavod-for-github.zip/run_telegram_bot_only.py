#!/usr/bin/env python3
"""
Запуск только Telegram-бота (без Celery/Redis).
Удобно для демо и проверки уведомлений: /status, /stats, /alerts, /topics, /videos.

Требуется в .env:
  TELEGRAM_BOT_TOKEN=...
  TELEGRAM_ADMIN_IDS=123456789   или   [123456789]   или   123,456
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import requests
from loguru import logger

from config import settings
from database import init_db, get_db
from modules.telegram_bot import TelegramBot


def _fetch_bot_username() -> str | None:
    """Узнать @username бота через getMe (чтобы вывести в лог)."""
    token = settings.TELEGRAM_BOT_TOKEN
    if not token:
        return None
    try:
        r = requests.get(
            f"https://api.telegram.org/bot{token}/getMe",
            timeout=10,
        )
        data = r.json()
        if data.get("ok") and isinstance(data.get("result"), dict):
            u = data["result"].get("username")
            return f"@{u}" if u else None
    except Exception:
        pass
    return None


def main():
    if not settings.TELEGRAM_BOT_TOKEN:
        print("Ошибка: задайте TELEGRAM_BOT_TOKEN в .env")
        print("Создайте бота через @BotFather, скопируйте токен.")
        sys.exit(1)

    init_db()
    db = next(get_db())
    bot = TelegramBot(db)

    bot_handle = _fetch_bot_username()
    logger.info("Запуск Telegram-бота (только бот, без Celery)...")
    if bot_handle:
        logger.info(f"Бот: {bot_handle} — открой в Telegram и пиши команды.")
    logger.info("Команды: /start /status /stats /alerts /topics /videos /myid")
    logger.info("Остановка: Ctrl+C")
    bot.run()


if __name__ == "__main__":
    main()
