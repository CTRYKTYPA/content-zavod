"""Модуль управления тематиками и контентом."""
from .manager import ContentManager

__all__ = ["ContentManager"]
