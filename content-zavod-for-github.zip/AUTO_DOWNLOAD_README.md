# Автоматический поиск и скачивание видео с Instagram

## Описание

Новый модуль `instagram_video_finder.py` автоматизирует процесс:
1. **Поиск видео** - находит видео в профилях или по хэштегам
2. **Сохранение ссылок** - сохраняет URL в файлы для последующего использования
3. **Скачивание** - использует уже протестированный метод `download_video_combined`

## Структура

```
modules/content_collector/
  ├── instagram_downloader.py      # Существующий модуль (НЕ ТРОГАЕМ)
  └── instagram_video_finder.py    # Новый модуль для автоматизации

auto_download_videos.py             # Скрипт для запуска
instagram_links/                    # Папка для сохраненных ссылок
test_downloads/                     # Папка для скачанных видео (существующая)
```

## Использование

### Вариант 1: Поиск в профиле

```bash
python auto_download_videos.py profile instagram 10
```

Найдет 10 видео из профиля @instagram и скачает их.

### Вариант 2: Поиск по хэштегу

```bash
python auto_download_videos.py hashtag travel 5
```

Найдет 5 видео по хэштегу #travel и скачает их.

### Вариант 3: Скачать из сохраненных ссылок

```bash
python auto_download_videos.py links video_links_20240122_123456.txt
```

Скачает видео из ранее сохраненного файла со ссылками.

### Вариант 4: Интерактивный режим

```bash
python auto_download_videos.py
```

Запустит интерактивное меню.

## Программное использование

```python
from modules.content_collector.instagram_video_finder import InstagramVideoFinder

finder = InstagramVideoFinder()

# Найти и скачать видео из профиля
result = finder.find_and_download("username", "profile", limit=10)

# Найти и скачать видео по хэштегу
result = finder.find_and_download("travel", "hashtag", limit=5)

# Только найти видео (без скачивания)
video_urls = finder.find_videos_from_profile("username", limit=10)
finder.save_links(video_urls, "my_videos.txt")

# Позже скачать из файла
video_urls = finder.load_links("my_videos.txt")
finder.download_videos(video_urls)
```

## Результаты

- **Ссылки сохраняются в:** `instagram_links/`
- **Видео скачиваются в:** `test_downloads/` (существующая папка)

## Важно

- ✅ Существующий модуль `instagram_downloader.py` **НЕ ИЗМЕНЕН**
- ✅ Используется уже протестированный метод скачивания
- ✅ Все работает через новый модуль `instagram_video_finder.py`
