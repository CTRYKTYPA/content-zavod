# Актуальные методы парсинга ссылок Instagram на 2026 год

## 📋 Резюме

Я нашел и обновил код с **актуальными методами на 2026 год** для парсинга ссылок из Instagram через Graph API.

## ✅ Что было сделано

1. ✅ Обновлена версия API до **v24.0** (актуальная на 2026)
2. ✅ Исправлены endpoints согласно официальной документации
3. ✅ Добавлена правильная обработка типов токенов
4. ✅ Добавлены информативные сообщения об ошибках
5. ✅ Добавлен альтернативный метод получения постов пользователя

## 🔑 Ключевая проблема: Типы токенов

### Instagram Token (IGAAT...) - У ВАС СЕЙЧАС
- ✅ Работает: Получение информации о пользователе
- ✅ Работает: Публикация контента
- ❌ **НЕ работает**: Поиск по хэштегам (hashtag search)
- ❌ **НЕ работает**: Получение постов по хэштегам

### Facebook User Access Token (EAA...) - НУЖЕН ДЛЯ ХЭШТЕГОВ
- ✅ Работает: Все функции Instagram токена
- ✅ Работает: **Поиск по хэштегам**
- ✅ Работает: **Получение постов по хэштегам**

## 🎯 Методы парсинга ссылок (2026)

### Метод 1: Instagram Graph API - Hashtag Search (ТРЕБУЕТ FACEBOOK ТОКЕН)

**Endpoint:**
```
GET https://graph.facebook.com/v24.0/ig_hashtag_search?user_id=<<USER_ID>>&q=<<HASHTAG>>&access_token=<<TOKEN>>
```

**Шаги:**
1. Найти ID хэштега через `ig_hashtag_search`
2. Получить посты через `/{hashtag_id}/top_media` или `/{hashtag_id}/recent_media`
3. Извлечь `permalink` из каждого поста

**Ограничения:**
- Максимум 30 уникальных хэштегов за 7 дней
- Recent media: только последние 24 часа
- Максимум 50 постов на страницу
- Требуется App Review для `Instagram Public Content Access`

**Код:**
```python
from modules.content_collector.instagram_graph_api import InstagramGraphAPI

api = InstagramGraphAPI()
post_urls = api.get_hashtag_posts("funnyvideos", limit=10)
```

### Метод 2: Instagram Graph API - User Media (РАБОТАЕТ С INSTAGRAM ТОКЕНОМ)

**Endpoint:**
```
GET /{ig-user-id}/media?fields=id,permalink&limit=50
```

**Описание:**
Получение постов конкретного пользователя (не по хэштегам).

**Код:**
```python
from modules.content_collector.instagram_graph_api import InstagramGraphAPI

api = InstagramGraphAPI()
post_urls = api.get_user_media_urls(limit=50)
```

### Метод 3: Selenium (УЖЕ РЕАЛИЗОВАН В ПРОЕКТЕ)

**Описание:**
Автоматизация браузера для парсинга страниц Instagram.

**Плюсы:**
- Работает без API токенов
- Может парсить любые страницы
- Не требует App Review

**Минусы:**
- Медленнее API
- Требует авторизацию в Instagram
- Может быть заблокирован

**Использование:**
Уже реализовано в `modules/thematic_collectors/humor_collector.py`

### Метод 4: Instaloader (УЖЕ РЕАЛИЗОВАН В ПРОЕКТЕ)

**Описание:**
Python библиотека для парсинга Instagram.

**Плюсы:**
- Не требует официального API
- Может парсить хэштеги
- Поддерживает авторизацию

**Минусы:**
- Неофициальный метод
- Может нарушать ToS Instagram
- Может быть заблокирован

**Использование:**
Уже реализовано в `modules/thematic_collectors/humor_collector.py`

## 📝 Что нужно сделать

### Для работы с хэштегами через Graph API:

1. **Получить Facebook User Access Token (EAA...)**
   - См. инструкцию: `HOW_TO_GET_FACEBOOK_TOKEN.md`
   - Используйте Facebook Login в вашем приложении
   - Требуются разрешения: `instagram_basic`, `pages_read_engagement`

2. **Пройдите App Review**
   - Запросите доступ к `Instagram Public Content Access`
   - Это обязательное требование для hashtag search

3. **Обновите .env**
   ```
   INSTAGRAM_GRAPH_API_TOKEN=EAA...ваш_facebook_токен...
   ```

4. **Проверьте работу**
   ```bash
   python test_graph_api_links.py
   ```

## 🔄 Текущая ситуация

### Что работает СЕЙЧАС:
- ✅ Получение информации о пользователе (через Instagram токен)
- ✅ Публикация контента (через Instagram токен)
- ✅ Сбор ссылок через Selenium (резервный метод)
- ✅ Сбор ссылок через Instaloader (резервный метод)

### Что НЕ работает СЕЙЧАС:
- ❌ Поиск по хэштегам через Graph API (нужен Facebook токен)
- ❌ Получение постов по хэштегам через Graph API (нужен Facebook токен)

## 📚 Документация

- `INSTAGRAM_GRAPH_API_2026_GUIDE.md` - Подробное руководство по Graph API
- `HOW_TO_GET_FACEBOOK_TOKEN.md` - Инструкция по получению Facebook токена
- Официальная документация: https://developers.facebook.com/docs/instagram-platform/

## 🎯 Рекомендации

1. **Для тестирования**: Используйте Graph API Explorer для быстрого получения Facebook токена
2. **Для production**: Реализуйте OAuth flow для автоматического получения токенов
3. **Резервные методы**: Продолжайте использовать Selenium/Instaloader как fallback
4. **Мониторинг**: Отслеживайте лимиты API (30 хэштегов за 7 дней)

## ⚠️ Важные ограничения (2026)

- **Hashtag search**: Максимум 30 уникальных хэштегов за 7 дней
- **Recent media**: Только посты за последние 24 часа
- **Top media**: Ограничено популярными постами
- **Rate limits**: 200 запросов в час
- **App Review**: Обязателен для публичного контента

## 🔗 Полезные ссылки

- [Instagram Graph API Documentation](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api)
- [Hashtag Search Endpoint](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api/reference/ig-hashtag-search/)
- [User Media Endpoint](https://developers.facebook.com/docs/instagram-platform/instagram-graph-api/reference/ig-user/media/)
- [App Review Guide](https://developers.facebook.com/docs/app-review)

---

**Обновлено**: 25 января 2026
**Версия API**: v24.0
**Статус**: Код обновлен согласно актуальной документации 2026 года
