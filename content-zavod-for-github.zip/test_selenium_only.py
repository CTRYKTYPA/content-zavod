"""
БЫСТРЫЙ ТЕСТ ТОЛЬКО SELENIUM МЕТОДОВ (Undetected-ChromeDriver и Nodriver).
Без проверки cookies - только логин через Selenium.
"""
import sys
from pathlib import Path
from loguru import logger
import io
import time
import random

# Настройка логирования
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
logger.remove()
logger.add(sys.stdout, format="{time:HH:mm:ss} | {level: <8} | {message}", level="INFO")

from config import settings

def test_undetected_chromedriver(username: str, password: str):
    """Тест Undetected-ChromeDriver."""
    print("\n" + "="*80)
    print("ТЕСТ 1: UNDETECTED-CHROMEDRIVER")
    print("="*80)
    
    try:
        import undetected_chromedriver as uc
        from selenium.webdriver.common.by import By
        from selenium.webdriver.common.keys import Keys
        
        logger.info("Инициализирую Undetected-ChromeDriver...")
        
        options = uc.ChromeOptions()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        options.add_argument('--disable-blink-features=AutomationControlled')
        options.add_experimental_option("excludeSwitches", ["enable-automation"])
        options.add_experimental_option('useAutomationExtension', False)
        
        # НЕ headless - Instagram лучше работает с видимым браузером
        # options.add_argument('--headless=new')
        
        driver = uc.Chrome(options=options, version_main=None)
        
        try:
            logger.info("Загружаю страницу логина...")
            driver.get('https://www.instagram.com/accounts/login/')
            time.sleep(3)
            
            # Ищем поля
            logger.info("Ищу поля ввода...")
            username_field = driver.find_element(By.CSS_SELECTOR, 'input[name="username"], input[type="text"]')
            password_field = driver.find_element(By.CSS_SELECTOR, 'input[name="password"], input[type="password"]')
            
            logger.info("[OK] Поля найдены")
            
            # Вводим данные
            logger.info("Ввожу логин...")
            username_field.clear()
            username_field.send_keys(username)
            time.sleep(1)
            
            logger.info("Ввожу пароль...")
            password_field.clear()
            password_field.send_keys(password)
            time.sleep(1)
            
            # Нажимаем кнопку
            try:
                login_button = driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
                login_button.click()
            except:
                password_field.send_keys(Keys.RETURN)
            
            # Ждем
            logger.info("Ожидаю авторизацию (8 секунд)...")
            time.sleep(8)
            
            # Проверяем cookies
            cookies = driver.get_cookies()
            has_sessionid = any(c.get('name') == 'sessionid' for c in cookies)
            
            current_url = driver.current_url
            
            if has_sessionid:
                logger.info("[OK] ✅ УСПЕХ! sessionid найден!")
                logger.info(f"[OK] URL: {current_url}")
                driver.quit()
                return True
            else:
                logger.warning("[WARN] sessionid не найден")
                logger.warning(f"URL: {current_url}")
                
                # Скриншот
                try:
                    screenshot_path = Path("selenium_cookies") / f"test_undetected_{username}.png"
                    screenshot_path.parent.mkdir(exist_ok=True)
                    driver.save_screenshot(str(screenshot_path))
                    logger.warning(f"Скриншот: {screenshot_path}")
                except:
                    pass
                
                driver.quit()
                return False
                
        except Exception as e:
            logger.error(f"[ERROR] Ошибка: {e}")
            try:
                driver.quit()
            except:
                pass
            return False
            
    except ImportError:
        logger.warning("[WARN] undetected-chromedriver не установлен")
        logger.info("Установите: pip install undetected-chromedriver")
        return False
    except Exception as e:
        logger.error(f"[ERROR] Критическая ошибка: {e}")
        return False


def test_nodriver(username: str, password: str):
    """Тест Nodriver."""
    print("\n" + "="*80)
    print("ТЕСТ 2: NODRIVER")
    print("="*80)
    
    try:
        import nodriver as uc
        import asyncio
        
        logger.info("Инициализирую Nodriver...")
        
        async def login_async():
            try:
                browser = await uc.start(
                    headless=True,
                    browser_args=["--no-sandbox", "--disable-dev-shm-usage"]
                )
                page = await browser.get('https://www.instagram.com/accounts/login/')
                await page.sleep(3)
                
                # Ищем поля
                logger.info("Ищу поля ввода...")
                username_input = await page.select('input[name="username"], input[type="text"]')
                password_input = await page.select('input[name="password"], input[type="password"]')
                
                logger.info("[OK] Поля найдены")
                
                # Вводим данные
                logger.info("Ввожу логин...")
                await username_input.clear()
                await username_input.send_keys(username)
                await page.sleep(1)
                
                logger.info("Ввожу пароль...")
                await password_input.clear()
                await password_input.send_keys(password)
                await page.sleep(1)
                
                # Нажимаем кнопку
                try:
                    login_button = await page.select('button[type="submit"]')
                    await login_button.click()
                except:
                    await password_input.send_keys(uc.Keys.ENTER)
                
                # Ждем
                logger.info("Ожидаю авторизацию (6 секунд)...")
                await page.sleep(6)
                
                # Проверяем cookies
                cookies = []
                try:
                    if hasattr(browser, 'cookies'):
                        cookies = await browser.cookies.get_all() if hasattr(browser.cookies, 'get_all') else []
                    if not cookies and hasattr(page, 'cookies'):
                        cookies = await page.cookies() if callable(getattr(page, 'cookies', None)) else []
                except:
                    pass
                
                if not isinstance(cookies, list):
                    cookies = list(cookies) if cookies else []
                
                has_sessionid = any((c.get('name') if isinstance(c, dict) else getattr(c, 'name', '')) == 'sessionid' for c in cookies)
                
                current_url = page.url
                
                if has_sessionid:
                    logger.info("[OK] ✅ УСПЕХ! sessionid найден!")
                    logger.info(f"[OK] URL: {current_url}")
                    await browser.stop()
                    return True
                else:
                    logger.warning("[WARN] sessionid не найден")
                    logger.warning(f"URL: {current_url}")
                    await browser.stop()
                    return False
                    
            except Exception as e:
                logger.error(f"[ERROR] Ошибка: {e}")
                try:
                    await browser.stop()
                except:
                    pass
                return False
        
        # Запускаем
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(login_async())
        loop.close()
        
        return result
        
    except ImportError:
        logger.warning("[WARN] nodriver не установлен")
        logger.info("Установите: pip install nodriver")
        return False
    except Exception as e:
        logger.error(f"[ERROR] Критическая ошибка: {e}")
        return False


def main():
    print("\n" + "="*80)
    print("БЫСТРЫЙ ТЕСТ ТОЛЬКО SELENIUM МЕТОДОВ")
    print("="*80)
    print("\nТестирую только:")
    print("  1. Undetected-ChromeDriver")
    print("  2. Nodriver")
    print("\nБез проверки cookies - только логин через Selenium\n")
    
    username = settings.INSTAGRAM_USERNAME
    password = settings.INSTAGRAM_PASSWORD
    
    if not username or not password:
        print("❌ Логин/пароль не указаны в .env")
        print("\nДобавьте в .env:")
        print("  INSTAGRAM_USERNAME=ваш_логин")
        print("  INSTAGRAM_PASSWORD=ваш_пароль")
        return
    
    print(f"Логин: {username}\n")
    
    # Тест 1: Undetected-ChromeDriver
    result1 = test_undetected_chromedriver(username, password)
    
    if result1:
        print("\n" + "="*80)
        print("✅ УСПЕХ! Undetected-ChromeDriver работает!")
        print("="*80)
        return
    
    # Тест 2: Nodriver
    result2 = test_nodriver(username, password)
    
    if result2:
        print("\n" + "="*80)
        print("✅ УСПЕХ! Nodriver работает!")
        print("="*80)
        return
    
    print("\n" + "="*80)
    print("❌ ОБА МЕТОДА НЕ СРАБОТАЛИ")
    print("="*80)
    print("\nВозможные причины:")
    print("1. Instagram блокирует логин с нового браузера")
    print("2. Требуется проверка (checkpoint/challenge)")
    print("3. Неверный логин/пароль")
    print("\nРекомендация:")
    print("Используйте cookies из браузера:")
    print("  1. Закройте браузер")
    print("  2. python quick_test_cookies.py")


if __name__ == '__main__':
    main()
