"""Простой импорт сессии из Яндекс браузера."""
import sys
import codecs
from pathlib import Path
import os

if sys.platform == 'win32':
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')

project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from config import settings
import instaloader

print("=" * 60)
print("ИМПОРТ СЕССИИ ИЗ ЯНДЕКС БРАУЗЕРА")
print("=" * 60)

username = settings.INSTAGRAM_USERNAME

if not username:
    print("Ошибка: INSTAGRAM_USERNAME не указан в .env")
    exit(1)

print(f"\nЛогин: {username}")
print("\nВАЖНО:")
print("1. Закройте Яндекс браузер полностью (если открыт)")
print("2. Подождите 2 секунды...")
import time
time.sleep(2)

print("\nИмпортирую cookies из Яндекс браузера...")

try:
    import browser_cookie3
    
    # Путь к профилю Яндекс браузера
    yandex_profile = Path(os.getenv("LOCALAPPDATA")) / "Yandex" / "YandexBrowser" / "User Data" / "Default"
    
    if not yandex_profile.exists():
        print("Профиль Яндекс браузера не найден")
        exit(1)
    
    print(f"Профиль: {yandex_profile}")
    
    # Пробуем использовать browser-cookie3 с указанием пути к профилю
    # Яндекс браузер использует Chrome движок
    try:
        # Пробуем через chrome с указанием cookie_file
        cookies_file = yandex_profile / "Network" / "Cookies"
        if cookies_file.exists():
            cookies = browser_cookie3.chrome(domain_name="instagram.com", cookie_file=str(cookies_file))
        else:
            # Пробуем стандартный способ
            cookies = browser_cookie3.chrome(domain_name="instagram.com")
    except Exception as e:
        print(f"Ошибка при чтении cookies: {e}")
        print("\nПопробуйте:")
        print("1. Откройте Яндекс браузер")
        print("2. Войдите на instagram.com")
        print("3. Закройте браузер полностью")
        print("4. Запустите этот скрипт снова")
        exit(1)
    
    cookies_list = list(cookies)
    
    if not cookies_list:
        print("Cookies Instagram не найдены")
        print("Убедитесь что вы залогинены на instagram.com в Яндекс браузере")
        exit(1)
    
    print(f"Найдено cookies: {len(cookies_list)}")
    
    # Создаём instaloader
    L = instaloader.Instaloader()
    
    # Импортируем cookies
    import requests
    session = requests.Session()
    for cookie in cookies:
        session.cookies.set(cookie.name, cookie.value, domain=cookie.domain)
    
    L.context._session = session
    
    # Проверяем
    test_user = L.test_login()
    if test_user:
        print(f"OK: Сессия работает! Пользователь: {test_user}")
        
        # Сохраняем
        L.save_session_to_file()
        print("OK: Сессия сохранена!")
        print("\nТеперь можно запускать систему:")
        print("  python test_download.py")
    else:
        print("Ошибка: Сессия не работает")
        print("Убедитесь что вы залогинены в Instagram через Яндекс браузер")

except Exception as e:
    print(f"Ошибка: {e}")
    import traceback
    traceback.print_exc()
