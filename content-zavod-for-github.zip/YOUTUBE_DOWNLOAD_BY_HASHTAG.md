# Скачивание с YouTube по хэштегам

YouTube проще Instagram: не нужна авторизация, нет жёстких блокировок, **yt-dlp** уже в проекте и отлично работает с поиском.

---

## 1. yt-dlp (рекомендуется)

**Уже установлен** в проекте (`requirements.txt`). Поддерживает поиск по запросу (в т.ч. хэштегам) через `ytsearch`.

### Синтаксис поиска

| Формат | Описание |
|--------|----------|
| `ytsearchN:запрос` | Первые **N** результатов поиска YouTube |
| `ytsearchall:запрос` | Все результаты (осторожно: может быть очень много) |

### Примеры (CLI)

```bash
# Список ID и названий по хэштегу (без скачивания)
yt-dlp "ytsearch10:#funny" --get-id --get-title

# Скачать 5 видео по хэштегу
yt-dlp "ytsearch20:#funny" --max-downloads 5 -o "downloads/%(title)s.%(ext)s"

# Короткие (Shorts) по хэштегу, до 5 штук
yt-dlp "ytsearch15:#shorts funny" --max-downloads 5 -o "downloads/%(title)s.%(ext)s"

# Несколько хэштегов подряд (разные запуски)
yt-dlp "ytsearch10:#memes" --max-downloads 3 -o "downloads/memes/%(title)s.%(ext)s"
yt-dlp "ytsearch10:#viral" --max-downloads 3 -o "downloads/viral/%(title)s.%(ext)s"
```

### Хэштег в запросе

- С решёткой: `ytsearch10:#funny` — ищет по хэштегу `#funny`.
- Без решётки: `ytsearch10:funny` — обычный поиск по слову «funny».

Оба варианта работают; для точности по хэштегу лучше указывать `#`.

---

## 2. Скрипт по одному хэштегу

**`download_youtube_by_hashtag.py`** — обёртка над yt-dlp. По умолчанию только **Shorts 10–120 сек**.

```bash
# Shorts 10–120 сек, 10 роликов по #funny
python download_youtube_by_hashtag.py "#funny"

# Лимит и папка
python download_youtube_by_hashtag.py "#memes" --max 5 --output downloads/memes

# Длина Shorts: 15–90 сек
python download_youtube_by_hashtag.py "#funny" --min-duration 15 --max-duration 90

# Только список (без скачивания)
python download_youtube_by_hashtag.py "#viral" --list-only

# Любые видео, не только Shorts
python download_youtube_by_hashtag.py "#funny" --no-shorts

# Прокси
python download_youtube_by_hashtag.py "#funny" --proxy "http://127.0.0.1:7890"
```

Подробнее: `python download_youtube_by_hashtag.py --help`.

---

## 3. Пакетное скачивание по списку хэштегов

**`download_youtube_hashtags_batch.py`** — перебирает хэштеги из **`youtube_hashtags_list.txt`**, для каждого качает Shorts в подпапку `downloads/youtube_hashtag/<хэштег>/`.

В списке 20 хэштегов: **русские** (#смех, #приколы, #юмор, …) и **английские** (#funny, #memes, …). Редактируйте `youtube_hashtags_list.txt` по необходимости.

```bash
# 15 видео на каждый хэштег (все 20)
python download_youtube_hashtags_batch.py

# Тест: 5 видео на хэштег
python download_youtube_hashtags_batch.py --test

# Тест только по первым 3 хэштегам, по 5 видео
python download_youtube_hashtags_batch.py --test --limit-tags 3

# Свой файл хэштегов и папка
python download_youtube_hashtags_batch.py -f my_hashtags.txt -o downloads/my_shorts

# Прокси
python download_youtube_hashtags_batch.py --proxy "http://127.0.0.1:7890"
```

---

## 4. Браузерные расширения (ручное скачивание)

Если нужно качать отдельные видео вручную из браузера:

| Расширение | Браузеры | Особенности |
|------------|----------|-------------|
| **Tubly** | Chrome, Edge, Firefox | 4K/8K, MP3, Shorts, без рекламы в интерфейсе |
| **YouTube Downloader** | Firefox | Видео, Shorts, встроенное; аудио, GIF |
| **Flow Launcher + YouTube Downloader** | Windows | Глобальный поиск, команда `{-yt} {ссылка}` |

Для **автоматизации по хэштегам** они не подходят — только yt-dlp/скрипт.

---

## 5. Итог

| Задача | Решение |
|--------|---------|
| Shorts по одному хэштегу | `download_youtube_by_hashtag.py "#funny"` (10–120 сек по умолчанию) |
| Shorts по 20 хэштегам (RU+EN) | `download_youtube_hashtags_batch.py` и `youtube_hashtags_list.txt` |
| Ручное скачивание из браузера | Tubly / YouTube Downloader (расширения) |
| Интеграция в пайплайн | **yt-dlp** или скрипты из Python |

С YouTube проще, чем с Instagram: не нужны cookies, прокси обычно не требуются (при необходимости передайте `--proxy` в скрипт). Поиск и скачивание по хэштегам работают «из коробки» через yt-dlp.
