#!/usr/bin/env python3
"""
Пакетное скачивание YouTube Shorts по списку хэштегов.

Читает youtube_hashtags_list.txt, для каждого хэштега качает Shorts (10–120 сек)
в подпапку downloads/youtube_hashtag/<хэштег>/.

Примеры:
  python download_youtube_hashtags_batch.py              # 15 видео на хэштег
  python download_youtube_hashtags_batch.py --test       # 5 на хэштег (тест)
  python download_youtube_hashtags_batch.py -n 3 --test  # только первые 3 хэштега, по 5 видео
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DEFAULT_LIST = ROOT / "youtube_hashtags_list.txt"
DEFAULT_OUT = ROOT / "downloads" / "youtube_hashtag"


def load_hashtags(path: Path) -> list[str]:
    """Загрузить хэштеги из файла. Пустые строки и строки «# комментарий» пропускаем."""
    lines = path.read_text(encoding="utf-8").splitlines()
    out = []
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith("# ") or line.startswith("#\t"):
            continue
        if not line.startswith("#"):
            line = f"#{line}"
        out.append(line)
    return out


def main() -> None:
    ap = argparse.ArgumentParser(
        description="Скачать Shorts по списку хэштегов (файл youtube_hashtags_list.txt)."
    )
    ap.add_argument(
        "-f", "--file",
        type=Path,
        default=DEFAULT_LIST,
        help=f"Файл со списком хэштегов (по умолчанию {DEFAULT_LIST.name})",
    )
    ap.add_argument(
        "-o", "--output",
        type=Path,
        default=DEFAULT_OUT,
        help=f"Корневая папка для подпапок по хэштегам (по умолчанию {DEFAULT_OUT})",
    )
    ap.add_argument(
        "-n", "--max-per-tag",
        type=int,
        default=15,
        help="Сколько видео качать на каждый хэштег (по умолчанию 15)",
    )
    ap.add_argument(
        "--test",
        action="store_true",
        help="Тест: 5 видео на хэштег (переопределяет -n)",
    )
    ap.add_argument(
        "--limit-tags",
        type=int,
        default=0,
        metavar="N",
        help="Обработать только первые N хэштегов (0 = все)",
    )
    ap.add_argument(
        "--proxy",
        type=str,
        default=None,
        help="Прокси для yt-dlp (например http://127.0.0.1:7890)",
    )
    args = ap.parse_args()

    per_tag = 5 if args.test else args.max_per_tag
    out_root = args.output.resolve()
    out_root.mkdir(parents=True, exist_ok=True)

    if not args.file.exists():
        print(f"Файл не найден: {args.file}")
        print("Создайте youtube_hashtags_list.txt с хэштегами (по одному на строку).")
        sys.exit(1)

    hashtags = load_hashtags(args.file)
    if args.limit_tags > 0:
        hashtags = hashtags[: args.limit_tags]

    if not hashtags:
        print("Нет хэштегов в файле.")
        sys.exit(1)

    print(f"Хэштегов: {len(hashtags)}. Видео на хэштег: {per_tag}. Папка: {out_root}")
    if args.test:
        print("Режим: ТЕСТ (5 видео на хэштег)")
    print()

    script = ROOT / "download_youtube_by_hashtag.py"
    for i, tag in enumerate(hashtags, 1):
        slug = tag.lstrip("#").strip() or "noname"
        subdir = out_root / slug
        subdir.mkdir(parents=True, exist_ok=True)
        cmd = [
            sys.executable,
            str(script),
            tag,
            "--max", str(per_tag),
            "-o", str(subdir),
        ]
        if args.proxy:
            cmd += ["--proxy", args.proxy]
        print(f"[{i}/{len(hashtags)}] {tag} -> {subdir}")
        env = {**os.environ, "PYTHONIOENCODING": "utf-8"}
        ret = subprocess.run(cmd, cwd=str(ROOT), env=env)
        if ret.returncode != 0:
            print(f"  (завершено с кодом {ret.returncode}, продолжаем)")
        print()

    print("Готово.")


if __name__ == "__main__":
    main()
