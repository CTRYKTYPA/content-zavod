"""
Конфиг тем для TikTok (Этап 1).
Источники: users (никнеймы) и/или hashtags. Без API — yt-dlp.

Users используют web API (работает без app_info). Hashtags — mobile API (нужны куки/app_info).
Приоритет: сначала users, потом hashtags. Добавь своих авторов по темам.
"""

TIKTOK_THEMES = [
    {"name": "Юмор", "slug": "humor", "description": "Смешные видео, комедия, мемы", "folder": "humor",
     "users": ["khaby.lame", "zachking", "spencerx", "daviddobrik"], "hashtags": ["funny", "memes", "comedy", "viral", "fyp"]},
    {"name": "Бизнес", "slug": "business", "description": "Бизнес, предпринимательство, успех", "folder": "business",
     "users": ["garyvee", "alexhormozi", "grantcardone", "edmylett"], "hashtags": ["business", "money", "success", "entrepreneur", "motivation"]},
    {"name": "Лайфстайл", "slug": "lifestyle", "description": "Образ жизни, влоги, красота", "folder": "lifestyle",
     "users": ["addisonre", "charlidamelio", "lorengray", "bellapoarch"], "hashtags": ["lifestyle", "vlog", "beauty", "fashion", "travel"]},
    {"name": "Технологии", "slug": "tech", "description": "Технологии, гаджеты", "folder": "tech",
     "users": ["mkbhd", "zollotech", "unboxtherapy", "linustech"], "hashtags": ["tech", "gadgets", "iphone", "android", "gaming"]},
    {"name": "Мотивация", "slug": "motivation", "description": "Мотивация, цели, развитие", "folder": "motivation",
     "users": ["tonyrobbins", "edmylett", "melrobbins", "jockowillink"], "hashtags": ["motivation", "success", "goals", "mindset", "inspiration"]},
]

DEFAULT_MIN_LIKES = 10_000
DEFAULT_MIN_VIEWS = 500_000
MIN_DURATION = 10
MAX_DURATION = 180
